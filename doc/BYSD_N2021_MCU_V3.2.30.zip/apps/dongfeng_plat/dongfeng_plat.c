#include "dongfeng_plat.h"



unsigned int xGB32960_DongfengBasicPack(void *pOut,unsigned int outbuflen,void *pVIN)
{
	unsigned char *ptr = 0;
	unsigned int rlen = 0;
	unsigned char *cp = "��A00001";
	char *psn = 0;
	char *p_mpu_ver = 0;
	unsigned int templen = 0;
	unsigned char tid[8] = {0};
	unsigned char imei[21] = {0};
	static unsigned int s_df_c6_flow = 0;

	if ((pOut == 0) || (outbuflen == 0))
	{
		return 0;
	}
	ptr = (unsigned char *)pOut + GB32960_CONTENT_OFFSET;

	//ʱ��
	memcpy(ptr,get_rtc_time_ptr(),6);
	rlen += 6;

	//����
	ptr[rlen++] = 0xC6;

	//��ˮ
	s_df_c6_flow++;
	ptr[rlen++] = s_df_c6_flow >> 16;
	ptr[rlen++] = s_df_c6_flow >> 8;
	ptr[rlen++] = s_df_c6_flow;

	//�ְ���ʶ
	ptr[rlen++] = 0;

	//vin
	if (pVIN) memcpy(ptr + rlen,pVIN,17);
	rlen += 17;

	//���Ƴ���
	ptr[rlen++] = strlen((char *)cp);
	memcpy(ptr + rlen,cp,strlen((char *)cp));
	rlen += strlen((char *)cp);

	//�ն�ID 8Bytes
	send_msg(S_MSG_GET_IMEI,imei,(void *)21,0);
	templen = strlen((char *)imei);
	if (templen == 0)
	{
		return 0;
	}
	if (templen < 20)
	{
		memset(imei,'0',20 - templen);
		send_msg(S_MSG_GET_IMEI,imei + (20 - templen),(void *)16,0);
	}
	else
	{
		return 0;
	}
	iccid_str_to_8byte(imei,tid);
	memcpy(ptr + rlen,tid,8);
	rlen += 8;

	//Ӳ���汾��
	ptr[rlen++] = 1;
	ptr[rlen++] = 1;

	//TBOX�̼��汾��
	ptr[rlen++] = 1;
	ptr[rlen++] = 1;


	//vcu���к�
	ptr[rlen++] = 6;
	memcpy(ptr + rlen,"123456",6);
	rlen += 6;

	//mcu���к�
	psn = send_msg(S_MSG_GET_IMEI,0,0,0);
	ptr[rlen++] = strlen(psn);
	memcpy(ptr + rlen,psn,strlen(psn));
	rlen += strlen(psn);

	//bms���к�
	ptr[rlen++] = 6;
	memcpy(ptr + rlen,"111111",6);
	rlen += 6;

	//vcuԴ��ַ
	ptr[rlen++] = 0x01;

	//mcuԴ��ַ
	ptr[rlen++] = 0x02;

	//bmsԴ��ַ
	ptr[rlen++] = 0x03;

	//vcu�汾��
	ptr[rlen++] = strlen("BYSD_VCU_V1.0.1");
	memcpy(ptr + rlen,"BYSD_VCU_V1.0.1",strlen("BYSD_VCU_V1.0.1"));
	rlen += strlen("BYSD_VCU_V1.0.1");

	//mcu�汾
	p_mpu_ver = send_msg(S_MSG_GET_MPU_SOFTWARE_VERSION,0,0,0);
	if ((p_mpu_ver == 0) || (strlen(p_mpu_ver) == 0))
	{
		return 0;
	}

	templen = strlen(APP_VERSION) + strlen((char *)p_mpu_ver);
	if (templen >= 47)
	{
		templen = 47;
	}

	ptr[rlen++] = templen;
	memcpy(ptr+rlen,APP_VERSION,(strlen(APP_VERSION) > templen) ? templen : strlen(APP_VERSION));
	rlen += ((strlen(APP_VERSION) > templen) ? templen : strlen(APP_VERSION));
	if (templen > strlen(APP_VERSION))
	{
		memcpy(ptr + rlen,p_mpu_ver,templen - strlen(APP_VERSION));
		rlen += (templen - strlen(APP_VERSION));
	}

	//bms�汾��
	ptr[rlen++] = strlen("BYSD_BMS_V1.0.1");
	memcpy(ptr + rlen,"BYSD_BMS_V1.0.1",strlen("BYSD_BMS_V1.0.1"));
	rlen += strlen("BYSD_BMS_V1.0.1");

	//�������״̬
	ptr[rlen++] = 0;

	return _xDataBag(pOut,outbuflen,0x20,0xFE,pVIN,ptr,rlen);
}


unsigned int xGB32960_DongfengNewBasicPack(void *pOutBuf,INT16U usOutBufSize,
																	void *pVIN,
																	INT8U t[6],
																	void *piccid,unsigned int iccid_len,
																	void *pesn,unsigned int esn_len
																	)
{
	static unsigned int s_sandian_plat_flow = 0;
	INT16U len = 0;
	INT16U templen = 0;
	unsigned char *pimei = 0;	
	char *p_mpu_ver = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;

	if ((pOutBuf == 0) || (usOutBufSize == 0)) return 0;

	//���ݲɼ�ʱ��
	if (t) memcpy(ptr,t,6);
	len += 6;

	//������Ϣ
	ptr[len++] = 0x51;

	//ʵʱ��Ϣ��ˮ��
	s_sandian_plat_flow++;
	ptr[len++] = s_sandian_plat_flow >> 8;
	ptr[len++] = s_sandian_plat_flow;

	//�ְ���ʶ
	ptr[len++] = 0;

	//��Ϣ��

	//Э��汾
	ptr[len++] = 0x02;

	//�ն�ID
	pimei = send_msg(S_MSG_GET_IMEI,0,0,0);
	templen = strlen((char *)pimei);
	if (templen >= 24)
	{
		templen = 24;
	}
	ptr[len++] = templen;
	memcpy(ptr + len,pimei,templen);
	len += templen;

	//Ӳ���汾
	ptr[len++] = strlen("V1.0");
	memcpy(ptr + len,"V1.0",strlen("V1.0"));
	len += strlen("V1.0");

	//�����汾
	p_mpu_ver = send_msg(S_MSG_GET_MPU_SOFTWARE_VERSION,0,0,0);
	if ((p_mpu_ver == 0) || (strlen((char *)p_mpu_ver) == 0))
	{
		return 0;
	}

	templen = strlen(APP_VERSION) + strlen((char *)p_mpu_ver);
	if (templen >= 47)
	{
		templen = 47;
	}

	ptr[len++] = templen;
	memcpy(ptr+len,APP_VERSION,(strlen(APP_VERSION) > templen) ? templen : strlen(APP_VERSION));
	len += ((strlen(APP_VERSION) > templen) ? templen : strlen(APP_VERSION));
	if (templen > strlen(APP_VERSION))
	{
		memcpy(ptr + len,p_mpu_ver,templen - strlen(APP_VERSION));
		len += (templen - strlen(APP_VERSION));
	}

#if 0
�ն��ͺ�:JJ-Q2019
��ȫоƬ�ͺ�:HSC32I1
��ȫоƬǰ��λ��ʶ��:BVT
#endif

	//�ն��ͺ�
	ptr[len++] = strlen("JJ-Q2019");
	memcpy(ptr + len,"JJ-Q2019",strlen("JJ-Q2019"));
	len += strlen("JJ-Q2019");

	//IMSI
	memcpy(ptr + len,pimei,15);
	len += 15;

	//iccid
	if (piccid)
	{
		memcpy(ptr + len,piccid,20);
	}
	len += 20;

	//sim
	ptr[len++] = 13;
	memcpy(ptr + len,"144",3);
	if (piccid) memcpy(ptr + len + 3,(unsigned char *)piccid + 10,10);
	len += 13;

	//���ƺ�
	ptr[len++] = strlen("��A00003");
	memcpy(ptr + len,"��A00003",strlen("��A00003"));
	len += strlen("��A00003");

	//VCU���к�
	if (pesn && esn_len)
	{
		ptr[len++] = esn_len;
		memcpy(ptr + len,pesn,esn_len);
		len += esn_len;
	}
	else
	{
		ptr[len++] = 0;
	}

	//VCU����CAN����
	ptr[len++] = 1;					//0 ����CAN(BMS) 1 ����CAN (VCU MCU)
	
	//VCUԴ��ַ
	ptr[len++] = 0xEF;

	templen = strlen((char *)get_vcu_ver_ptr());
	if (templen > 16)
	{
		templen = 16;
	}
	//VCU�궨�汾��
	ptr[len++] = templen;
	memcpy(ptr + len,get_vcu_ver_ptr(),templen);
	len += templen;

	//VCU�ͺ�
	ptr[len++] = strlen("CMMNS");
	memcpy(ptr + len,"CMMNS",strlen("CMMNS"));
	len += strlen("CMMNS");

	//VCU�궨�ļ���ʽ
	ptr[len++] = 3;			//1.bin 2.zip 3.gz

	//MCU���к�
	ptr[len++] = 3 + 15;
	memcpy(ptr + len,"MCU",3);
	len += 3;
	memcpy(ptr + len,pimei,15);
	len += 15;

	//MCU����CAN����
	ptr[len++] = 1;					//0 ����CAN(BMS) 1 ����CAN (VCU MCU)

	//MCUԴ��ַ
	ptr[len++] = 0xEE;

	templen = strlen((char *)get_mcu_ver_ptr());
	if (templen > 16)
	{
		templen = 16;
	}
	//MCU�궨�汾��
	ptr[len++] = templen;
	memcpy(ptr + len,get_mcu_ver_ptr(),templen);
	len += templen;

	//MCU�ͺ�
	ptr[len++] = strlen("HUICHUAN");
	memcpy(ptr + len,"HUICHUAN",strlen("HUICHUAN"));
	len += strlen("HUICHUAN");

	//MCU�궨�ļ���ʽ
	ptr[len++] = 3;			//1.bin 2.zip 3.gz

	//BMS���к�
	ptr[len++] = 3 + 15;
	memcpy(ptr + len,"BMS",3);
	len += 3;
	memcpy(ptr + len,pimei,15);
	len += 15;

	//BMS����CAN����
	ptr[len++] = 0;					//0 ����CAN(BMS) 1 ����CAN (VCU MCU)

	//BMSԴ��ַ
	ptr[len++] = 0xC8;

	//BMS�궨�汾��
	templen = strlen((char *)get_bms_ver_ptr());
	if (templen > 16)
	{
		templen = 16;
	}
	ptr[len++] = templen;
	memcpy(ptr + len,get_bms_ver_ptr(),templen);
	len += templen;

	//BMS�ͺ�
	ptr[len++] = strlen("BMS");
	memcpy(ptr + len,"BMS",strlen("BMS"));
	len += strlen("BMS");

	//BMS�궨�ļ���ʽ
	ptr[len++] = 1;			//1.bin 2.zip 3.gz


	//�Ǳ�����ѡ��
	ptr[len++] = strlen("tspBasic");
	memcpy(ptr + len,"tspBasic",strlen("tspBasic"));
	len += strlen("tspBasic");

	//������
	ptr[len++] = 0;

	//OTA
	ptr[len++] = 0xFF;

	//��������
	ptr[len++] = 0x01;

	//��Ϲ���
	ptr[len++] = 0x01;

	return _xDataBag(pOutBuf,usOutBufSize,0x35,0xFE,pVIN,ptr,len);	
}


