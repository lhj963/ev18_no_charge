#ifndef __GB32960_H__
#define __GB32960_H__

#ifdef __cplusplus
extern "C" {
#endif

#define GBHEAD0 0x23
#define GBHEAD1 0x23

#define GB32960_CONTENT_OFFSET (2+1+1+GB_LEN_VIN+1+2)


#define GB32960_MIN_PACK_LEN (2+2+17+1+2+1)

#define GB32960_CMD_OFFSET     				2
#define GB32960_CMD_ACK_FLAG_OFFSET    		3
#define GB32960_VIN_OFFSET					4
#define GB32960_JIAMI_WAY_OFFSET			21
#define GB32960_CONTENT_LEN_OFFSET			22


#define GB32960_LOGIN_CMD 				0x01
#define GB32960_REAL_DATA_CMD 			0x02
#define GB32960_BF_DATA_CMD 			0x03
#define GB32960_LOGOUT_CMD 				0x04
#define GB32960_HEART_BEAT_CMD 			0x07
#define GB32960_JS_CMD 					0x08
#define GB32960_ZC_CMD 					0x37

#define GB32960_PLAT_QUERY_PARAM_CMD	0x80		//ƽ̨��ѯ����
#define GB32960_PLAT_SET_PARAM_CMD		0x81		//ƽ̨���ò���
#define GB32960_PLAT_CTRL_CMD			0x82		//ƽ̨��������

#define ZUOCANG_DATA_INFO			0x61		//����������Ϣ����

#define ZC_DATA_INFO			0x01		//����������Ϣ����
#define QDDJ_INFO 				0x02			//�����������
#define RLDC_INFO 				0x03			//ȼ�ϵ����Ϣ����
#define ECU_INFO 				0x04			//��������Ϣ����
#define CAR_POS_INFO 			0x05		//λ����Ϣ����
#define JIZHI_INFO 				0x06		//��ֵ��Ϣ����
#define SOS_INFO 				0x07		//������Ϣ����
#define VOL_INFO 				0x08		//��ѹ��������
#define TEMP_INFO 				0x09		//�¶���������


#define	GB_LEN_VIN			17		//VIN����
#define GB_LEN_SOFTVER		18		//�����궨ʶ��ų���
#define GB_LEN_CVN			18		//�궨��֤��
#define GB_LEN_IUPR         36
#define GB_LEN_ICCID        20



#define MAX_DJ_CNT  					2
#define MAX_TAN_ZHEN_CNT 				255		//�¶�̽������
#define MAX_CAN_CHARGE_DTC_CNT   		5		//���ɳ��װ�ù���
#define MAX_QDDJ_DTC_CNT   				5		//�����������
#define MAX_ECU_DTC_CNT   				4		//����������
#define MAX_OTHER_DTC_CNT   			20		//������������
#define MAX_DIANCHI_CNT    				2		//��ظ��� ����ϵͳ����
#define DANTI_DIANCHI_CNT_EVERY_DIANCHI 255		//ÿ�������������ж��ٸ�������
#define WENDU_TANZHEN_CNT_EVERY_DIANCHI 255		//ÿ�������������ж��ٸ��¶�̽��


extern void gb32960_analyze(unsigned char channel,CanRxMsg *prxmsg);

extern void gb32960_fresh(void);

extern void GB32960_Init(void *pvin,INT8U way,INT16U *pLoginFlow,unsigned int flow_cnt);


//��¼
extern unsigned int GB32960_LoginPack(void *pOutBuf,unsigned int outbuflen,unsigned char linkid,
			INT8U time[6],void *iccid,INT8U charge_cnt,
			void *pCode,INT8U code_len);


//�ǳ�
extern unsigned int GB32960_LogoutPack(void *pOutBuf,unsigned int outbuflen,unsigned char linkid,INT8U time[6]);

//����
extern unsigned int GB32960_HeartBeatPack(void *pOutBuf,unsigned int outbuflen);

//Уʱ
extern unsigned int GB32960_JSPack(void *pOutBuf,unsigned int outbuflen);



extern unsigned int xGB32960_RealDataPack(void *pOut,unsigned int outbuflen,void *pVIN,
												INT8U time[6],
												INT8U pos_status,INT32U lon,INT32U lat);


extern unsigned int xGB32960_BFDataPack(void *pOut,unsigned int outbuflen,void *pVIN,
													INT8U time[6],
													INT8U pos_status,INT32U lon,INT32U lat);

extern unsigned int D78_xGB32960_RealDataPack(void *pOut,unsigned int outbuflen,void *pVIN,
												INT8U time[6],
												INT8U pos_status,INT32U lon,INT32U lat);

extern unsigned int D78_xGB32960_BFDataPack(void *pOut,unsigned int outbuflen,void *pVIN,
												INT8U time[6],
												INT8U pos_status,INT32U lon,INT32U lat);



/*--------------------ʱ��������---------------------------*/
extern unsigned int sddf_xGB32960_RealDataPack(void *pOut,unsigned int outbuflen,void *pVIN,
												INT8U time[6],
												INT8U pos_status,INT32U lon,INT32U lat);

extern unsigned int sddf_xGB32960_BFDataPack(void *pOut,unsigned int outbuflen,void *pVIN,
												INT8U time[6],
												INT8U pos_status,INT32U lon,INT32U lat);

extern unsigned int sddf_BasicDataPack(void *pOut,unsigned int outbuflen,void *pVIN,INT8U time[6]);

extern unsigned int sddf_charge_data_pack(void *pOut,unsigned int outbuflen,void *pVIN,INT8U time[6]);

extern unsigned int sddf_ack_charge_limit_pack(void *pOut,unsigned int outbuflen,void *pVIN,INT8U time[6]);

extern unsigned int sddf_LoginPlatPack(void *pVIN,void *puser,void *psw,void *pOut,unsigned int outbuflen);

extern unsigned char get_sddf_login_ok_flag(void);

extern void set_sddf_login_ok_flag(unsigned char val);


extern void set_0c0728d0_flag(unsigned char val);
extern unsigned char get_0c0728d0_flag(void);



extern unsigned int xDataBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,void *pDataUnit,INT16U usDataUnitLen);

extern unsigned int _xDataBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,INT8U ack_flag,void *pVIN,void *pDataUnit,INT16U usDataUnitLen);


extern INT8U is_get_milage_id(void);
extern INT8U get_d78_huandian_ver(void);
extern void set_d78_huandian_ver(INT8U val);


extern INT8U get_dst_want_bms_charge_flag(void);
extern void set_dst_want_bms_charge_flag(INT8U val);
extern INT8U get_dst_fact_bms_charge_flag(void);
extern void set_dst_fact_bms_charge_flag(INT8U val);
extern void set_dst_budian_init_vol(unsigned int val);
extern unsigned int get_dst_budian_init_vol(void);

extern INT8U get_lock_car_can_channel(void);
extern void set_lock_car_can_channel(INT8U val);
extern INT8U *get_iccid_bytes_in_ecu(void);
extern void set_iccid_bytes_in_ecu(INT8U *piccid_bytes,unsigned int datlen);
extern INT8U get_iccid_head_flag_in_ecu(void);
extern void set_iccid_head_flag_in_ecu(INT8U val);
extern INT8U *get_iccid_head_bytes_in_ecu(void);
extern void set_iccid_head_bytes_in_ecu(INT8U *piccid_head_bytes,unsigned int datlen);
extern INT8U get_want_bind_status(void);
extern INT8U get_fact_bind_status(void);
extern INT8U get_fact_pro_ver_about_lock(void);
extern INT8U get_fact_lock_status(void);
extern void set_want_bind_status(INT8U val);
extern void set_fact_bind_status(INT8U val);
extern void set_fact_pro_ver_about_lock(INT8U val);
extern void set_fact_lock_status(INT8U val);

extern INT16U gb32960_can_get_cnxt_dianya(INT8U idx);
extern INT16U gb32960_can_get_cnxt_dianliu(INT8U idx);
extern INT8U gb32960_can_get_soc(void);
extern INT8U gb32960_can_get_qddj_cnt(void);

extern void gb32960_can_set_milage(INT32U val);
extern INT32U gb32960_can_get_milage(void);
extern void gb32960_can_set_speed(INT16U val);
extern INT16U gb32960_can_get_speed(void);
extern INT16U gb32960_can_get_total_dianliu(void);
extern INT16U gb32960_can_get_total_dianya(void);


//����״̬
extern INT8U gb32960_can_get_car_status(void);
extern INT8U gb32960_can_get_charge_status(void);
extern INT8U gb32960_can_get_dianchi_cnt(void);

extern void gb32960_can_set_max_sos_level(INT8U val);
extern INT8U gb32960_can_get_max_sos_level(void);
extern void gb32960_can_set_sos_flag_by_bit(INT8U whitch_bit,INT8U val);
extern void gb32960_can_set_sos_flag(INT32U val);
extern INT32U gb32960_can_get_sos_flag(void);

extern void gb32960_can_set_sos_test(INT8U val);

extern char *gb32960_get_car_status_str(INT8U val);
extern char *gb32960_get_charge_status_str(INT8U val);




//�ɼ�ʱ����
extern INT16U gb32960_get_caiji_time_inteval(void);

extern void gb32960_set_caiji_time_inteval(INT16U val);

extern INT8U gb32960_get_moni_enter_mq_flag(void);

extern void gb32960_set_moni_enter_mq_flag(INT8U val);



extern void gb32960_moni_data_proc(void);


extern INT32U get_sos_collect_time(void);

extern void set_sos_collect_time(INT32U val);

extern char is_car_xh(void);

extern void gb32960_proc(void);

extern void gb32960_ack_plat(INT8U linkid,void *pdat,unsigned int len);

extern void sddf_ack_plat(INT8U linkid,void *pdat,unsigned int len);

extern char is_usually_collect(void);

extern void gb32960_sos_proc(void (*p_collect_func)(void));

extern void d78_gb32960_sos_proc(void (*p_collect_func)(void));


extern void set_s_32960_zuocang_data_change(unsigned char val);

extern unsigned char get_s_32960_zuocang_data_change(void);

extern int get_send_18X4D0D5_times(void);

extern void set_send_18X4D0D5_times(int temp);

extern void set_collect_32960_acc_status(unsigned char val);

extern unsigned char get_collect_32960_acc_status(void);

void set_want_startup_status(INT8U val);

INT8U get_want_startup_status(void);

void set_want_lockdoor_status(INT8U val);

INT8U get_want_lockdoor_status(void);

void set_lockdoor_commond_flag(INT8U val);

INT8U get_lockdoor_commond_flag(void);

INT8U get_lose_power_fail_status(void);

void set_lose_power_fail_status(INT8U val);

void set_lock_door_fail_status(INT8U val);

INT8U get_lock_door_fail_status(void);

extern void set_bcm_online_status(unsigned char val);

extern unsigned char get_bcm_online_status(void);
#ifdef __cplusplus
}
#endif

#endif



