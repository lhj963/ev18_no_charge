#include "ningde_bms_ota.h"


typedef enum tagCAN_BMS_OTA_STEP
{
	CAN_BMS_OTA_NONE = 0,

	CAN_BMS_OTA_STEP_1,
	CAN_BMS_OTA_STEP_1_WAIT_ACK,

	CAN_BMS_OTA_STEP_2,
	CAN_BMS_OTA_STEP_2_WAIT_ACK,


	CAN_BMS_OTA_STEP_3,
	CAN_BMS_OTA_STEP_3_WAIT_ACK,


	CAN_BMS_OTA_STEP_4,
	CAN_BMS_OTA_STEP_4_WAIT_ACK,


	CAN_BMS_OTA_STEP_5,
	CAN_BMS_OTA_STEP_5_WAIT_ACK,


	CAN_BMS_OTA_STEP_6,
	CAN_BMS_OTA_STEP_6_WAIT_ACK,


	CAN_BMS_OTA_STEP_7,
	CAN_BMS_OTA_STEP_7_WAIT_ACK,


	CAN_BMS_OTA_STEP_8,
	CAN_BMS_OTA_STEP_8_WAIT_ACK,

	CAN_BMS_OTA_STEP_9,
	CAN_BMS_OTA_STEP_9_WAIT_ACK,

	CAN_BMS_OTA_STEP_10,
	CAN_BMS_OTA_STEP_10_WAIT_ACK,

	CAN_BMS_OTA_STEP_11,
	CAN_BMS_OTA_STEP_11_WAIT_ACK,

	CAN_BMS_OTA_STEP_12,
	CAN_BMS_OTA_STEP_12_WAIT_ACK,

	CAN_BMS_OTA_STEP_13,
	CAN_BMS_OTA_STEP_13_WAIT_ACK,

	CAN_BMS_OTA_STEP_14,
	CAN_BMS_OTA_STEP_14_WAIT_ACK,

	CAN_BMS_OTA_STEP_15,
	CAN_BMS_OTA_STEP_15_WAIT_ACK,

	CAN_BMS_OTA_STEP_16,
	CAN_BMS_OTA_STEP_16_WAIT_ACK,

	CAN_BMS_OTA_STEP_17,
	CAN_BMS_OTA_STEP_17_WAIT_ACK,

	CAN_BMS_OTA_STEP_18,
	CAN_BMS_OTA_STEP_18_WAIT_ACK,
}CAN_BMS_OTA_STEP;


typedef struct tagNDBMSOTA
{
	unsigned char channel;					//CANͨ��
	CAN_BMS_OTA_STEP ota_step;			//��ǰ����������
	unsigned long seed;						//��ȫ���ʵ�����

	unsigned char next_drv_bag_flag : 1;
	unsigned char next_app_bag_flag : 1;
	unsigned char drv_data_arrive_flag : 1;
	unsigned char app_data_arrive_flag : 1;

	unsigned int last_send_cmd_time;

	unsigned int drv_check_sum;				//�����ļ�checksum
	unsigned int app_check_sum;				//app�ļ�checksum

	unsigned int drv_offset;
	unsigned int app_offset;
	unsigned int drv_tx_len;
	unsigned int app_tx_len;

	unsigned int drv_cur_tx_len;
	unsigned int app_cur_tx_len;

	unsigned int drv_addr;					//������ַ
	unsigned int drv_len;
	unsigned int drv_bag_id;

	unsigned int app_addr;					//app��ַ
	unsigned int app_len;
	unsigned int app_bag_id;

	unsigned int transfer_max_len;			//һ������䳤��

	unsigned char buf[512];
}NDBMSOTA;

NDBMSOTA s_stNDBMSOTA = {0};


unsigned int get_sandian_bms_ota_step(void)
{
	return (unsigned int)(s_stNDBMSOTA.ota_step);
}

void sandian_bms_start_ota_step(unsigned int step,unsigned int drv_addr,unsigned int drv_len,unsigned int app_addr,unsigned int app_len)
{
	memset(&s_stNDBMSOTA,0,sizeof(s_stNDBMSOTA));

	s_stNDBMSOTA.ota_step = (CAN_BMS_OTA_STEP)step;

	s_stNDBMSOTA.drv_addr = drv_addr;
	s_stNDBMSOTA.drv_len = drv_len;
	s_stNDBMSOTA.app_addr = app_addr;
	s_stNDBMSOTA.app_len = app_len;	
}

void ningde_bms_transfer_file_proc(CanRxMsg *pMsg,unsigned int file_type,CAN_MCU_OTA_STEP next_step)
{
#if 0
	unsigned int canid = 0;
	unsigned int templen = 0;
	unsigned char dat[8] = {0};

	if (pMsg->IDE)
	{
		canid = pMsg->ExtId;
	}
	else
	{
		canid = pMsg->StdId;
	}


	if (file_type == 1)						//drv ����
	{
		if (s_stHCMCUOTA.drv_len == 0)
		{
			s_stHCMCUOTA.mcu_ota_step = next_step;
			return ;
		}

		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x04) && (pMsg->Data[1] == 0x74) && (pMsg->Data[2] == 0x20))
		{
			s_stHCMCUOTA.transfer_max_len = (pMsg->Data[3] << 8) + pMsg->Data[4];
			DBG_Print(LEVEL2,"onece max transfer len:%uByes\r\n",s_stHCMCUOTA.transfer_max_len);		//MCU��Ӧ����һ������䳤��
		
			if (s_stHCMCUOTA.transfer_max_len >= 512)
			{
				s_stHCMCUOTA.transfer_max_len = 512;
			}
			else if (s_stHCMCUOTA.transfer_max_len >= 256)
			{
				s_stHCMCUOTA.transfer_max_len = 256;
			}
		
			s_stHCMCUOTA.next_drv_bag_flag = 1;
			send_msg(S_MSG_GET_FILE_DATA,(void *)file_type,(void *)(s_stHCMCUOTA.drv_offset),(void *)(s_stHCMCUOTA.transfer_max_len));
			s_stHCMCUOTA.drv_offset += s_stHCMCUOTA.transfer_max_len;
		}
		
		if (s_stHCMCUOTA.transfer_max_len && (s_stHCMCUOTA.drv_tx_len < s_stHCMCUOTA.drv_len))
		{
			unsigned int i = 0;
		
			if ((canid == 0x7EE) && (pMsg->Data[1] == 0x76))
			{
				s_stHCMCUOTA.next_drv_bag_flag = 1;
		
				s_stHCMCUOTA.drv_tx_len += s_stHCMCUOTA.drv_cur_tx_len;
		
				if (s_stHCMCUOTA.drv_tx_len >= s_stHCMCUOTA.drv_len)											//������� �˳�
				{
					sandian_tx(s_stHCMCUOTA.channel,0x7E6,"\x01\x37\xFF\xFF\xFF\xFF\xFF\xFF",8);
		
					s_stHCMCUOTA.mcu_ota_step = next_step;
		
					DBG_Print(LEVEL2,"drv transfer finish\r\n");
					s_stHCMCUOTA.next_drv_bag_flag = 0;
					s_stHCMCUOTA.transfer_max_len = 0;
				}
			}
		
			if (s_stHCMCUOTA.next_drv_bag_flag && s_stHCMCUOTA.drv_data_arrive_flag)
			{
				s_stHCMCUOTA.next_drv_bag_flag = 0;
		
				if ((s_stHCMCUOTA.drv_len - s_stHCMCUOTA.drv_tx_len) <= 5)
				{
					s_stHCMCUOTA.drv_cur_tx_len = s_stHCMCUOTA.drv_len - s_stHCMCUOTA.drv_tx_len;
		
					dat[0] = s_stHCMCUOTA.drv_cur_tx_len + 2;
					dat[1] = 0x36;
					dat[2] = 0x01 + s_stHCMCUOTA.drv_bag_id;
					
					dat[3] = s_stHCMCUOTA.buf[0];								//data										
					dat[4] = s_stHCMCUOTA.buf[1];
					dat[5] = s_stHCMCUOTA.buf[2];
					dat[6] = s_stHCMCUOTA.buf[3];
					dat[7] = s_stHCMCUOTA.buf[4];
				}
				else
				{
					if ((s_stHCMCUOTA.drv_len - s_stHCMCUOTA.drv_tx_len) > s_stHCMCUOTA.transfer_max_len)
					{
						s_stHCMCUOTA.drv_cur_tx_len = s_stHCMCUOTA.transfer_max_len;
					}
					else
					{
						s_stHCMCUOTA.drv_cur_tx_len = s_stHCMCUOTA.drv_len - s_stHCMCUOTA.drv_tx_len;
					}
					
					dat[0] = ((s_stHCMCUOTA.drv_cur_tx_len + 2) >> 8) | 0x10;
					dat[1] = s_stHCMCUOTA.drv_cur_tx_len + 2;
					dat[2] = 0x36;
					dat[3] = 0x01 + s_stHCMCUOTA.drv_bag_id;
		
					dat[4] = s_stHCMCUOTA.buf[0];								//data										
					dat[5] = s_stHCMCUOTA.buf[1];
					dat[6] = s_stHCMCUOTA.buf[2];
					dat[7] = s_stHCMCUOTA.buf[3];
				}
		
				sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);
				s_stHCMCUOTA.drv_bag_id++;
			}
		
			if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
			{
				templen = 4;
				i = 0;
				while (templen < s_stHCMCUOTA.drv_cur_tx_len)
				{
					dat[0] = 0x20 + ((i+1) % 16);
					dat[1] = s_stHCMCUOTA.buf[4 + (i * 7) + 0];
					dat[2] = s_stHCMCUOTA.buf[4 + (i * 7) + 1];
					dat[3] = s_stHCMCUOTA.buf[4 + (i * 7) + 2];
					dat[4] = s_stHCMCUOTA.buf[4 + (i * 7) + 3]; 									
					dat[5] = s_stHCMCUOTA.buf[4 + (i * 7) + 4];
					dat[6] = s_stHCMCUOTA.buf[4 + (i * 7) + 5];
					dat[7] = s_stHCMCUOTA.buf[4 + (i * 7) + 6];
		
					sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);
		
					templen += 7;
					i++;
		
					//if ((i % 16) == 0) os_sleep(5);
				}
				
				s_stHCMCUOTA.drv_data_arrive_flag = 0;
				send_msg(S_MSG_GET_FILE_DATA,(void *)file_type,(void *)(s_stHCMCUOTA.drv_offset),(void *)(s_stHCMCUOTA.transfer_max_len));
				s_stHCMCUOTA.drv_offset += s_stHCMCUOTA.transfer_max_len;
			}
		}

	}
	else if (file_type == 2)
	{
		if (s_stHCMCUOTA.app_len == 0)
		{
			s_stHCMCUOTA.mcu_ota_step = next_step;
			return ;
		}

		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x04) && (pMsg->Data[1] == 0x74) && (pMsg->Data[2] == 0x20))
		{
			s_stHCMCUOTA.transfer_max_len = (pMsg->Data[3] << 8) + pMsg->Data[4];
			DBG_Print(LEVEL2,"onece max transfer len:%uByes\r\n",s_stHCMCUOTA.transfer_max_len);		//MCU��Ӧ����һ������䳤��
		
			if (s_stHCMCUOTA.transfer_max_len >= 512)
			{
				s_stHCMCUOTA.transfer_max_len = 512;
			}
			else if (s_stHCMCUOTA.transfer_max_len >= 256)
			{
				s_stHCMCUOTA.transfer_max_len = 256;
			}
		
			s_stHCMCUOTA.next_app_bag_flag = 1;
			send_msg(S_MSG_GET_FILE_DATA,(void *)file_type,(void *)(s_stHCMCUOTA.app_offset),(void *)(s_stHCMCUOTA.transfer_max_len));
			s_stHCMCUOTA.app_offset += s_stHCMCUOTA.transfer_max_len;
		}
		
		if (s_stHCMCUOTA.transfer_max_len && (s_stHCMCUOTA.app_tx_len < s_stHCMCUOTA.app_len))
		{
			unsigned int i = 0;
		
			if ((canid == 0x7EE) && (pMsg->Data[1] == 0x76))
			{
				s_stHCMCUOTA.next_app_bag_flag = 1;
		
				s_stHCMCUOTA.app_tx_len += s_stHCMCUOTA.app_cur_tx_len;

				if (s_stHCMCUOTA.app_tx_len >= s_stHCMCUOTA.app_len)											//������� �˳�
				{
					sandian_tx(s_stHCMCUOTA.channel,0x7E6,"\x01\x37\xFF\xFF\xFF\xFF\xFF\xFF",8);
		
					s_stHCMCUOTA.mcu_ota_step = next_step;
		
					DBG_Print(LEVEL2,"app transfer finish\r\n");
					s_stHCMCUOTA.next_app_bag_flag = 0;
					s_stHCMCUOTA.transfer_max_len = 0;
				}
			}
		
			if (s_stHCMCUOTA.next_app_bag_flag && s_stHCMCUOTA.app_data_arrive_flag)
			{
				s_stHCMCUOTA.next_app_bag_flag = 0;
		
				if ((s_stHCMCUOTA.app_len - s_stHCMCUOTA.app_tx_len) <= 5)
				{
					s_stHCMCUOTA.app_cur_tx_len = s_stHCMCUOTA.app_len - s_stHCMCUOTA.app_tx_len;
		
					dat[0] = s_stHCMCUOTA.app_cur_tx_len + 2;
					dat[1] = 0x36;
					dat[2] = 0x01 + s_stHCMCUOTA.app_bag_id;
					
					dat[3] = s_stHCMCUOTA.buf[0];								//data										
					dat[4] = s_stHCMCUOTA.buf[1];
					dat[5] = s_stHCMCUOTA.buf[2];
					dat[6] = s_stHCMCUOTA.buf[3];
					dat[7] = s_stHCMCUOTA.buf[4];
				}
				else
				{
					if ((s_stHCMCUOTA.app_len - s_stHCMCUOTA.app_tx_len) > s_stHCMCUOTA.transfer_max_len)
					{
						s_stHCMCUOTA.app_cur_tx_len = s_stHCMCUOTA.transfer_max_len;
					}
					else
					{
						s_stHCMCUOTA.app_cur_tx_len = s_stHCMCUOTA.app_len - s_stHCMCUOTA.app_tx_len;
					}
					
					dat[0] = ((s_stHCMCUOTA.app_cur_tx_len + 2) >> 8) | 0x10;
					dat[1] = s_stHCMCUOTA.app_cur_tx_len + 2;
					dat[2] = 0x36;
					dat[3] = 0x01 + s_stHCMCUOTA.app_bag_id;
		
					dat[4] = s_stHCMCUOTA.buf[0];								//data										
					dat[5] = s_stHCMCUOTA.buf[1];
					dat[6] = s_stHCMCUOTA.buf[2];
					dat[7] = s_stHCMCUOTA.buf[3];
				}

				sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);
				s_stHCMCUOTA.app_bag_id++;
			}
		
			if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
			{
				templen = 4;
				i = 0;
				while (templen < s_stHCMCUOTA.app_cur_tx_len)
				{
					dat[0] = 0x20 + ((i+1) % 16);
					dat[1] = s_stHCMCUOTA.buf[4 + (i * 7) + 0];
					dat[2] = s_stHCMCUOTA.buf[4 + (i * 7) + 1];
					dat[3] = s_stHCMCUOTA.buf[4 + (i * 7) + 2];
					dat[4] = s_stHCMCUOTA.buf[4 + (i * 7) + 3]; 									
					dat[5] = s_stHCMCUOTA.buf[4 + (i * 7) + 4];
					dat[6] = s_stHCMCUOTA.buf[4 + (i * 7) + 5];
					dat[7] = s_stHCMCUOTA.buf[4 + (i * 7) + 6];
		
					sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);
		
					templen += 7;
					i++;
		
					//if ((i % 16) == 0) os_sleep(5);
				}

				s_stHCMCUOTA.app_data_arrive_flag = 0;
				send_msg(S_MSG_GET_FILE_DATA,(void *)file_type,(void *)(s_stHCMCUOTA.app_offset),(void *)(s_stHCMCUOTA.transfer_max_len));
				s_stHCMCUOTA.app_offset += s_stHCMCUOTA.transfer_max_len;
			}
		}

	}
#endif
}


const unsigned int mask= 0xAAAAAAAA;
unsigned int ComputeKey(unsigned int seed, unsigned int mask)
{
	unsigned char key[4];
	unsigned int retKey;
	unsigned char i=0,j=0;
	unsigned char result=0x00;
	union
	{
		char byte[4];
		unsigned int wort;
	}seedlokal;

	seedlokal.wort = seed;
	if(seedlokal.byte[0]==0&&seedlokal.byte[1]==0)
	{
	/* Do Nothing*/
	}
	else
	{
		for(i=0;i<40;i++)
		{
			if(seedlokal.wort & 0x80000000)
			{
				seedlokal.wort = seedlokal.wort << 1;
				seedlokal.wort = seedlokal.wort ^ mask;
			}
			else
			{
				seedlokal.wort=seedlokal.wort<<1;
			}
		}
		for(i = 0; i < 4; i++)
		{
			result=0x00;
			j=0;
			for(; j<8; j++)
			{
				if(j<4)
				{
					result|=(seedlokal.byte[i]& (0x01 << (7-j) ) ) >> (7-2*j);
				}
				else
				{
					result|=(seedlokal.byte[i]& (0x01 << (7-j) ) ) << (2*j-7);
				}
			}
			key[3 - i] = result;
		}
	}
	retKey =((unsigned int)key[3] << 24) + ((unsigned int)key[2]<<16)+((unsigned int)key[1]<<8)+(unsigned int)key[0];
	return retKey;
}

void ningde_bms_ota_proc(char channel,CanRxMsg *pMsg)
{
	unsigned int canid = 0;
	unsigned char dat[8] = {0};

	if (pMsg->IDE)
	{
		canid = pMsg->ExtId;
	}
	else
	{
		canid = pMsg->StdId;
	}

	if (canid == 0x7C8)
	{
		s_stNDBMSOTA.channel = channel;
	}

	switch (s_stNDBMSOTA.ota_step)
	{
	case CAN_BMS_OTA_STEP_1:
	{
		sandian_tx(0,0x7C0,"\x02\x10\x03\xFF\xFF\xFF\xFF\xFF",8);
		//sandian_tx(1,0x7C0,"\x02\x10\x03\xFF\xFF\xFF\xFF\xFF",8);
		//sandian_tx(2,0x7C0,"\x02\x10\x03\xFF\xFF\xFF\xFF\xFF",8);
		s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_1_WAIT_ACK;
	}
	break;
	case CAN_BMS_OTA_STEP_1_WAIT_ACK:
	case CAN_BMS_OTA_STEP_2:
		if ((canid == 0x7C8) && (pMsg->Data[1] == 0x50) && (pMsg->Data[2] == 0x03))
		{
			sandian_tx(s_stNDBMSOTA.channel,0x7C0,"\x04\x31\x01\xFF\x02\xFF\xFF\xFF",8);
			s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_2_WAIT_ACK;
		}
	break;

	case CAN_BMS_OTA_STEP_2_WAIT_ACK:
	case CAN_BMS_OTA_STEP_3:
		//if ((canid == 0x7C8) && (pMsg->Data[1] == 0x71) && (pMsg->Data[2] == 0x01))
		{
			sandian_tx(s_stNDBMSOTA.channel,0x7C0,"\x02\x85\x02\xFF\xFF\xFF\xFF\xFF",8);
			s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_3_WAIT_ACK;
		}
	break;

	case CAN_BMS_OTA_STEP_3_WAIT_ACK:
	case CAN_BMS_OTA_STEP_4:
		if ((canid == 0x7C8) && (pMsg->Data[1] == 0xC5) && (pMsg->Data[2] == 0x02))
		{
			sandian_tx(s_stNDBMSOTA.channel,0x7C0,"\x03\x28\x03\x01\xFF\xFF\xFF\xFF",8);
			s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_4_WAIT_ACK;
		}
	break;


	case CAN_BMS_OTA_STEP_4_WAIT_ACK:
	case CAN_BMS_OTA_STEP_5:
		if ((canid == 0x7C8) && (pMsg->Data[1] == 0x68) && (pMsg->Data[2] == 0x03))
		{
			s_stNDBMSOTA.last_send_cmd_time = GetRunTime();

			sandian_tx(s_stNDBMSOTA.channel,0x7C0,"\x02\x10\x02\xFF\xFF\xFF\xFF\xFF",8);
			s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_5_WAIT_ACK;
		}
	break;

	case CAN_BMS_OTA_STEP_5_WAIT_ACK:
	case CAN_BMS_OTA_STEP_6:
		if ((canid == 0x7C8) && (pMsg->Data[1] == 0x50) && (pMsg->Data[2] == 0x02))
		{
			sandian_tx(s_stNDBMSOTA.channel,0x7C0,"\x02\x27\x09\xFF\xFF\xFF\xFF\xFF",8);		//��ȡ��ȫ��������
			s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_6_WAIT_ACK;
		}

		if ((GetRunTime() - s_stNDBMSOTA.last_send_cmd_time) >= 3)
		{
			//s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_5;
		}

	break;

	case CAN_BMS_OTA_STEP_6_WAIT_ACK:
	case CAN_BMS_OTA_STEP_7:
		if ((canid == 0x7C8) && (pMsg->Data[1] == 0x67) && (pMsg->Data[2] == 0x09))				//���Ͱ�ȫ��Կ
		{
			unsigned int temp = 0;

			DBG_Print(LEVEL2,"bms seed:%02X %02X %02X %02X\r\n",pMsg->Data[3],pMsg->Data[4],pMsg->Data[5],pMsg->Data[6]);
			s_stNDBMSOTA.seed = (pMsg->Data[3] << 24) + (pMsg->Data[4] << 16) + (pMsg->Data[5] << 8) +pMsg->Data[6];

			temp = ComputeKey(s_stNDBMSOTA.seed,mask);

			dat[0] = 0x06;
			dat[1] = 0x27;
			dat[2] = 0x0A;
			dat[3] = temp >> 24;
			dat[4] = temp >> 16;
			dat[5] = temp >> 8;
			dat[6] = temp;
			dat[7] = 0xFF;

			sandian_tx(s_stNDBMSOTA.channel,0x7C0,dat,8);

			s_stNDBMSOTA.ota_step = CAN_BMS_OTA_STEP_7_WAIT_ACK;
		}
	break;
#if 0

	case CAN_MCU_OTA_STEP_7_WAIT_ACK:
	case CAN_MCU_OTA_STEP_8:														//��������
		Bzip2_Start();
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x67) && (pMsg->Data[2] == 0x0A))
		{
			dat[0] = 0x10;
			dat[1] = 0x0B;
			dat[2] = 0x34;
			dat[3] = 0x00;
			dat[4] = 0x44;
			dat[5] = s_stHCMCUOTA.drv_addr >> 24;
			dat[6] = s_stHCMCUOTA.drv_addr >> 16;
			dat[7] = s_stHCMCUOTA.drv_addr >> 8;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);					//����֡ �ڴ��ַ+����
		}

		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
		{
			dat[0] = 0x21;
			dat[1] = s_stHCMCUOTA.drv_addr;
			dat[2] = s_stHCMCUOTA.drv_len >> 24;
			dat[3] = s_stHCMCUOTA.drv_len >> 16;
			dat[4] = s_stHCMCUOTA.drv_len >> 8;
			dat[5] = s_stHCMCUOTA.drv_len;
			dat[6] = 0xFF;
			dat[7] = 0xFF;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);					//����֡ �ڴ��ַ+����
			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_8_WAIT_ACK;
		}
	break;

	case CAN_MCU_OTA_STEP_8_WAIT_ACK:
	case CAN_MCU_OTA_STEP_9:
		huichuan_mcu_transfer_file_proc(pMsg,1,CAN_MCU_OTA_STEP_9_WAIT_ACK);		//�ֶ��ļ�����
	break;

	case CAN_MCU_OTA_STEP_9_WAIT_ACK:
	case CAN_MCU_OTA_STEP_10:																
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x77))
		{
			s_stHCMCUOTA.drv_check_sum = Bzip2_XOR();

			DBG_Print(LEVEL2,"drv transfer finish exit.checksum:%08X\r\n",s_stHCMCUOTA.drv_check_sum);

			dat[0] = 0x10;
			dat[1] = 0x08;
			dat[2] = 0x31;
			dat[3] = 0x01;
			dat[4] = 0xF0;
			dat[5] = 0x01;
			dat[6] = s_stHCMCUOTA.drv_check_sum >> 24;
			dat[7] = s_stHCMCUOTA.drv_check_sum >> 16;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);									//���������Լ��
		}

		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
		{
			dat[0] = 0x21;
			dat[1] = s_stHCMCUOTA.drv_check_sum >> 8;
			dat[2] = s_stHCMCUOTA.drv_check_sum;
			dat[3] = 0xFF;
			dat[4] = 0xFF;
			dat[5] = 0xFF;
			dat[6] = 0xFF;
			dat[7] = 0xFF;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);									//���������Լ��
			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_10_WAIT_ACK;
		}
	break;

	case CAN_MCU_OTA_STEP_10_WAIT_ACK:
	case CAN_MCU_OTA_STEP_11:
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x71) && (pMsg->Data[2] == 0x01) && (pMsg->Data[3] == 0xF0) && (pMsg->Data[4] == 0x01))
		{
			dat[0] = 0x10;
			dat[1] = 0x0D;
			dat[2] = 0x31;
			dat[3] = 0x01;
			dat[4] = 0xFF;
			dat[5] = 0x00;
			dat[6] = 0x44;
			dat[7] = s_stHCMCUOTA.app_addr >> 24;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);									//���������Լ��			
		}

		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
		{
			dat[0] = 0x21;
			dat[1] = s_stHCMCUOTA.app_addr >> 16;
			dat[2] = s_stHCMCUOTA.app_addr >> 8;
			dat[3] = s_stHCMCUOTA.app_addr;
			dat[4] = s_stHCMCUOTA.app_len >> 24;
			dat[5] = s_stHCMCUOTA.app_len >> 16;
			dat[6] = s_stHCMCUOTA.app_len >> 8;
			dat[7] = s_stHCMCUOTA.app_len;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);
			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_11_WAIT_ACK;
		}
	break;

	case CAN_MCU_OTA_STEP_11_WAIT_ACK:
	case CAN_MCU_OTA_STEP_12:
		Bzip2_Start();
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x71) && (pMsg->Data[2] == 0x01) && (pMsg->Data[3] == 0xFF))
		{
			dat[0] = 0x10;
			dat[1] = 0x0B;
			dat[2] = 0x34;
			dat[3] = 0x00;
			dat[4] = 0x44;
			dat[5] = s_stHCMCUOTA.app_addr >> 24;
			dat[6] = s_stHCMCUOTA.app_addr >> 16;
			dat[7] = s_stHCMCUOTA.app_addr >> 8;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);					//����֡ �ڴ��ַ+����
		}

		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
		{
			dat[0] = 0x21;
			dat[1] = s_stHCMCUOTA.app_addr;
			dat[2] = s_stHCMCUOTA.app_len >> 24;
			dat[3] = s_stHCMCUOTA.app_len >> 16;
			dat[4] = s_stHCMCUOTA.app_len >> 8;
			dat[5] = s_stHCMCUOTA.app_len;
			dat[6] = 0xFF;
			dat[7] = 0xFF;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);					//����֡ �ڴ��ַ+����
			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_12_WAIT_ACK;
		}
		
	break;

	case CAN_MCU_OTA_STEP_12_WAIT_ACK:
	case CAN_MCU_OTA_STEP_13:
		huichuan_mcu_transfer_file_proc(pMsg,2,CAN_MCU_OTA_STEP_13_WAIT_ACK);
	break;

	case CAN_MCU_OTA_STEP_13_WAIT_ACK:
	case CAN_MCU_OTA_STEP_14:
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x77))
		{
			s_stHCMCUOTA.app_check_sum = Bzip2_XOR();
			DBG_Print(LEVEL2,"app transfer finish exit.check sum:%08X\r\n",s_stHCMCUOTA.app_check_sum);

			dat[0] = 0x10;
			dat[1] = 0x08;
			dat[2] = 0x31;
			dat[3] = 0x01;
			dat[4] = 0xF0;
			dat[5] = 0x01;
			dat[6] = s_stHCMCUOTA.app_check_sum >> 24;
			dat[7] = s_stHCMCUOTA.app_check_sum >> 16;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);									//���������Լ��
		}


		if ((canid == 0x7EE) && (pMsg->Data[0] == 0x30))
		{
			dat[0] = 0x21;
			dat[1] = s_stHCMCUOTA.app_check_sum >> 8;
			dat[2] = s_stHCMCUOTA.app_check_sum;
			dat[3] = 0xFF;
			dat[4] = 0xFF;
			dat[5] = 0xFF;
			dat[6] = 0xFF;
			dat[7] = 0xFF;
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,dat,8);									//���������Լ��
			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_14_WAIT_ACK;
		}
	break;

	case CAN_MCU_OTA_STEP_14_WAIT_ACK:
	case CAN_MCU_OTA_STEP_15:
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x71) && (pMsg->Data[2] == 0x01) && (pMsg->Data[3] == 0xF0) && (pMsg->Data[4] == 0x01))
		{
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,"\x04\x31\x01\xFF\x01\xFF\xFF\xFF",8);	//���������Լ��

			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_15_WAIT_ACK;
		}
	break;

	case CAN_MCU_OTA_STEP_15_WAIT_ACK:
	case CAN_MCU_OTA_STEP_16:
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x71) && (pMsg->Data[2] == 0x01) && (pMsg->Data[3] == 0xFF) && (pMsg->Data[4] == 0x01))
		{
			DBG_Print(LEVEL1,"send mcu reset cmd\r\n");
			sandian_tx(s_stHCMCUOTA.channel,0x7E6,"\x02\x11\x01\xFF\xFF\xFF\xFF\xFF",8);	//ECU��λ

			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_16_WAIT_ACK;
		}
	break;
	case CAN_MCU_OTA_STEP_16_WAIT_ACK:
	case CAN_MCU_OTA_STEP_17:
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x51) && (pMsg->Data[2] == 0x01))
		{
			os_sleep(1500);

			sandian_tx(s_stHCMCUOTA.channel,0x7DF,"\x02\x10\x83\xFF\xFF\xFF\xFF\xFF",8);	//��ϻỰ����
			os_sleep(100);
			sandian_tx(s_stHCMCUOTA.channel,0x7DF,"\x03\x28\x80\x03\xFF\xFF\xFF\xFF",8);	//ͨѶ���� ����
			os_sleep(100);
			sandian_tx(s_stHCMCUOTA.channel,0x7DF,"\x02\x85\x81\xFF\xFF\xFF\xFF\xFF",8);	//����������

			sandian_tx(s_stHCMCUOTA.channel,0x7DF,"\x02\x10\x81\xFF\xFF\xFF\xFF\xFF",8);	//������ϻỰģʽ
			os_sleep(100);

			sandian_tx(s_stHCMCUOTA.channel,0x7E6,"\x04\x14\xFF\xFF\xFF\xFF\xFF\xFF",8);
			s_stHCMCUOTA.mcu_ota_step = CAN_MCU_OTA_STEP_17_WAIT_ACK;
		}
	break;

	case CAN_MCU_OTA_STEP_17_WAIT_ACK:
	case CAN_MCU_OTA_STEP_18:
		if ((canid == 0x7EE) && (pMsg->Data[1] == 0x54))
		{
			DBG_Print(LEVEL1,"sandian mcu ota finish\r\n");
		}

	break;
#endif

	default:break;
	}
}












