#ifndef __BACK_PLAT_UI_H__
#define __BACK_PLAT_UI_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct tagRecvCanMsg
{
	INT32U decs;		//������  
						//0-5bit:��
						//6-11bit:��
						//12-16bit:ʱ
						//17-21bit:��
						//22-25bit:��
						//26-29bit:�� (2020��Ϊ����)  0��ʾ2020�� 1��ʾ2021�� 2��ʾ2022��
						//30-31:CANͨ��
	CanRxMsg msg;
}RecvCanMsg;


extern unsigned int get_heart_beat_time_interval(void);
extern void set_heart_beat_time_interval(unsigned int val);
extern void set_report_can_raw_sw(unsigned char val);
extern void report_to_server_temp(unsigned char can_channel,CanRxMsg *prxmsg);





extern void server4_connect_ok(void);
extern void link4_data_arrive(void *pdat,unsigned int rlen);
extern void server4_connected(void);

extern void remote_log(void *pdat,unsigned int datlen);

#if 1
extern void server_test_connect_ok(void);
extern void link_test_data_arrive(void *pdat,unsigned int rlen);
extern void server_test_connected(void);
#endif

#ifdef __cplusplus
}
#endif

#endif


