#include "usercmd.h"


typedef int (*SystemCmdFunc)(void *content,unsigned int contentlen,void *outbuf,unsigned int outbuflen);


/* �û�ָ��ṹ�� */
typedef struct tagSystemCommand
{
	void *pCmd;				//ָ������
	SystemCmdFunc pFunc;	//ִ����Ӧ�ĺ���
	char *pTip;
}SystemCommand;

int Cmd_Help(void *pArg,INT32U len,void *pOut,INT32U outlen);


int Cmd_GetSoftwareVersion(void *content,unsigned int contentlen,void *pOut,unsigned int outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Software Version:%s Compile @ %s %s\r\n",APP_VERSION,__TIME__,__DATE__);
	if (pOut)
	{
		rlen = snprintf(pOut,outlen,"Software Version:%s Compile @ %s %s\r\n",APP_VERSION,__TIME__,__DATE__);
	}

	return rlen;
}

/**************************************************************************
* ��  ��: int Cmd_DefaultDevice(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: �ָ���������
* ��  ��: ATRST
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*	      INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
int Cmd_DefaultDevice(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0, "Factory Device Start...\r\n");
	//empty_acce_store_block();
	UserParamDefault();
	DBG_Print(LEVEL0,"Factory Device Finish.\r\n");
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen, "Factory Device Finish");
	}

	return rlen;
}


#if 0
unsigned int Cmd_Execute_Mdm(void *content,unsigned int contentlen,void *pOut,unsigned int outlen)
{
	char *ptr = (char *)content;
	char cmd[128] = {0};
	int rlen = 0;

	ptr[contentlen] = 0;
	DBG_Print(0,"send to mdm(%u):\r\n",contentlen);
	DBG_Print(0,"%s",(char *)content);

	rlen = snprintf(cmd,sizeof(cmd),"%s\r",(char *)content);
	usart1_send_data(cmd,rlen);
	
	return 0;
}

static unsigned int s_val = 0;

unsigned int get_test_val(void)
{
	return s_val;
}

void set_test_val(unsigned int val)
{
	s_val = val;
}


unsigned int Cmd_Test(void *content,unsigned int contentlen,void *pOut,unsigned int outlen)
{
	CanRxMsg msg;
	char *ptr = (char *)content;
	unsigned int a = 0;
	unsigned int b = 0;

	if (strstr(ptr,"store"))
	{
		a = cpu_clock();
		StoreOneData(0,&msg,sizeof(msg));
		b = cpu_clock();
		
		DBG_Print(0,"store take time:%u\r\n",(b - a) / 75);

	}
	//set_test_val(atoi(ptr));
	//DBG_Print(0,"set test val:%u\r\n",atoi(ptr));

	return 0;
}


unsigned int Cmd_GetRtc(void *pArg,unsigned int len,void *pOut,unsigned int outlen)
{
	pcf8563_read_rtc();

	DBG_Print(LEVEL0,"<RTC:%04d-%02d-%02d %02d:%02d:%02d>\r\n",
	pcf8563_get_year()+2000,pcf8563_get_month(),pcf8563_get_day(),
	pcf8563_get_hour(),pcf8563_get_min(),pcf8563_get_sec());

	return snprintf((char *)pArg,outlen,"Get RTC:%04d-%02d-%02d %02d:%02d:%02d\r\n",
	pcf8563_get_year()+2000,pcf8563_get_month(),pcf8563_get_day(),
	pcf8563_get_hour(),pcf8563_get_min(),pcf8563_get_sec()
	);
}

unsigned int cmd_gprs(void *pArg,unsigned int len,void *pOut,unsigned int outlen)
{
	unsigned char *ptr = (unsigned char *)pArg;

	DBG_Print(LEVEL0,"send to mdm(%u):%s\r\n",strlen((char *)ptr),ptr);
	usart1_send_data(ptr,strlen((char *)ptr));
	return 0;
}



unsigned int Cmd_SetRtc(void *pArg,unsigned int len,void *pOut,unsigned int outlen)
{
	//20180831153033
	INT16U year;
	INT8U dat[5];
	INT8U i = 0;
	char temp[5] = {0};
	char *ptr = (char *)pArg;
	INT8U rlen = 0;

	DBG_Print(LEVEL0,"Set RTC:%s\r\n",(char *)pArg);

	memset(temp,0,sizeof(temp));
	memcpy(temp,ptr + rlen,4);
	rlen += 4;
	year = atoi(temp);

	for (i = 0; i < 5; i++)
	{
		memset(temp,0,sizeof(temp));
		memcpy(temp,ptr + rlen,2);
		rlen += 2;
		dat[i] = atoi(temp);
	}

	//DBG_Print(0,"%d %d %d %d %d %d\r\n",year,dat[0],dat[1],dat[2],dat[3],dat[4]);
	//RTC_Set(year,dat[0],dat[1],dat[2],dat[3],dat[4]);
	pcf8563_set_rtc(year,dat[0],dat[1],dat[2],dat[3],dat[4]);
	if (pOut)
	{
		return snprintf((char *)pOut,len,"Set RTC:%s OK.\r\n",(char *)pArg);
	}
	return 0;
}



#define _SET_BIT(val,bit_no) val |= (1 << bit_no)
#define _CLR_BIT(val,bit_no) val &= (~(1 << bit_no))

/**
��0λ��ʾ:SIM������״̬ 0��ʾδ���� 1��ʾ�Ѳ���
��1λ��ʾ�Ƿ�����ƽ̨��־ 0��ʾδ���� 1��ʾ������
��2λ��ʾACC״̬ 0��ʾOFF  1��ʾON
��3λ��ʾFLASH�Ƿ�OK 0��ʾ��OK  1��ʾOK
4-31λ���� ����
*/
INT32U _get_sw_status(void)
{
	INT32U ret = 0;

	if (GetNetStatus(0) >= SIM_READY)
	{
		_SET_BIT(ret,0);
	}
	else
	{
		_CLR_BIT(ret,0);
	}

	if (IsConnectServerOk(0))
	{
		_SET_BIT(ret,1);
	}
	else
	{
		_CLR_BIT(ret,1);
	}

	if (1)
	{
		_SET_BIT(ret,2);
	}
	else
	{
		_CLR_BIT(ret,2);
	}

	if (is_spi_flash_ok())
	{
		_SET_BIT(ret,3);
	}
	else
	{
		_CLR_BIT(ret,3);
	}

	return ret;
}



unsigned int get_status(void *pOutBuf,unsigned int outbuflen)
{
	INT8U *rxbuf = (INT8U *)pOutBuf;
	INT16U len = 0;
	INT32U ulRunTime = 0;
	INT16U usMainPowerVoltage = 0;
	INT16U usBatVoltage = 0;
	INT16U temp = 0;
	INT32U lonlat = 0;
	INT8U lonlatflag = 0;
	char *ptr = 0;

	if ((pOutBuf == 0) || (outbuflen == 0))
	{
		return 0;
	}

	
	ulRunTime = GetRunTime();
	usMainPowerVoltage = get_main_power_vol();
	usBatVoltage = get_bat_power_vol();

	//�豸rtcʱ��
	rxbuf[len++] = pcf8563_get_year();
	rxbuf[len++] = pcf8563_get_month();
	rxbuf[len++] = pcf8563_get_day();
	rxbuf[len++] = pcf8563_get_hour();
	rxbuf[len++] = pcf8563_get_min();
	rxbuf[len++] = pcf8563_get_sec();

	//�豸����ʱ��
	rxbuf[len++] = ulRunTime >> 24;
	rxbuf[len++] = ulRunTime >> 16;
	rxbuf[len++] = ulRunTime >> 8;
	rxbuf[len++] = ulRunTime;

	//����Դ��ѹ
	rxbuf[len++] = usMainPowerVoltage >> 8;
	rxbuf[len++] = usMainPowerVoltage;

	//��ص�ѹ
	rxbuf[len++] = usBatVoltage >> 8;
	rxbuf[len++] = usBatVoltage;

	//CPU�ڲ�Flash��С
	temp = 512;
	rxbuf[len++] = temp >> 8;
	rxbuf[len++] = temp;

	//CPU���к�
	rxbuf[len++] = 12;
	//GetCpuID(rxbuf + len,outbuflen - len);
	
	len += 12;

	//�Ƿ�λ
	rxbuf[len++] = IsPosition();

	//GpsGetLonInfo(&lonlat, &lonlatflag);

	lonlat = GetLong();
	
	//������
	rxbuf[len++] = GetEW();
	//����
	rxbuf[len++] = lonlat >> 24;
	rxbuf[len++] = lonlat >> 16;
	rxbuf[len++] = lonlat >> 8;
	rxbuf[len++] = lonlat;

	//GpsGetLatInfo(&lonlat, &lonlatflag);
	lonlat = GetLat();

	//�ϱ�γ
	rxbuf[len++] = GetNS();
	//γ��
	rxbuf[len++] = lonlat >> 24;
	rxbuf[len++] = lonlat >> 16;
	rxbuf[len++] = lonlat >> 8;
	rxbuf[len++] = lonlat;


	//�����汾��
	rxbuf[len++] = strlen(APP_VERSION);
	memcpy(rxbuf + len,APP_VERSION,strlen(APP_VERSION));
	len += strlen(APP_VERSION);

	//��������
	rxbuf[len++] = strlen(__DATE__) + strlen(__TIME__) + 1;
	memcpy(rxbuf + len,__DATE__,strlen(__DATE__));
	len += strlen(__DATE__);
	rxbuf[len++] = ' ';
	memcpy(rxbuf + len,__TIME__,strlen(__TIME__));
	len += strlen(__TIME__);

	//ͨ��ģ���Ƿ����
	rxbuf[len++] = GPRS_MD_GetModemExistFlag();
	//GPSģ���Ƿ����
	rxbuf[len++] = GetGPSExistFlag();

	//״̬λ
	rxbuf[len++] = _get_sw_status() >> 24;
	rxbuf[len++] = _get_sw_status() >> 16;
	rxbuf[len++] = _get_sw_status() >> 8;
	rxbuf[len++] = _get_sw_status();

	//��λ����
	rxbuf[len++] = GetStartNum();
	//SIM���ź�ǿ��
	rxbuf[len++] = GetCsq();
	//GPS����״̬
	rxbuf[len++] = (unsigned char)gps_get_ant_status();

	//SN��
	//SysGetSnNumber((char *)rxbuf + len + 1);
	ptr = GetSN();
	temp = (strlen(ptr) >= MAX_SN_LEN) ? MAX_SN_LEN : strlen(ptr);
	memcpy(rxbuf+len+1,ptr,temp);

	rxbuf[len++] = temp;

	len += temp;

	return len;
}

INT8U XOR_Check1(INT8U *pdat,INT32U len)
{
	INT32U i = 0;
	INT8U temp = pdat[0];

	if (len == 1) return pdat[0];
	
	for (i = 1; i < len; i++)
	{
		temp ^= pdat[i];
	}
	return temp;
}


void ReportStatus(void)
{
	unsigned char *ptr = 0;
	unsigned int len = 0;

	ptr = lfos_mem_malloc(1);

	if (ptr == 0) return ;

	//״̬�㱨��ʼ��־
	ptr[0] = 0xAA;
	ptr[1] = 0xBB;
	ptr[2] = 0xCC;
	ptr[3] = 0xDD;

	len = get_status(ptr + 4,lfos_mem_get_block_size(1) - 4);

	//xorУ��
	ptr[len + 4] = XOR_Check1(ptr,len+4);

	DBG_SendData(ptr,len+5);


	lfos_mem_free(1,ptr);
	
}


unsigned int Cmd_SetReportStatusSw(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	int flag = atoi((char *)pArg);

	SetReportStatus(flag);
	if (pOut)
	{
		rlen = snprintf(pOut,outlen,"Set report status switch:%d", flag);
	}
	DBG_Print(LEVEL0,"Set report status switch:%d\r\n", flag);
	return rlen;
}


unsigned int Cmd_GetVin(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	char *vin = 0;

	vin = GetVIN();
	DBG_Print(LEVEL0,"<VIN:%s>\r\n", vin);
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"VIN:%s", vin);
	}

	return rlen;
}

unsigned int Cmd_SetVin(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	char *vin = (char *)pArg;

	SetVIN(vin);
	DBG_Print(LEVEL0,"Set Vin:%s\r\n", vin);
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set Vin:%s OK", vin);
	}
	return rlen;
}

/**************************************************************************
* ��  ��: int Cmd_GetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ��ȡSN���к�
* ��  ��: ATSN?
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*	      INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
unsigned int Cmd_GetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	char *sn = 0;

	sn = GetSN();
	DBG_Print(LEVEL0, "Get <SN:%s>\r\n", sn);	
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get SN:%s", sn);
	}

	return rlen;
}

/**************************************************************************
* ��  ��: int Cmd_SetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ����SN���к�
* ��  ��: ATSN=XXXXXXXXXXXXXXXXXXXXXX
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*	      INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
unsigned int Cmd_SetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Set SN:%s\r\n", (char *)pArg);
	SetSN((char *)pArg);
	if (pOut)
	{
		rlen = snprintf((char *)pOut, outlen, "Set SN:%s", (char *)pArg);
	}

	return rlen;
}



int set_ip(char idx,void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	char *ipDomain = pArg;
	
	SPSetServerAddr(idx,pArg);
	if (idx == 0)
	{
		DBG_Print(LEVEL0,"<FIRSTIP:%s>\r\n", ipDomain);
		return snprintf((char *)pOut,outlen,"FIRSTIP:%s", ipDomain);
	}
	else if (idx == 1)
	{
		DBG_Print(LEVEL0,"<SECONDIP:%s>\r\n", ipDomain);
		return snprintf((char *)pOut,outlen,"SECONDIP:%s", ipDomain);
	}
	else if (idx == 2)
	{
		DBG_Print(LEVEL0,"<THIRDIP:%s>\r\n", ipDomain);
		return snprintf((char *)pOut,outlen,"THIRDIP:%s",ipDomain);
	}
	return 0;
}

int set_port(char idx,void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	INT16U port = 0;

	if (pArg == 0) return 0;
	port = atoi((char *)pArg);

	SPSetServerPort(idx,port);

	if (idx == 0)
	{
		DBG_Print(LEVEL0,"<FIRSTPORT:%d>\r\n", port);
		return snprintf((char *)pOut,outlen,"FIRSTPORT:%d", port);
	}
	else if (idx == 1)
	{
		DBG_Print(LEVEL0,"<SECONDPORT:%d>\r\n", port);
		return snprintf((char *)pOut,outlen,"SECONDPORT:%d", port);
	}
	else if (idx == 2)
	{
		DBG_Print(LEVEL0,"<THIRDPORT:%d>\r\n", port);
		return snprintf((char *)pOut,outlen,"THIRDPORT:%d",port);
	}
	return 0;
}


unsigned int Cmd_SetFirstIP(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_ip(0,pArg,len,pOut,outlen);
}

unsigned int Cmd_SetSecondIP(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_ip(1,pArg,len,pOut,outlen);
}

unsigned int Cmd_SetThirdIP(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_ip(2,pArg,len,pOut,outlen);
}


unsigned int Cmd_SetFirstPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_port(0,pArg,len,pOut,outlen);
}

unsigned int Cmd_SetSecondPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_port(1,pArg,len,pOut,outlen);
}

unsigned int Cmd_SetThirdPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_port(2,pArg,len,pOut,outlen);
}


static unsigned int Cmd_GetPlat(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	
	DBG_Print(LEVEL0,"<FIRSTIP:%s><FIRSTPORT:%u>"
	"<SECONDIP:%s><SECONDPORT:%u>"
	"<THIRDIP:%s><THIRDPORT:%u>"
	"\r\n",
	SPGetServerAddr(0), SPGetServerPort(0),
	SPGetServerAddr(1), SPGetServerPort(1),
	SPGetServerAddr(2), SPGetServerPort(2)
	);

	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"<FIRSTIP:%s><FIRSTPORT:%u>"
		"<SECONDIP:%s><SECONDPORT:%u>"
		"<THIRDIP:%s><THIRDPORT:%u>"
		"\r\n",
		SPGetServerAddr(0), SPGetServerPort(0),
		SPGetServerAddr(1), SPGetServerPort(1),
		SPGetServerAddr(2), SPGetServerPort(2)
		);

	}
	return rlen;
}




unsigned int Cmd_SetCan1Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned int bps = atoi((char *)pArg);

	DBG_Print(LEVEL0,"Set CAN1 Bps:%u\r\n", bps);
	SetCan0Bps(bps);
	can0_init(bps);

	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set CAN1 Bps:%u", bps);
	}

	return rlen;
}

unsigned int Cmd_GetCan1Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Get CAN1 Bps:%u\r\n", GetCan0Bps());
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get CAN1 Bps:%u", GetCan0Bps());
	}

	return rlen;
}

unsigned int Cmd_SetCan2Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned int bps = atoi((char *)pArg);

	DBG_Print(LEVEL0,"Set CAN2 Bps:%u\r\n", bps);

	SetCan2Bps(bps);
	can2_init(bps);

	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set CAN2 Bps:%u", bps);
	}

	return rlen;
}

unsigned int Cmd_GetCan2Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Get CAN2 Bps:%u\r\n", GetCan2Bps());
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get CAN2 Bps:%u", GetCan2Bps());
	}

	return rlen;
}

unsigned int Cmd_SetCan3Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned int bps = atoi((char *)pArg);

	DBG_Print(LEVEL0,"Set CAN3 Bps:%u\r\n", bps);
	SetCan1Bps(bps);
	can1_init(bps);

	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set CAN3 Bps:%u", bps);
	}

	return rlen;
}

unsigned int Cmd_GetCan3Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Get CAN3 Bps:%u\r\n", GetCan1Bps());
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get CAN3 Bps:%u", GetCan1Bps());
	}

	return rlen;
}
#endif


int Cmd_Test(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return 0;
}

int Cmd_SetApn(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;


	SPSetApn((char *)pArg);
	if (pOut)
	{
		rlen = snprintf((char *)pOut, outlen, "Set APN:%s", (char *)pArg);
	}


	DBG_Print(LEVEL0,"set apn:%s\r\n",SPGetApn());
	return rlen;
}

int Cmd_GetApn(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;
	char *apn = 0;

	apn = SPGetApn();
	DBG_Print(LEVEL0,"Get APN:%s user:%s password:%s\r\n", apn,SPGetApnUsername(),SPGetApnPassword());
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get APN:%s user:%s password:%s",
		apn,SPGetApnUsername(),SPGetApnPassword());
	}

	return rlen;
}

int Cmd_SetApnUser(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Set APN User:%s\r\n",(char *)pArg);

	SPSetApnUsername((char *)pArg);
	if (pOut)
	{
		rlen = snprintf((char *)pOut, outlen, "Set APN User:%s", SPGetApnUsername());
	}

	return rlen;
}


int Cmd_SetApnPsw(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;

	DBG_Print(LEVEL0,"Set APN Password:%s\r\n",(char *)pArg);

	SPSetApnPassword((char *)pArg);
	if (pOut)
	{
		rlen = snprintf((char *)pOut, outlen, "Set APN Password:%s", SPGetApnPassword());
	}

	return rlen;
}


int Cmd_GetPlat(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return 0;
}

int Cmd_SetVin(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned rlen = 0;

	SetVIN((char *)pArg);
	send_msg(S_MSG_SEND_PARAM_TO_MPU,GetVIN(),(void *)17,0);
	DBG_Print(LEVEL0,"Set VIN:%s\r\n",(char *)pArg);
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set VIN:%s\r\n",GetVIN());
	}
	return rlen;
}

int Cmd_GetVin(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;

	DBG_Print(0,"<VIN:%s><canvin:%s>\r\n",GetVIN(),can_get_vin_ptr(0));
	if (pOut && outlen)
	{
		rlen = snprintf(pOut,outlen,"<VIN:%s><canvin:%s>",GetVIN(),can_get_vin_ptr(0));
	}
	return rlen;
}


int Cmd_GetInfo(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;
	unsigned char *pt = get_dst_time_when_network_error();
	unsigned char *sc_date = get_sc_date();

	rlen = disp_sysparam(pOut,outlen);

	if (pOut && outlen)
	{
		rlen += snprintf((char *)pOut + rlen,outlen - rlen,
						"(df)bind_pro_lock:(fact)%02X_%02X_%02X (want)%02X_%02X_%02X "
						"%u sos:%08X %u %02X flg:%d\r\n"
						"(dst)b_pro_lock:(fact)%02X_%02X_%02X (want)%02X_%02X_%02X "
						"c_l_k:(fact)%02X_%02X_%02X (want)%02X_%02X_%02X tip:%d_%d_%d where:%d,%d,%u,%u,%02d-%02d-%02d %02d:%02d:%02d %u d78:%u %u(0.01kwh)\r\n"
						"%u %u %u(%02u%02u%02u%02u%02u%02u)\r\n",
						get_fact_bind_status(),get_fact_pro_ver_about_lock(),get_fact_lock_status(),
						get_want_bind_status(),get_want_pro_ver_about_lock(),get_want_lock_status(),
						get_electric_car_class(),gb32960_can_get_sos_flag(),gb32960_can_get_max_sos_level(),get_test_step(),gb32960_can_get_sos_test(),

						get_dst_fact_bind_status(),get_dst_fact_pro_ver_about_lock(),get_dst_fact_lock_status(),0,get_dst_want_pro_ver_about_lock(),get_dst_want_lock_status(),

						get_dst_fact_bms_charge_flag(),get_dst_fact_limit_speed_level(),get_dst_fact_kucunrong_limit_speed(),
						get_dst_want_bms_charge_flag(),get_dst_want_limit_speed_level(),get_dst_want_kucunrong_limit_speed(),
						get_dst_keep_fit_tip_flag(),get_dst_pay_tip_flag(),get_dst_inspect_tip_flag(),get_lock_car_cmd_from_where(),
						get_dst_network_error_flag(),get_dst_network_error_tip_flag(),get_dst_milage_when_network_error(),pt[0],pt[1],pt[2],pt[3],pt[4],pt[5],get_dst_net_error_accumulate_time_tmp(),
						get_d78_huandian_ver(),_get_dst_charge_dl(),get_dst_chemen_switch(),get_dst_chesuo_switch(),get_dst_left_qian_chesuo_switch(),
						sc_date[0],sc_date[1],sc_date[2],sc_date[3],sc_date[4],sc_date[5]
						);

	}

	DBG_Print(LEVEL0,
					"(df)bind_pro_lock:(fact)%02X_%02X_%02X (want)%02X_%02X_%02X "
					"%u sos:%08X %u %02X flg:%d\r\n"
					"(dst)b_pro_lock:(fact)%02X_%02X_%02X (want)%02X_%02X_%02X "
					"c_l_k:(fact)%02X_%02X_%02X (want)%02X_%02X_%02X tip:%d_%d_%d where:%d,%d,%u,%02d-%02d-%02d %02d:%02d:%02d\r\n",
					get_fact_bind_status(),get_fact_pro_ver_about_lock(),get_fact_lock_status(),
					get_want_bind_status(),get_want_pro_ver_about_lock(),get_want_lock_status(),
					get_electric_car_class(),gb32960_can_get_sos_flag(),gb32960_can_get_max_sos_level(),get_test_step(),gb32960_can_get_sos_test(),
	
					get_dst_fact_bind_status(),get_dst_fact_pro_ver_about_lock(),get_dst_fact_lock_status(),0,get_dst_want_pro_ver_about_lock(),get_dst_want_lock_status(),
	
					get_dst_fact_bms_charge_flag(),get_dst_fact_limit_speed_level(),get_dst_fact_kucunrong_limit_speed(),
					get_dst_want_bms_charge_flag(),get_dst_want_limit_speed_level(),get_dst_want_kucunrong_limit_speed(),
					get_dst_keep_fit_tip_flag(),get_dst_pay_tip_flag(),get_dst_inspect_tip_flag(),get_lock_car_cmd_from_where(),
					get_dst_network_error_flag(),get_dst_milage_when_network_error(),pt[0],pt[1],pt[2],pt[3],pt[4],pt[5]
					);
	return rlen;
}

/**************************************************************************
* ��  ��: int Cmd_GetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ��ȡSN���к�
* ��  ��: ATSN?
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*	      INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
int Cmd_GetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	char *sn = 0;

	sn = GetSN();
	DBG_Print(LEVEL0, "Get <SN:%s>\r\n", sn);	
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get SN:%s", sn);
	}
	return rlen;
}

/**************************************************************************
* ��  ��: int Cmd_GetPubKey(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ��ȡ����оƬ�Ĺ�Կ
* ��  ��: ATPUBKEY?
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*		  INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
static int Cmd_GetPubKey(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned char key[66] = {0};

	//sm2_chip_read_public_key(key,sizeof(key));
	send_msg(S_MSG_GET_PUBLIC_KEY,key,(void *)66,0);

	DBG_PrintBuf(LEVEL0, "Get Pub Key:\r\n", key, 64);

	if (pOut)
	{
		rlen = ArrayToHexStr1(key,64,pOut,outlen);	
	}

	return rlen;	
}

/**************************************************************************
* ��  ��: int Cmd_SetChipId(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ���ü���оƬ��ID
* ��  ��: ATCHIPID=xxxx //�����Ϊ16���ֽ�
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*		  INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
static int Cmd_SetChipId(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned char *pdata = (unsigned char *)pArg;

	if (len <= 16)
	{
		SysSetChipId(pdata, len);

		DBG_PrintBuf(0, "Set ChipId Successful:\r\n", pdata, len);
		if (pOut)
		{
			rlen = snprintf((char *)pOut, outlen, "Set ChipId Successful");
		}
	}

	return rlen;
}

/**************************************************************************
* ��  ��: int Cmd_GetChipId(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ��ȡ����оƬ��ID
* ��  ��: ATCHIPID?
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*		  INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
static int Cmd_GetChipId(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned char i = 0;
	char *pSms = (char *)pOut;
	unsigned char chipid[16] = {0};

	SysGetChipId(chipid);
	DBG_PrintBuf(0, "Get ChipId:\r\n", chipid, sizeof(chipid));
	if (pOut)
	{
		rlen += snprintf(pSms, outlen, "Get ChipId:");
		for (i = 0; i < 16; i++)
		{
			rlen += snprintf(&pSms[rlen], outlen - rlen, "%02x ", chipid[i]);
		}
	}

	return rlen;
}



/**************************************************************************
* ��  ��: int Cmd_SetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
* ��  ��: ����SN���к�
* ��  ��: ATSN=XXXXXXXXXXXXXXXXXXXXXX
* ��  ��: void *pArg: ָ��Ĳ���
*		  INT32U len: �����ĳ���
*	      INT32U outlen�������Ϣ����󳤶�
* ��  ��: void *pOut�������Ϣ
* ����ֵ: int:�����Ϣ��ʵ�ʳ���
**************************************************************************/
int Cmd_SetSn(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Set SN:%s\r\n", (char *)pArg);
	SetSN((char *)pArg);
	if (pOut)
	{
		rlen = snprintf((char *)pOut, outlen, "Set SN:%s", (char *)pArg);
	}

	return rlen;
}
int Cmd_SetCan1Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	int bps = atoi((char *)pArg);

	DBG_Print(LEVEL0,"Set CAN1 Bps:%u\r\n", bps);

	SetCan0Bps(bps);
	can_init(0,bps);
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set CAN1 Bps:%u", bps);
	}

	return rlen;
}

int Cmd_GetCan1Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Get CAN1 Bps:%u %u %u\r\n", GetCan0Bps(),GetCan1Bps(),GetCan2Bps());
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get CAN1 Bps:%u %u %u", GetCan0Bps(),GetCan1Bps(),GetCan2Bps());
	}

	return rlen;
}

int Cmd_SetCan2Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	int bps = atoi((char *)pArg);

	DBG_Print(LEVEL0,"Set CAN2 Bps:%u\r\n", bps);

	SetCan1Bps(bps);
	can_init(1,bps);
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Set CAN2 Bps:%u", bps);
	}

	return rlen;
}

int Cmd_GetCan2Bps(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;

	DBG_Print(LEVEL0,"Get CAN2 Bps:%u\r\n", GetCan1Bps());
	if (pOut)
	{
		rlen = snprintf((char *)pOut,outlen,"Get CAN2 Bps:%u", GetCan1Bps());
	}

	return rlen;
}


int set_ip(char idx,void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;

	SPSetServerAddr(idx,pArg);
	//connect_server(idx,SPGetServerAddr(idx),SPGetServerPort(idx),ServerLinkIsTcp(idx));

	if (idx == 0)
	{	
		DBG_Print(LEVEL0,"<FIRSTIP:%s>\r\n",SPGetServerAddr(0));
		if (pOut) rlen = snprintf((char *)pOut,outlen,"FIRSTIP:%s",SPGetServerAddr(0));
	}
	else if (idx == 1)
	{
		DBG_Print(LEVEL0,"<SECONDIP:%s>\r\n",SPGetServerAddr(1));
		if (pOut) rlen = snprintf((char *)pOut,outlen,"SECONDIP:%s",SPGetServerAddr(1));
	}
	else if (idx == 2)
	{
		DBG_Print(LEVEL0,"<THIRDIP:%s>\r\n",SPGetServerAddr(2));
		if (pOut) rlen = snprintf((char *)pOut,outlen,"THIRDIP:%s",SPGetServerAddr(2));
	}
	return rlen;
}

int set_port(char idx,void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	unsigned int rlen = 0;
	unsigned int port = atoi((char *)pArg);

	SPSetServerPort(idx,port);
	//connect_server(idx,SPGetServerAddr(idx),SPGetServerPort(idx),ServerLinkIsTcp(idx));

	if (idx == 0)
	{
		DBG_Print(LEVEL0,"<FIRSTPORT:%d>\r\n",port);
		if (pOut) rlen = snprintf((char *)pOut,outlen,"FIRSTPORT:%d",port);
	}
	else if (idx == 1)
	{
		DBG_Print(LEVEL0,"<SECONDPORT:%d>\r\n",port);
		if (pOut) rlen = snprintf((char *)pOut,outlen,"SECONDPORT:%d",port);
	}
	else if (idx == 2)
	{
		DBG_Print(LEVEL0,"<THIRDPORT:%d>\r\n",port);
		if (pOut) rlen = snprintf((char *)pOut,outlen,"THIRDPORT:%d",port);
	}
	return rlen;
}


int Cmd_SetFirstIP(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_ip(0,pArg,len,pOut,outlen);
}

int Cmd_SetSecondIP(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_ip(1,pArg,len,pOut,outlen);
}

int Cmd_SetThirdIP(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_ip(2,pArg,len,pOut,outlen);
}


int Cmd_SetFirstPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_port(0,pArg,len,pOut,outlen);
}

int Cmd_SetSecondPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_port(1,pArg,len,pOut,outlen);
}

int Cmd_SetThirdPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return set_port(2,pArg,len,pOut,outlen);
}

char *find_str_tail(void *ptr,void *tip)
{
	char *pRet = 0;
	if ((ptr == 0) || (tip == 0) || (strlen((char *)tip) == 0))
	{
		return 0;
	}

	pRet = strstr((char *)ptr,(char *)tip);
	if (pRet)
	{
		return (pRet + strlen((char *)tip));
	}
	return 0;
}

unsigned long real_idx = 0;
unsigned long mq_idx = 0;
unsigned long hb_idx = 0;
unsigned long loginout_idx = 0;

INT8U s_start_time[6] = {0};
INT8U s_end_time[6] = {0};

void export_print(unsigned long index,INT8U year,INT8U month,INT8U day,
											INT8U hour,INT8U min,INT8U sec,
											void *pbuf,unsigned int len)

{
}

void _export_print(unsigned long index,INT8U year,INT8U month,INT8U day,
											INT8U hour,INT8U min,INT8U sec,
											INT8U car_status,INT8U charge_status,INT16U speed,
											void *pbuf,unsigned int len)
{
}


void real_data_handler(unsigned long index,void * buf,unsigned int buflen)
{
	INT8U *pbuf = (INT8U *)buf;
	INT16U templen = 0;
	INT8U desTime[6] = {0};

	templen = (pbuf[0] << 8) + pbuf[1];
	if (templen < 1450)
	{
		desTime[0] = *(pbuf+3+24);
		desTime[1] = *(pbuf+3+25);
		desTime[2] = *(pbuf+3+26);
		desTime[3] = *(pbuf+3+27);
		desTime[4] = *(pbuf+3+28);
		desTime[5] = *(pbuf+3+29);
		if (is_between_time(desTime,s_start_time,s_end_time))
		{
			_export_print(real_idx,*(pbuf+3+24),*(pbuf+3+25),*(pbuf+3+26),
								*(pbuf+3+27),*(pbuf+3+28),*(pbuf+3+29),
								pbuf[3+31],pbuf[3+32],byte_to_int16u(pbuf[3+34],pbuf[3+35]),
						pbuf + 3,templen);
			real_idx++;
		}
	}
}

void mq_data_handler(unsigned long index,void * buf,unsigned int buflen)
{
	INT8U *pbuf = (INT8U *)buf;
	INT16U templen = 0;
	INT8U desTime[6] = {0};

	templen = (pbuf[0] << 8) + pbuf[1];
	if (templen < 1450)
	{
		desTime[0] = *(pbuf+3+24);
		desTime[1] = *(pbuf+3+25);
		desTime[2] = *(pbuf+3+26);
		desTime[3] = *(pbuf+3+27);
		desTime[4] = *(pbuf+3+28);
		desTime[5] = *(pbuf+3+29);
		if (is_between_time(desTime,s_start_time,s_end_time))
		{
			_export_print(mq_idx,*(pbuf+3+24),*(pbuf+3+25),*(pbuf+3+26),
								*(pbuf+3+27),*(pbuf+3+28),*(pbuf+3+29),
								pbuf[3+31],pbuf[3+32],byte_to_int16u(pbuf[3+34],pbuf[3+35]),
						pbuf + 3,templen);
			mq_idx++;
		}

	}
}

void heart_record_handler(unsigned long index,void * buf,unsigned int buflen)
{
	INT8U *pbuf = (INT8U *)buf;
	INT16U templen = 0;
	INT8U desTime[6] = {0};

	templen = (pbuf[0] << 8) + pbuf[1];
	if (templen < 250)
	{
		desTime[0] = *(pbuf+3+templen);
		desTime[1] = *(pbuf+3+templen + 1);
		desTime[2] = *(pbuf+3+templen + 2);
		desTime[3] = *(pbuf+3+templen + 3);
		desTime[4] = *(pbuf+3+templen + 4);
		desTime[5] = *(pbuf+3+templen + 5);
		if (is_between_time(desTime,s_start_time,s_end_time))
		{
			export_print(hb_idx,*(pbuf+3+templen),*(pbuf+3+templen+1),*(pbuf+3+templen + 2),
								*(pbuf+3+templen+3),*(pbuf+3+templen+4),*(pbuf+3+templen+5),
						pbuf + 3,templen);
			hb_idx++;

		}
	}
}

void loginout_record_handler(unsigned long index,void * buf,unsigned int buflen)
{
	INT8U *pbuf = (INT8U *)buf;
	INT16U templen = 0;
	INT8U desTime[6] = {0};

	templen = (pbuf[0] << 8) + pbuf[1];
	if (templen < 256)
	{
		desTime[0] = *(pbuf+3+24);
		desTime[1] = *(pbuf+3+25);
		desTime[2] = *(pbuf+3+26);
		desTime[3] = *(pbuf+3+27);
		desTime[4] = *(pbuf+3+28);
		desTime[5] = *(pbuf+3+29);
		if (is_between_time(desTime,s_start_time,s_end_time))
		{
			export_print(loginout_idx,*(pbuf+3+24),*(pbuf+3+25),*(pbuf+3+26),
								*(pbuf+3+27),*(pbuf+3+28),*(pbuf+3+29),
						pbuf + 3,templen);
			loginout_idx++;
		}
	}
}

//��ʱ��ε�������
void export_record_by_time(INT8U start_time[6],INT8U end_time[6])
{

}


int Cmd_Expand(void *pArg,unsigned int len,void *pOut,unsigned int outlen)
{
	char *ptr = (char *)pArg;
	char *ptemp = 0;
	//unsigned int a = 0;
	//unsigned int b = 0;
	char szTemp[256 + 1] = {0};
	char *pTemp = 0;
	char *pOutBuf = (char *)pOut;
	int ack_len = 0;
	unsigned int templen = 0;

	pOutBuf = pOutBuf;
	templen = templen;

	if (strstr(ptr,"recv_send_can:"))
	{
		if (strstr(ptr,"recv_send_can:1"))
		{
			set_recv_send_can_flag(1);
		}
		
		if (strstr(ptr,"recv_send_can:0"))
		{
			set_recv_send_can_flag(0);
		}
		DBG_Print(LEVEL2,"recv send can:%u\r\n",get_recv_send_can_flag());
		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"recv send can:%u\r\n",get_recv_send_can_flag());
	}

	if (strstr(ptr,"recvcan"))
	{
		CanTxMsg txmsg = {0};
		INT8U hex[4] = {0};
		
		//CAN ID
		GetSubString(ptr,":"," ",szTemp,16);
		if (strlen(szTemp) < 8)
		{
			//��0
			for (templen = 0; templen < (8 - strlen(szTemp)); templen++)
			{
				*(szTemp + 16 + templen) = '0';
			}
			memcpy(szTemp + 16 + templen,szTemp,strlen(szTemp));
		}
		else
		{
			memcpy(szTemp + 16,szTemp,8);
		}
		HexStrToArray((INT8U *)szTemp + 16,hex,4);
		templen = (hex[0] << 24) + (hex[1] << 16) + (hex[2] << 8) + hex[3];
		
		//CAN DATA
		ptemp = strstr((char *)pArg," ");
		if (ptemp)
		{
			HexStrToArray((INT8U *)ptemp + 1,(INT8U *)szTemp,32);
			memcpy(txmsg.Data,szTemp,8);
		}
		
		txmsg.DLC = 8;
		if (templen > 0x7FF)
		{
			txmsg.ExtId = templen;
			txmsg.IDE = CAN_ID_EXT;
		}
		else
		{
			txmsg.StdId = templen;
			txmsg.IDE = CAN_ID_STD;
		}
		
		txmsg.RTR = CAN_RTR_DATA;
		
		GetSubString(ptr,"recvcan",":",szTemp,16);
		//can_send_data(atoi(szTemp),&txmsg);

		can_data_in_queue(atoi(szTemp),(templen > 0x7FF) ? 1 : 0,templen,txmsg.Data,8);

		DBG_Print(LEVEL4,"[CAN%u]RX:%X %02X %02X %02X %02X %02X %02X %02X %02X\r\n",atoi(szTemp),
						templen,txmsg.Data[0],txmsg.Data[1],txmsg.Data[2],txmsg.Data[3],
						txmsg.Data[4],txmsg.Data[5],txmsg.Data[6],txmsg.Data[7]);
	}
	//�ֶ�����CAN���� 
	//ATEX=sendcan0:7DF 00 01 02 03 04 05 06 07
	//ATEX=sendcan0:18FE5201 00 01 02 03 04 05 06 07
	if (strstr(ptr,"sendcan"))
	{
		CanTxMsg txmsg = {0};
		INT8U hex[4] = {0};

		//CAN ID
		GetSubString(ptr,":"," ",szTemp,16);
		if (strlen(szTemp) < 8)
		{
			//��0
			for (templen = 0; templen < (8 - strlen(szTemp)); templen++)
			{
				*(szTemp + 16 + templen) = '0';
			}
			memcpy(szTemp + 16 + templen,szTemp,strlen(szTemp));
		}
		else
		{
			memcpy(szTemp + 16,szTemp,8);
		}
		HexStrToArray((INT8U *)szTemp + 16,hex,4);
		templen = (hex[0] << 24) + (hex[1] << 16) + (hex[2] << 8) + hex[3];

		//CAN DATA
		ptemp = strstr((char *)pArg," ");
		if (ptemp)
		{
			HexStrToArray((INT8U *)ptemp + 1,(INT8U *)szTemp,32);
			memcpy(txmsg.Data,szTemp,8);
		}

		txmsg.DLC = 8;
		if (templen > 0x7FF)
		{
			txmsg.ExtId = templen;
			txmsg.IDE = CAN_ID_EXT;
		}
		else
		{
			txmsg.StdId = templen;
			txmsg.IDE = CAN_ID_STD;
		}

		txmsg.RTR = CAN_RTR_DATA;

		GetSubString(ptr,"sendcan",":",szTemp,16);
		can_send_data(atoi(szTemp),&txmsg);

		DBG_Print(LEVEL2,"[CAN%u]TX:%X %02X %02X %02X %02X %02X %02X %02X %02X\r\n",atoi(szTemp),
						templen,txmsg.Data[0],txmsg.Data[1],txmsg.Data[2],txmsg.Data[3],
						txmsg.Data[4],txmsg.Data[5],txmsg.Data[6],txmsg.Data[7]);
	}
#if 1
	if (strstr((char *)pArg,"test_sd_mcu_ota"))
	{
		static unsigned char s_test = 0;

		const unsigned char m[] = 
		{
			0x23,0x23,0xA0,0xFE,0x4C,0x45,0x57,0x56,0x45,0x42,0x31,0x34,0x36,0x4D,0x4E,0x32,
			0x32,0x30,0x35,0x30,0x32,0x01,0x00,0xAE,0x16,0x0A,0x14,0x0B,0x17,0x13,0xC4,0xDE,
			0xA5,0x00,0x01,0xEE,0x12,0x4D,0x43,0x55,0x38,0x36,0x38,0x33,0x34,0x33,0x30,0x34,
			0x33,0x34,0x39,0x36,0x30,0x35,0x33,0x14,0x38,0x39,0x38,0x36,0x30,0x34,0x39,0x33,
			0x31,0x39,0x32,0x31,0x39,0x30,0x34,0x36,0x32,0x32,0x30,0x33,0x10,0x53,0x31,0x30,
			0x30,0x2E,0x30,0x30,0x34,0x43,0x32,0x35,0x35,0x2E,0x32,0x35,0x35,0x58,0x66,0x74,
			0x70,0x3A,0x2F,0x2F,0x66,0x74,0x70,0x5F,0x63,0x77,0x6A,0x68,0x5F,0x62,0x79,0x5F,
			0x6D,0x66,0x75,0x3A,0x43,0x37,0x71,0x6F,0x46,0x67,0x6D,0x7A,0x4C,0x58,0x51,0x38,
			0x51,0x77,0x74,0x6B,0x40,0x65,0x76,0x2E,0x63,0x77,0x6A,0x68,0x2E,0x63,0x6E,0x3A,
			0x33,0x30,0x30,0x32,0x31,0x2F,0x67,0x62,0x33,0x32,0x39,0x36,0x30,0x2F,0x6D,0x63,
			0x75,0x2F,0x53,0x31,0x30,0x30,0x2E,0x30,0x30,0x34,0x43,0x32,0x35,0x35,0x2E,0x32,
			0x35,0x35,0x2E,0x7A,0x69,0x70,0x4E,0xBA,0x6E,0x1B,0xE3,0xD6,0x89,0x3C,0xB7,0xDD,
			0x4B,0x55,0xF2,0x44,0x33,0xC1,0xD4
		};

		const unsigned char m1[] = 
		{
			0x23,0x23,0xA0,0xFE,0x4C,0x45,0x57,0x56,0x45,0x42,0x31,0x34,0x36,0x4D,0x4E,0x32,
			0x32,0x30,0x35,0x30,0x32,0x01,0x00,0xAE,0x16,0x0A,0x14,0x0F,0x04,0x16,0xC4,0xB7,
			0x7D,0x00,0x01,0xEE,0x12,0x4D,0x43,0x55,0x38,0x36,0x38,0x33,0x34,0x33,0x30,0x34,
			0x33,0x34,0x39,0x36,0x30,0x35,0x33,0x14,0x38,0x39,0x38,0x36,0x30,0x34,0x39,0x33,
			0x31,0x39,0x32,0x31,0x39,0x30,0x34,0x36,0x32,0x32,0x30,0x33,0x10,0x53,0x31,0x30,
			0x30,0x2E,0x30,0x30,0x35,0x43,0x32,0x35,0x35,0x2E,0x32,0x35,0x35,0x58,0x66,0x74,
			0x70,0x3A,0x2F,0x2F,0x66,0x74,0x70,0x5F,0x63,0x77,0x6A,0x68,0x5F,0x62,0x79,0x5F,
			0x6D,0x66,0x75,0x3A,0x43,0x37,0x71,0x6F,0x46,0x67,0x6D,0x7A,0x4C,0x58,0x51,0x38,
			0x51,0x77,0x74,0x6B,0x40,0x65,0x76,0x2E,0x63,0x77,0x6A,0x68,0x2E,0x63,0x6E,0x3A,
			0x33,0x30,0x30,0x32,0x31,0x2F,0x67,0x62,0x33,0x32,0x39,0x36,0x30,0x2F,0x6D,0x63,
			0x75,0x2F,0x53,0x31,0x30,0x30,0x2E,0x30,0x30,0x35,0x43,0x32,0x35,0x35,0x2E,0x32,
			0x35,0x35,0x2E,0x7A,0x69,0x70,0x9A,0xEF,0xC4,0x8B,0xE1,0xA2,0x5F,0x56,0x92,0x5A,
			0xC3,0x48,0xEE,0x7E,0x19,0x90,0x6C
		};

		s_test = !s_test;
		if (s_test)
		{
			gb32960_ack_plat(0,(void *)m,sizeof(m));
		}
		else
		{
			gb32960_ack_plat(0,(void *)m1,sizeof(m1));
		}
	}
#endif
#if 0
	if (strstr((char *)pArg,"test_uart_store"))
	{
		DBG_Print(LEVEL1,"start test uart...\r\n");
		for (templen = 0; templen < 50000; templen++)
		{
			sprintf(szTemp,"%u.hello world\n",templen);
			send_msg(S_MSG_SAVE_MCU_LOG,0,szTemp,(void *)strlen(szTemp));
			//send_msg(S_MSG_SAVE_MCU_LOG,(void *)1,"\x55\x66\x77\x88\x99\xaa",(void *)6);

			szTemp[0] = 22;
			szTemp[1] = 07;
			szTemp[2] = 25;
			szTemp[3] = 10;
			send_msg(S_MSG_STORE_CAN_DATA,szTemp,(void *)256,0);

			if (templen && (templen % 100) == 0)
			{
				os_sleep(10);
			}
		}
		DBG_Print(LEVEL1,"test uart finish\r\n");
	}

	if (strstr((char *)pArg,"set_chemen"))
	{
		set_dst_chemen_switch(1);
		set_dst_chesuo_switch(1);
	}
	if (strstr((char *)pArg,"clr_chemen"))
	{
		set_dst_chemen_switch(0);
		set_dst_chesuo_switch(0);
	}
	if (strstr((char *)pArg,"kg_chemen"))
	{
		set_dst_chemen_switch(1);
		set_dst_chesuo_switch(0);
	}

	if (strstr((char *)pArg,"dst_net_error_test"))
	{
		dst_start_test_net_error_lock();
		DBG_Print(0,"start test dst net error\r\n");
	}
#endif
	if (strstr((char *)pArg,"get_boxid"))
	{
		iccid_str_to_8byte("111111111111111111",szTemp);
		DBG_PrintBuf(LEVEL0,"boxid:",szTemp,8);
	}

	pTemp = find_str_tail(pArg,"test_sl_sos:");
	if (pTemp)
	{
		if (atoi(pTemp) < 32)
		{
			gb32960_can_set_sos_test(1);
			gb32960_can_set_sos_flag_by_bit(atoi(pTemp),1);
			if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"test_sl_sos:%dbit",atoi(pTemp));
		}
		else
		{
			gb32960_can_set_sos_test(0);
			gb32960_can_set_sos_flag(0);
			gb32960_can_set_max_sos_level(0);
			if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"test_sl_sos close");
		}
	}

	if (strstr(pArg,"beian"))
	{
		//<ip5:g6check.vecc.org.cn><port5:20006>
		send_hj1239_beian_info_to_server("g6check.vecc.org.cn",20006);

		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"send beian info\r\n");
	}

	if (GetSubString((char *)pArg,"<chipid:",">",szTemp,sizeof(szTemp)))
	{
		send_msg(S_MSG_SET_JIAMI_CHIP_ID,szTemp,(void *)(strlen(szTemp)),0);
		DBG_Print(LEVEL1,"chip id set ok(%s)\r\n",szTemp);
		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"chip id set ok(%s)\r\n",szTemp);
	}
#if 0
	if (strstr(pArg,"firstba"))
	{
		static unsigned char s_test1[] = {
			0x23,0x23,0x07,0x4C,0x47,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x43,0x43,0x34,0x34,
			0x34,0x34,0x34,0x34,0x00,0x01,0x00,0xA9,0x16,0x06,0x08,0x0B,0x13,0x31,0x4A,0x4D,
			0x43,0x30,0x31,0x30,0x33,0x32,0x31,0x31,0x32,0x31,0x38,0x35,0x38,0x36,0x9D,0x8D,
			0x7B,0x1D,0x49,0xB2,0xFB,0x76,0x31,0x6D,0x96,0x87,0xFD,0x0B,0x09,0x5D,0xD9,0x39,
			0x23,0xFF,0x6F,0x17,0xBC,0xFA,0xB8,0xCA,0x26,0x33,0xE9,0x46,0x5F,0x05,0x00,0x71,
			0xFB,0xBD,0xE1,0x2F,0x9B,0x4A,0xCD,0xA5,0xEA,0xF8,0x8D,0x88,0x9A,0x3C,0xAC,0xDE,
			0x63,0x01,0xB3,0x3B,0x91,0x38,0xE5,0xB2,0x30,0x5E,0x4C,0x1F,0x46,0xE8,0x4C,0x47,
			0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x43,0x43,0x34,0x34,0x34,0x34,0x34,0x34,0x20,
			0xF5,0xA8,0x23,0xB6,0x71,0xC0,0x9F,0x12,0x00,0xAE,0x98,0x63,0xFC,0x77,0x7F,0x48,
			0xB0,0x15,0xF0,0x8C,0x51,0xB7,0xD3,0x2E,0x1D,0xBB,0x4A,0x5F,0x12,0xF9,0xC2,0x9B,
			0x20,0x29,0xD5,0x9A,0xA2,0xE4,0xFA,0x87,0xB7,0xE5,0x0D,0x9E,0x38,0x4B,0xCA,0xBC,
			0x7C,0x02,0x12,0x62,0x8A,0xBC,0x83,0x92,0x5C,0x6E,0x27,0x75,0x6F,0x4E,0xE0,0x0C,
			0xFA,0xA8
		};
		send_msg(S_MSG_SEND_TO_SERVER,(void *)5,s_test1,(void *)(sizeof(s_test1)));

		DBG_Print(LEVEL0,"first bei an test\r\n");
	}

	if (strstr(pArg,"secondba"))
	{
		static unsigned char s_test[] = {
			0x23,0x23,0x07,0x4C,0x47,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x43,0x43,0x34,0x34,
			0x34,0x34,0x34,0x34,0x00,0x01,0x00,0xA9,0x16,0x06,0x09,0x09,0x31,0x36,0x4A,0x4D,
			0x43,0x30,0x31,0x30,0x33,0x32,0x31,0x31,0x32,0x31,0x38,0x35,0x38,0x36,0x9D,0x8D,
			0x7B,0x1D,0x49,0xB2,0xFB,0x76,0x31,0x6D,0x96,0x87,0xFD,0x0B,0x09,0x5D,0xD9,0x39,
			0x23,0xFF,0x6F,0x17,0xBC,0xFA,0xB8,0xCA,0x26,0x33,0xE9,0x46,0x5F,0x05,0x00,0x71,
			0xFB,0xBD,0xE1,0x2F,0x9B,0x4A,0xCD,0xA5,0xEA,0xF8,0x8D,0x88,0x9A,0x3C,0xAC,0xDE,
			0x63,0x01,0xB3,0x3B,0x91,0x38,0xE5,0xB2,0x30,0x5E,0x4C,0x1F,0x46,0xE8,0x4C,0x47,
			0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x43,0x43,0x34,0x34,0x34,0x34,0x34,0x34,0x20,
			0xF8,0xD4,0xB2,0xF6,0x36,0xB9,0xB7,0x4A,0xE7,0x75,0x7A,0x14,0x20,0xDD,0x65,0x01,
			0x45,0xC4,0xA4,0x4B,0x82,0xEE,0x2D,0xBA,0xBD,0x6B,0x0D,0x5C,0x2E,0xCA,0x1E,0x76,
			0x20,0xF4,0x5E,0x27,0x7A,0xB8,0x45,0x23,0x06,0x53,0x11,0xB0,0x8E,0x12,0x43,0xD5,
			0xFE,0x3D,0x2A,0xCB,0x16,0x51,0xB2,0x08,0x38,0x53,0xD4,0xAC,0xF9,0x87,0xB2,0x7A,
			0xD9,0x22
		};
		send_msg(S_MSG_SEND_TO_SERVER,(void *)5,s_test,(void *)(sizeof(s_test)));

		DBG_Print(LEVEL0,"second bei an test\r\n");
	}

	if (strstr(pArg,"errba"))
	{
		static unsigned char e_test[] = {
			0x23,0x23,0x07,0x4C,0x47,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x43,0x43,0x34,0x34,
			0x34,0x34,0x34,0x34,0x00,0x01,0x00,0xA9,0x16,0x06,0x09,0x09,0x31,0x36,0x4A,0x4D,
			0x43,0x30,0x31,0x30,0x33,0x32,0x31,0x31,0x32,0x31,0x38,0x35,0x38,0x36,0x9D,0x8D,
			0x7B,0x1D,0x49,0xB2,0xFB,0x76,0x31,0x6D,0x96,0x87,0xFD,0x0B,0x09,0x5D,0xD9,0x39,
			0x23,0xFF,0x6F,0x17,0xBC,0xFA,0xB8,0xCA,0x26,0x33,0xE9,0x46,0x5F,0x05,0x00,0x71,
			0xFB,0xBD,0xE1,0x2F,0x9B,0x4A,0xCD,0xA5,0xEA,0xF8,0x8D,0x88,0x9A,0x3C,0xAC,0xDE,
			0x63,0x01,0xB3,0x3B,0x91,0x38,0xE5,0xB2,0x30,0x5E,0x4C,0x1F,0x46,0xE8,0x4C,0x47,
			0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x43,0x43,0x34,0x34,0x34,0x34,0x34,0x34,0x20,
			0xF8,0xD4,0xB2,0xF6,0x36,0xB9,0xB7,0x4A,0xE7,0x75,0x7A,0x14,0x20,0xDD,0x65,0x01,
			0x45,0xC4,0xA4,0x4B,0x82,0xEE,0x2D,0xBA,0xBD,0x6B,0x0D,0x5C,0x2E,0xCA,0x1E,0x76,
			0x20,0xF4,0x5E,0x27,0x7A,0xB8,0x45,0x23,0x06,0x53,0x11,0xB0,0x8E,0x12,0x43,0xD5,
			0xFE,0x3D,0x2A,0xCB,0x16,0x51,0xB2,0x08,0x38,0x53,0xD4,0xAC,0xF9,0x87,0xB2,0x7A,
			0xD8,0x23
		};
		send_msg(S_MSG_SEND_TO_SERVER,(void *)5,e_test,(void *)(sizeof(e_test)));

		DBG_Print(LEVEL0,"err bei an test\r\n");
	}
#endif
	if (strstr(pArg,"loadparam"))
	{
		load_param();
	}

	pTemp = find_str_tail(pArg,"set_want_bind:");
	if (pTemp)
	{
		set_want_bind_status(atoi(pTemp));
		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_want_bind:%d",
				get_want_bind_status());
			}
		}
	}

	pTemp = find_str_tail(pArg,"set_want_pro:");
	if (pTemp)
	{
		set_want_pro_ver_about_lock(atoi(pTemp));
		if (pOut && outlen)
		{
			ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_want_pro:%d",
			get_want_pro_ver_about_lock());
		}
	}

	pTemp = find_str_tail(pArg,"set_want_lock:");
	if (pTemp)
	{
		set_want_lock_status(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_want_lock:%d",
				get_want_lock_status());
			}
		}
	}

	pTemp = find_str_tail(pArg,"set_ns_tip:");
	if (pTemp)
	{
		set_dst_inspect_tip_flag(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_ns_tip:%d",
				get_dst_inspect_tip_flag());
			}
		}
	}

	pTemp = find_str_tail(pArg,"set_by_tip:");
	if (pTemp)
	{
		set_dst_keep_fit_tip_flag(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_by_tip:%d",
				get_dst_keep_fit_tip_flag());
			}
		}
	}

	pTemp = find_str_tail(pArg,"set_jf_tip:");
	if (pTemp)
	{
		set_dst_pay_tip_flag(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_jf_tip:%d",
				get_dst_pay_tip_flag());
			}
		}
	}

	pTemp = find_str_tail(pArg,"set_want_charge:");
	if (pTemp)
	{
		set_dst_want_bms_charge_flag(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_want_charge:%d",
				get_dst_want_bms_charge_flag());
			}
		}
	}

	pTemp = find_str_tail(pArg,"set_want_limit_level:");
	if (pTemp)
	{
		set_dst_want_limit_speed_level(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_want_limit_level:%d",
				get_dst_want_limit_speed_level());
			}
		}
	}
	
	pTemp = find_str_tail(pArg,"set_want_kcr:");
	if (pTemp)
	{
		set_dst_want_kucunrong_limit_speed(atoi(pTemp));

		if (pOut && outlen)
		{
			if (pOut && outlen)
			{
				ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get_want_kcr:%d",
				get_dst_want_kucunrong_limit_speed());
			}
		}
	}

	//ATEX=set_collect_can_sw:1

	if (strstr(pArg,"set_collect_can_sw:1"))
	{
		set_collect_can_sw(1);
		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"collect_can_sw:1");
	}
	else if (strstr(pArg,"set_collect_can_sw:0"))
	{
		set_collect_can_sw(0);

		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"collect_can_sw:0");
	}

	if (strstr(pArg,"senddata"))
	{
		unsigned char test_data[] = 
		{
		0x23,0x23,0x02,0xFE,0x54,0x45,0x53,0x54,0x43,0x57,0x4A,0x48,0x31,0x32,0x33,0x34,
		0x35,0x39,0x39,0x39,0x39,0x01,0x00,0xFA,0x15,0x0C,0x03,0x11,0x0B,0x28,0x01,0x01,
		0x03,0x01,0x00,0x00,0x00,0x00,0x09,0xEC,0x0C,0xA8,0x27,0x74,0x11,0x04,0x07,0x50,
		0xC3,0x00,0x00,0x05,0x01,0x06,0xCE,0x39,0x54,0x01,0xD1,0x37,0x10,0x08,0x01,0x01,
		0x00,0x00,0x00,0x00,0x00,0x54,0x00,0x01,0x54,0x0F,0x1A,0x0F,0x19,0x0F,0x18,0x0F,
		0x19,0x0F,0x18,0x0F,0x19,0x0F,0x18,0x0F,0x19,0x0F,0x16,0x0F,0x19,0x0F,0x16,0x0F,
		0x15,0x0F,0x16,0x0F,0x15,0x0F,0x12,0x0F,0x14,0x0F,0x12,0x0F,0x18,0x0F,0x12,0x0F,
		0x18,0x0F,0x18,0x0F,0x18,0x0F,0x18,0x0F,0x18,0x0F,0x19,0x0F,0x18,0x0F,0x18,0x0F,
		0x18,0x0F,0x18,0x0F,0x18,0x0F,0x18,0x0F,0x18,0x0F,0x12,0x0F,0x18,0x0F,0x12,0x0F,
		0x16,0x0F,0x13,0x0F,0x16,0x0F,0x14,0x0F,0x16,0x0F,0x14,0x0F,0x17,0x0F,0x14,0x0F,
		0x17,0x0F,0x18,0x0F,0x17,0x0F,0x18,0x0F,0x16,0x0F,0x18,0x0F,0x16,0x0F,0x13,0x0F,
		0x16,0x0F,0x13,0x0F,0x16,0x0F,0x13,0x0F,0x16,0x0F,0x16,0x0F,0x16,0x0F,0x16,0x0F,
		0x15,0x0F,0x16,0x0F,0x15,0x0F,0x17,0x0F,0x15,0x0F,0x17,0x0F,0x19,0x0F,0x17,0x0F,
		0x19,0x0F,0x14,0x0F,0x19,0x0F,0x14,0x0F,0x19,0x0F,0x14,0x0F,0x19,0x0F,0x18,0x0F,
		0x19,0x0F,0x17,0x0F,0x17,0x0F,0x17,0x0F,0x17,0x0F,0x19,0x0F,0x17,0x0F,0x19,0x0F,
		0x17,0x09,0x01,0x01,0x00,0x1C,0x3A,0x3B,0x3A,0x3A,0x3A,0x3A,0x3A,0x3B,0x3A,0x3A,
		0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,0x3A,
		0x3A,0x3A,0xC2,
		};
		send_msg(S_MSG_SEND_TO_SERVER,0,test_data,(void *)(sizeof(test_data)));
		DBG_Print(0,"send to server\r\n");
	}

	if (strstr(pArg,"getdw"))
	{
		test_calc_charge_dl();
		if (pOut && outlen) ack_len += sprintf((char *)pOut + ack_len,"dw:%02X\r\n",gb32960_can_get_dangwei());
	}

	if (strstr(pArg,"plat_sw1:1"))
	{
		DBG_Print(LEVEL0,"plat_sw1:1\r\n");
		set_plat_sw1(1);
	}
	if (strstr(pArg,"plat_sw1:0"))
	{
		DBG_Print(LEVEL0,"plat_sw1:0\r\n");
		set_plat_sw1(0);
	}

	if (strstr(pArg,"plat_sw2:1"))
	{
		DBG_Print(LEVEL0,"plat_sw2:1\r\n");
		set_plat_sw2(1);
	}
	if (strstr(pArg,"plat_sw2:0"))
	{
		DBG_Print(LEVEL0,"plat_sw2:0\r\n");
		set_plat_sw2(0);
	}


	ptemp = strstr(pArg,"testvin?");
	if (ptemp)
	{
		if (pOut && outlen)
		{
			ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get test:%s\r\n",(char *)(get_test_vin()));
		}
		DBG_Print(LEVEL0,"get test:%s\r\n",get_test_vin());
	}

	ptemp = strstr(pArg,"dfvin?");
	if (ptemp)
	{
		DBG_Print(LEVEL0,"get vin2:%s\r\n",GetLicensePlate());
	}

	ptemp = strstr(pArg,"dfvin:");
	if (ptemp)
	{
		memcpy(szTemp,ptemp + strlen("dfvin:"),17);
		szTemp[17] = 0;

		SetLicensePlate(szTemp);
		DBG_Print(LEVEL0,"set vin2:%s\r\n",GetLicensePlate());
	}

	ptemp = strstr(pArg,"testvin:");
	if (ptemp)
	{
		memcpy(szTemp,ptemp + strlen("testvin:"),17);
		szTemp[17] = 0;

		set_test_vin(szTemp,17);
		if (pOut && outlen)
		{
			ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,"get test:%s\r\n",(char *)(get_test_vin()));
		}
		DBG_Print(LEVEL0,"set test vin:%s\r\n",(char *)(get_test_vin()));
	}
	
	ptemp = strstr(pArg,"terminalid:");
	if (ptemp)
	{
		SetTerminalID(ptemp+strlen("terminalid:"));
		DBG_Print(LEVEL0,"set terminalid:%s\r\n",GetTerminalID());
	}

	ptemp = strstr(pArg,"terminalid?");
	if (ptemp)
	{
		DBG_Print(LEVEL0,"get terminalid:%s\r\n",GetTerminalID());
	}

	//�ϴ�CAN����
	if (strstr(pArg,"sc_can:1"))
	{
		set_report_can_raw_sw(1);
		DBG_Print(LEVEL0,"start repot can data\r\n");
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"start repot can data\r\n");
	}

	if (strstr(pArg,"sc_can:0"))
	{
		set_report_can_raw_sw(0);
		DBG_Print(LEVEL0,"stop repot can data\r\n");
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"stop repot can data\r\n");
	}

	//��άƽ̨����ʱ����
	pTemp = strstr(pArg,"set_beat_time:");
	if (pTemp)
	{
		DBG_Print(LEVEL0,"set heart beat time interval:%u\r\n",atoi(pTemp + 14));
		//set_heart_beat_time_interval(atoi(pTemp + 14));

		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"set heart beat time interval:%u\r\n",atoi(pTemp + 14));
	}

	pTemp = strstr(pArg,"set_test_step:");
	if (pTemp)
	{
		DBG_Print(LEVEL0,"set test step:%u\r\n",atoi(pTemp + 14));
		set_test_step(atoi(pTemp + 14));

		//sandian_mcu_start_ota_step(atoi(pTemp + 14),0x9800,1028,0x308400,341108);
		sandian_mcu_start_ota_step(atoi(pTemp + 14),0x9800,1028,0x308400,289272);

		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"set test step:%u\r\n",atoi(pTemp + 14));
	}

	pTemp = strstr(pArg,"set_test_step1:");
	if (pTemp)
	{
		DBG_Print(LEVEL0,"set test step:%u\r\n",atoi(pTemp + 15));
		set_test_step(atoi(pTemp + 15));

		sandian_mcu_start_ota_step(atoi(pTemp + 15),0x9800,1028,0x308400,289448);
		//sandian_mcu_start_ota_step(atoi(pTemp + 15),0x9800,1028,0x308400,289272);

		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"set test step:%u\r\n",atoi(pTemp + 15));
	}

	if (strstr(pArg,"moni_can_data:0"))
	{
		set_moni_can_data_flag(0);
		DBG_Print(LEVEL0,"ֹͣģ��CAN����\r\n");
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"stop mo ni can data");
	}

	if (strstr(pArg,"moni_can_data:1"))
	{
		set_moni_can_data_flag(1);
		DBG_Print(LEVEL0,"����ģ��CAN����\r\n");
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"start mo ni can data");
	}

	//����CAN ID
	if (GetSubString(pArg,"<addcan:",">",szTemp,32))
	{
		INT32U id = 0;
		INT8U hex[8] = {0};

		HexStrToArray((INT8U *)szTemp,hex,8);

		id = (hex[0] << 24) + (hex[1] << 16) + (hex[2] << 8) + hex[3];
		add_canid_in_list(id);
		DBG_Print(0,"add id:%08X\r\n",id);
		if (pOut && outlen) ack_len += sprintf((char *)pOut + ack_len,"add id:%08X\r\n",id);
	}

	if (strstr(pArg,"get_can_list"))
	{
		get_can_list_tip(szTemp,128);
		if (pOut && outlen) ack_len += sprintf((char *)pOut + ack_len,"can list:%s\r\n",szTemp);
		DBG_Print(LEVEL1,"can list:%s\r\n",szTemp);
	}

	pTemp = find_str_tail(pArg,"set_can_speed_id:");
	if (pTemp)
	{
		INT32U id = 0;
		INT8U hex[8] = {0};

		HexStrToArray((INT8U *)pTemp,hex,8);

		id = (hex[0] << 24) + (hex[1] << 16) + (hex[2] << 8) + hex[3];
		set_can_speed_id(id);
		DBG_Print(0,"set speed id:%08X\r\n",id);
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"set speed id:%08X\r\n",id);
	}

	pTemp = find_str_tail(pArg,"set_can_milage_id:");
	if (pTemp)
	{
		INT32U id = 0;
		INT8U hex[8] = {0};

		HexStrToArray((INT8U *)pTemp,hex,8);

		id = (hex[0] << 24) + (hex[1] << 16) + (hex[2] << 8) + hex[3];
		set_can_milage_id(id);
		DBG_Print(0,"set milage id:%08X\r\n",id);
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"set milage id:%08X\r\n",id);
	}

	if (strstr((char *)pArg,"sjz_beian"))
	{
		set_sjz_beian_flag(1);
		DBG_Print(0,"ִ��ƽ̨��������\r\n");
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"execute beian");
	}

	if (strstr((char *)pArg,"shoudong_login:1"))
	{
		set_shoudong_login_flag(1);
		DBG_Print(0,"�ֶ���¼\r\n");
		
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"execute login");
	}

	if (strstr((char *)pArg,"chaichu_sos:0"))
	{
		set_chaichu_sos_flag(0);
	}

	if (strstr((char *)pArg,"chaichu_sos:1"))
	{
		set_chaichu_sos_flag(1);
		DBG_Print(0,"�������\r\n");
		
		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"chai chu sos");
	}

	/* ����CANû�����ݵĽ��ճ�ʱʱ��,��λʱ����,ATEX=CANOUTTIME,value */
	ptr = find_str_tail(pArg, "CANOUTTIME,");
	if (ptr)
	{
		INT8U min = (INT8U)atoi(ptr);
		if (min > 0)
		{
			DBG_Print(LEVEL0,"Set Can recv data outtime[%d min] success\r\n", min);
			SysSetCanOuttime(min);
			
		}			
	}
	
	/* �������߻���ģʽ��acc-0,����canδ���ճ�ʱ-1,ATEX=SLEEPMODE,value */
	ptr = find_str_tail(pArg, "SLEEPMODE,");
	if (ptr)
	{
		INT8U flag = (INT8U)atoi(ptr);

		DBG_Print(LEVEL0,"Set Sleep Mode Base On %s success\r\n", 
		(0 == flag) ? "Acc" : "Can No Data Outtime");

		if (pOut) ack_len += sprintf((char *)pOut + ack_len,"Set Sleep Mode Base On %s success\r\n", 
		(0 == flag) ? "Acc" : "Can No Data Outtime");
	
		SysSetSleepBaseAccCanFlag(flag);	
	}
	
	/* ��ѯ���߻���ʲôģʽ */
	ptr = find_str_tail(pArg, "SLEEPMODE?");
	if (ptr)
	{
		INT8U flag = SysGetSleepBaseAccCanFlag();
	
		if (!flag)
		{
			DBG_Print(LEVEL0,"Get Sleep Mode Base On Acc\r\n");
			
			if (pOut) ack_len += sprintf((char *)pOut + ack_len,"Get Sleep Mode Base On Acc");
		}
		else
		{
			DBG_Print(LEVEL0,"Get Sleep Mode Base On Can No Data Outtime[%d min]\r\n", 
			SysGetCanOuttime());
			if (pOut) ack_len += sprintf((char *)pOut + ack_len,"Get Sleep Mode Base On Can No Data Outtime[%d min]", 
			SysGetCanOuttime());
		}
	}

	//��ȡ����������
	if (strstr(pArg,"ENGINETYPE?"))
	{
		if (pOut && outlen)
		{
			ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,
			"engine type:%s ryc_type:%s\r\n",get_engine_type_str(get_engine_type()),get_engine_type_str(get_ryc_engine_type()));

		}

		DBG_Print(LEVEL0,"engine type:%s ryc_type:%s\r\n",get_engine_type_str(get_engine_type()),get_engine_type_str(get_ryc_engine_type()));
	}

	//���÷���������
	ptemp = strstr(pArg,"ENGINETYPE=");
	if (ptemp)
	{
		set_engine_type((EngineType)atoi(ptemp + strlen("ENGINETYPE=")));

		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,
		"engine type:%s\r\n",get_engine_type_str(get_engine_type()));

		DBG_Print(LEVEL0,"set engine type:%s\r\n",get_engine_type_str(get_engine_type()));
	}

	//�������������
	ptemp = strstr(pArg,"CLRENGINETYPE");
	if (ptemp)
	{
		set_engine_type(EngineType_Compatible);
		set_ryc_engine_type(EngineType_Compatible);

		if (pOut && outlen) ack_len += snprintf((char *)pOut + ack_len,outlen - ack_len,
		"engine type:%s\r\n",get_engine_type_str(get_engine_type()));

		DBG_Print(LEVEL0,"set engine type:%s\r\n",get_engine_type_str(get_engine_type()));
	}

	if (strstr(pArg,"txcan"))
	{

		DBG_Print(0,"send tx test.\r\n");
	}
	

	if (strstr(pArg,"GPSAT:"))
	{
		DBG_Print(0,"send to gps:%s\r\n",ptr + 6);
		
		//send_to_gps(ptr + 6,strlen(ptr + 6));
	}


	return ack_len;
}


static int Cmd_SetIpPort(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	return 0;
}

/* ����֧�ֵ��û�ָ�� */
SystemCommand const stCmdList[] = 
{
{"ATVER?",	Cmd_GetSoftwareVersion,"��ѯ�����汾"},

{"ATRST",			Cmd_DefaultDevice}, 	//�ָ���������

{"ATTEST",			Cmd_Test},

//���� ��ѯ����VIN
{"ATVIN=",			Cmd_SetVin,"���ó���VIN ��ʽ:ATVIN=xxxxxxxxxxxxxxxxx (xxxxxxxxxxxxxxxxxΪ����VIN)"},
{"ATVIN?",			Cmd_GetVin,"��ѯ����VIN"},
{"ATINFO?",			Cmd_GetInfo},

//���� ��ѯSN��
//{"ATSN=",			Cmd_SetSn},
//{"ATSN?",			Cmd_GetSn},


{"ATCHIPID=",		Cmd_SetChipId,"���ü���оƬID ��ʽ:ATCHIPID=xxxx   (xxxΪоƬID)"},
{"ATCHIPID?",		Cmd_GetChipId,"��ѯ����оƬID"},
{"ATPUBKEY?", 		Cmd_GetPubKey,"��ѯ����оƬ��Կ"},


//���� ��ѯCAN1������
{"ATCAN1BPS=",		Cmd_SetCan1Bps,"���õ�һ·CAN������ ����: ���ò�����Ϊ500K  ATCAN1BPS=500"},
{"ATCAN1BPS?",		Cmd_GetCan1Bps,"��ѯ��һ·CAN������"},

//���� ��ѯCAN2������
{"ATCAN2BPS=",		Cmd_SetCan2Bps,"���õڶ�·CAN������ ����: ���ò�����Ϊ500K  ATCAN2BPS=500"},
{"ATCAN2BPS?",		Cmd_GetCan2Bps,"��ѯ�ڶ�·CAN������"},


{"ATAPN=",			Cmd_SetApn,"����APN ����:����APNΪCMNET:ATAPN=CMNET"},
{"ATAPN?",			Cmd_GetApn,"��ѯAPN"},


{"ATPLAT?", 		Cmd_GetPlat,"��ȡ�豸���ӵķ�������Ϣ"},
{"ATFIRSTIP=",		Cmd_SetFirstIP,"���õ�һ·IP ����:ATFIRSTIP=114.114.114.114 ���� ATFIRSTIP=www.bcg.cn"},
{"ATFIRSTPORT=",	Cmd_SetFirstPort,"���õ�һ·�˿� ����:ATFIRSTPORT=9100"},

{"ATSECONDIP=", 	Cmd_SetSecondIP,"���õڶ�·IP"},
{"ATSECONDPORT=",	Cmd_SetSecondPort,"���õڶ�·�˿�"},

{"ATTHIRDIP=",		Cmd_SetThirdIP,"���õ���·IP"},
{"ATTHIRDPORT=",	Cmd_SetThirdPort,"���õ���·�˿�"},

{"ATIPPORT=",		Cmd_SetIpPort,"����IP�˿� ��ʽ:ATIPPORT=�ڼ�·����,Э������,TCP,��������ַ,�������˿� ����:ATIPPORT=0,1,TCP,127.0.0.1,60000"},

{"ATEX=",			Cmd_Expand,"��չ"},
{"ATHELP",			Cmd_Help,"ָ�����"}

};

int Cmd_Help(void *pArg,INT32U len,void *pOut,INT32U outlen)
{
	int rlen = 0;
	unsigned int i = 0;
	unsigned int cnt = sizeof(stCmdList) / sizeof(stCmdList[0]);

	for (i = 0; i < cnt; i++)
	{
		DBG_Print(LEVEL0,"[APP]%s ��;:%s\r\n",
		stCmdList[i].pCmd,stCmdList[i].pTip ? stCmdList[i].pTip : "none");
	}

	if (pOut && outlen)
	{
		rlen = snprintf(pOut,outlen,"sms not support the ATHELP command.");
	}
	return rlen;	
}


//�ֶ����õ�VIN���� û���ֶ�����VIN������� ͨ��CAN��ȡ������VIN
INT8U get_vin(void *pOut,int outbuflen)
{
	char can_vin[20] = {0};
	unsigned char channel = GetCanChannel();

	if ((pOut == 0) || (outbuflen < VIN_LEN))
	{
		return 0;
	}

	can_get_vin(channel,can_vin,sizeof(can_vin));

	if (IsObjNULL(can_vin,VIN_LEN))
	{
		memcpy(pOut,GetVIN(),VIN_LEN);
	}
	else
	{
		memcpy(pOut,can_vin,VIN_LEN);
	}
	return VIN_LEN;
}



unsigned int get_obd_data(void *pOutBuf,unsigned int outbuflen)
{
	unsigned int rlen = 0;
#if 1
	unsigned char *candata = (unsigned char *)pOutBuf;
	unsigned char channel = GetCanChannel();
	unsigned int temp = 0;
	unsigned char i = 0;

	//rlen = get_vin(candata,outbuflen);
	memcpy(candata,GetVIN(),17);
	rlen = 17;

	if (can_get_speed(channel) && (can_get_speed(channel) != 0xFFFF))
	{
		temp = can_get_speed(channel);
	}
	else if (gb32960_can_get_speed() != 0xFFFF)
	{
		temp = (gb32960_can_get_speed() / 10) * 256;
	}
	else
	{
		temp = 0;
	}

	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	candata[rlen++] = can_get_kpa(channel);
	candata[rlen++] = can_get_actualtorquepercent(channel);
	candata[rlen++] = can_get_frictiontorquepercent(channel);
	temp = can_get_rpm(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	
	temp = can_get_fuelflow(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;

	temp = can_get_upperNOx(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	
	temp = can_get_lowerNOx(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	
	candata[rlen++] = can_get_remain(channel);
	
	temp = can_get_intakevolume(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;

	temp = can_get_SCRInletTemperature(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	
	temp = can_get_SCROutletTemperature(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	
	temp = can_get_DPF(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;

	candata[rlen++] = can_get_coolanttemperature(channel);
	if (can_get_oilboxlevel(channel) && (can_get_oilboxlevel(channel) != 0xFF))
	{
		candata[rlen++] = can_get_oilboxlevel(channel);
	}
	else
	{
		candata[rlen++] = gb32960_can_get_soc() / 0.4;
	}

	if (can_get_milage(channel) && (can_get_milage(channel) != 0xFFFFFFFF))
	{
		temp = can_get_milage(channel);
	}
	else if (gb32960_can_get_milage() != 0xFFFFFFFF)
	{
		temp = gb32960_can_get_milage();
	}
	else
	{
		temp = 0;
	}

	candata[rlen++] = temp >> 24;
	candata[rlen++] = temp >> 16;
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;

	
	candata[rlen++] = can_get_obd_pro(channel);
	candata[rlen++] = can_get_mil_sta(channel);

	temp = can_get_dst_sta(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;
	
	temp = can_get_drt_sta(channel);
	candata[rlen++] = temp >> 8;
	candata[rlen++] = temp;

	can_get_iupr(channel,candata + rlen,outbuflen - rlen);
	rlen += IUPR_LEN;

	if (can_get_dtc_cnt(channel) < 20)
	{
		candata[rlen++] = can_get_dtc_cnt(channel);
		for (i = 0; i < can_get_dtc_cnt(channel); i++)
		{
			if (i >= (DTC_BUF_LEN / 4))
			{
				break; 
			}
			candata[rlen++] = can_get_dtc_buf(channel,i * 4 + 0);
			candata[rlen++] = can_get_dtc_buf(channel,i * 4 + 1);
			candata[rlen++] = can_get_dtc_buf(channel,i * 4 + 2);
			candata[rlen++] = can_get_dtc_buf(channel,i * 4 + 3);
		}
	}
	else
	{
		candata[rlen++] = 0;
	}

	can_get_calid(channel,candata + rlen, CALID_LEN);
	rlen += CALID_LEN;

	can_get_cvn(channel,candata + rlen, CVN_LEN);
	rlen += (CVN_LEN);
#endif
	return rlen;
}




#define _SET_BIT(val,bit_no) val |= (1 << bit_no)
#define _CLR_BIT(val,bit_no) val &= (~(1 << bit_no))

/**
��0λ��ʾ:SIM������״̬ 0��ʾδ���� 1��ʾ�Ѳ���
��1λ��ʾ�Ƿ�����ƽ̨��־ 0��ʾδ���� 1��ʾ������
��2λ��ʾACC״̬ 0��ʾOFF  1��ʾON
��3λ��ʾFLASH�Ƿ�OK 0��ʾ��OK  1��ʾOK
��4λ��ʾ����оƬ�Ƿ�OK
��5λ��ʾ����ģʽ 0��ʾ����Դ���� 1��ʾ��ع���
��6λ��ʾSD���Ƿ�OK
��7λ��ʾ�Ƿ����ϵڶ�·ƽ̨��־ 0��ʾδ���� 1��ʾ������
��8λ��ʾ�Ƿ����ϵ���·ƽ̨��־ 0��ʾδ���� 1��ʾ������
��9λ��ʾ�Ƿ����ϵ���·ƽ̨��־ 0��ʾδ���� 1��ʾ������

��10λ��ʾemmcоƬ�Ƿ�OK
��11λ��ʾgsensorоƬ�Ƿ�OK
��12λ��ʾ�Ƿ����ϵ���·ƽ̨��־ 0��ʾδ���� 1��ʾ������
��13λ��ʾ�Ƿ����ϵ���·ƽ̨��־ 0��ʾδ���� 1��ʾ������
��14λ��ʾ�Ƿ����ϵ���·ƽ̨��־ 0��ʾδ���� 1��ʾ������
��15λ��ʾwifi�Ƿ�OK
��16-19λ ����Դ����
��20-23λ ȼ�ͳ�����

��24λ��ʾCAN0�Ƿ�OK
��25λ��ʾCAN1�Ƿ�OK
��26λ��ʾCAN2�Ƿ�OK

27-31λ���� ����
*/
INT32U _get_sw_status(void)
{
	INT32U ret = 0;
	INT8U i = 0;

	if (1)
	{
		_SET_BIT(ret,0);
	}
	else
	{
		_CLR_BIT(ret,0);
	}

	if (get_net_link_status(0))
	{
		_SET_BIT(ret,1);
	}
	else
	{
		_CLR_BIT(ret,1);
	}

	if ((unsigned int)send_msg(S_MSG_GET_ACC_STATUS,0,0,0))
	{
		_SET_BIT(ret,2);
	}
	else
	{
		_CLR_BIT(ret,2);
	}

	if ((unsigned int)send_msg(S_MSG_GET_FLASH_CHIP_STATUS,0,0,0))
	{
		_SET_BIT(ret,3);
	}
	else
	{
		_CLR_BIT(ret,3);
	}

	if ((unsigned int)send_msg(S_MSG_GET_JIAMI_CHIP_STATUS,0,0,0))
	{
		_SET_BIT(ret,4);
	}
	else
	{
		_CLR_BIT(ret,4);
	}

	//��5bit ����ģʽ
	if (send_msg(S_MSG_GET_POWER_SUPPLY_MODE,0,0,0))
	{
		_SET_BIT(ret,5);
	}
	else
	{
		_CLR_BIT(ret,5);
	}

	//��6bit SD����־
	if (0)
	{
		_SET_BIT(ret,6);
	}
	else
	{
		_CLR_BIT(ret,6);
	}

	//������·ƽ̨���ӱ�־
	for (i = 0; i < 3; i++)
	{		
		if (get_net_link_status(i + 1))
		{
			_SET_BIT(ret,7 + i);
		}
		else
		{
			_CLR_BIT(ret,7 + i);
		}
	}

	//��10bit emmc
	if ((unsigned int)send_msg(S_MSG_GET_EMMC_CHIP_STATUS,0,0,0))
	{
		_SET_BIT(ret,10);
	}
	else
	{
		_CLR_BIT(ret,10);
	}

	//��11bit g-sensor
	if ((unsigned int)send_msg(S_MSG_GET_GSENSOR_CHIP_STATUS,0,0,0))
	{
		_SET_BIT(ret,11);
	}
	else
	{
		_CLR_BIT(ret,11);
	}

	//��12 13 14bit ������·ƽ̨����
	for (i = 0; i < 3; i++)
	{
		if (get_net_link_status(i + 4))
		{
			_SET_BIT(ret,12 + i);
		}
		else
		{
			_CLR_BIT(ret,12 + i);
		}
	}

	//��15bit wifi
	if ((unsigned int)send_msg(S_MSG_GET_WIFI_MODULE_STATUS,0,0,0))
	{
		_SET_BIT(ret,15);
	}
	else
	{
		_CLR_BIT(ret,15);
	}

	//��24 25 26bit CAN״̬
	if ((unsigned int)send_msg(S_MSG_GET_CAN0_STATUS,0,0,0))
	{
		_SET_BIT(ret,24);
	}
	else
	{
		_CLR_BIT(ret,24);
	}
	if ((unsigned int)send_msg(S_MSG_GET_CAN1_STATUS,0,0,0))
	{
		_SET_BIT(ret,25);
	}
	else
	{
		_CLR_BIT(ret,25);
	}
	if ((unsigned int)send_msg(S_MSG_GET_CAN2_STATUS,0,0,0))
	{
		_SET_BIT(ret,26);
	}
	else
	{
		_CLR_BIT(ret,26);
	}

	ret |= ((((get_ryc_engine_type() << 4) + get_engine_type()) & 0xFF) << 16);

	return ret;
}
#if 1

unsigned int get_status(void *pOutBuf,unsigned int outbuflen)
{
	INT8U *rxbuf = (INT8U *)pOutBuf;
	INT16U len = 0;
	INT32U ulRunTime = 0;
	INT16U usMainPowerVoltage = 0;
	INT16U usBatVoltage = 0;
	INT16U temp = 0;
	INT32U lonlat = 0;
	INT8U lonlatflag = 0;
	char *piccid = 0;
	char *pimei = 0;
	unsigned char *p_mpu_ver = 0;

	if ((pOutBuf == 0) || (outbuflen == 0))
	{
		return 0;
	}

	piccid = send_msg(S_MSG_GET_ICCID,0,0,0);
	pimei = send_msg(S_MSG_GET_IMEI,0,0,0);

	ulRunTime = GetRunTime();
	usMainPowerVoltage = (unsigned int)send_msg(S_MSG_GET_MAIN_VOL,0,0,0);
	usBatVoltage = (unsigned int)send_msg(S_MSG_GET_BAT_VOL,0,0,0);

	//�豸rtcʱ��
	send_msg(S_MSG_GET_RTC_TIME,rxbuf + len,0,0);
	len += 6;

	//�豸����ʱ��
	rxbuf[len++] = ulRunTime >> 24;
	rxbuf[len++] = ulRunTime >> 16;
	rxbuf[len++] = ulRunTime >> 8;
	rxbuf[len++] = ulRunTime;

	//����Դ��ѹ
	rxbuf[len++] = usMainPowerVoltage >> 8;
	rxbuf[len++] = usMainPowerVoltage;

	//��ص�ѹ
	rxbuf[len++] = usBatVoltage >> 8;
	rxbuf[len++] = usBatVoltage;

	//CPU�ڲ�Flash��С
	temp = GetCpuFlashSize();
	rxbuf[len++] = temp >> 8;
	rxbuf[len++] = temp;

	//CPU���к�
	rxbuf[len++] = 12;
	//GetCpuID(rxbuf + len,outbuflen - len);
	len += 12;

	//�Ƿ�λ
	rxbuf[len++] = (INT32U)send_msg(S_MSG_GET_GPS_LOCAL_STATUS,0,0,0);;

	//GpsGetLonInfo(&lonlat, &lonlatflag);

	lonlat = (INT32U)send_msg(S_MSG_GET_LON,0,0,0);
	lonlatflag = 0;

	//������
	rxbuf[len++] = lonlatflag;
	//����
	rxbuf[len++] = lonlat >> 24;
	rxbuf[len++] = lonlat >> 16;
	rxbuf[len++] = lonlat >> 8;
	rxbuf[len++] = lonlat;

	//GpsGetLatInfo(&lonlat, &lonlatflag);
	lonlat = (INT32U)send_msg(S_MSG_GET_LAT,0,0,0);
	lonlatflag = 0;

	//�ϱ�γ
	rxbuf[len++] = lonlatflag;
	//γ��
	rxbuf[len++] = lonlat >> 24;
	rxbuf[len++] = lonlat >> 16;
	rxbuf[len++] = lonlat >> 8;
	rxbuf[len++] = lonlat;


	//�����汾��
	p_mpu_ver = send_msg(S_MSG_GET_MPU_SOFTWARE_VERSION,0,0,0);
	temp = strlen(APP_VERSION) + strlen((char *)p_mpu_ver);
	if (temp >= 47)
	{
		temp = 47;
	}

	rxbuf[len++] = temp;
	memcpy(rxbuf + len,APP_VERSION,strlen(APP_VERSION));
	len += strlen(APP_VERSION);
	if (temp > strlen(APP_VERSION)) memcpy(rxbuf + len,p_mpu_ver,temp - strlen(APP_VERSION));
	len += (temp - strlen(APP_VERSION));

	//��������
	rxbuf[len++] = strlen(__DATE__) + strlen(__TIME__) + 1;
	memcpy(rxbuf + len,__DATE__,strlen(__DATE__));
	len += strlen(__DATE__);
	rxbuf[len++] = ' ';
	memcpy(rxbuf + len,__TIME__,strlen(__TIME__));
	len += strlen(__TIME__);

	//ͨ��ģ���Ƿ����
	rxbuf[len++] = 1;
	//GPSģ���Ƿ����
	rxbuf[len++] = (unsigned int)send_msg(S_MSG_GET_GPS_MODULE_STATUS,0,0,0);

	//״̬λ
	rxbuf[len++] = _get_sw_status() >> 24;
	rxbuf[len++] = _get_sw_status() >> 16;
	rxbuf[len++] = _get_sw_status() >> 8;
	rxbuf[len++] = _get_sw_status();

	//��λ����
	rxbuf[len++] = (unsigned int)send_msg(S_MSG_GET_GPS_STAR_NUM,0,0,0);
	//SIM���ź�ǿ��
	rxbuf[len++] = (unsigned int)send_msg(S_MSG_GET_SIM_CSQ,0,0,0);
	//GPS����״̬
	rxbuf[len++] = (unsigned int)send_msg(S_MSG_GET_GPS_ANT_STATUS,0,0,0);

	temp = strlen(piccid);
	if (temp >= MAX_SN_LEN)
	{
		temp = MAX_SN_LEN - 1;
	}
	rxbuf[len++] = temp;
	//SN�� ��iccid����
	if (temp) memcpy((char *)rxbuf + len,piccid,temp);
	len += temp;

	//IMEI
	temp = strlen(pimei);
	if (temp >= 20)
	{
		temp = 20;
	}
	rxbuf[len++] = temp;
	if (temp) memcpy((char *)rxbuf + len,pimei,temp);
	len += temp;

	return len;
}


#endif

void report_can_data(void)
{
	unsigned char *ptr = 0;
	unsigned char *candata = 0;
	unsigned int rlen = 0;
	unsigned int sendlen = 0;

	if ((ptr == 0) || (candata == 0))
	{

		return ;
	}

	rlen = get_obd_data(candata,1536);

	sendlen = tccp_pack(TCCP_SLAVE_SEND_CAN_MSG_ID,candata,rlen,ptr,1536);

	DBG_PrintBuf(LEVEL5,"send can data:\r\n",ptr,sendlen);

}

#if 1
void device_heart_beat(void)
{
	unsigned int obd_len = 0;
	unsigned char status_len = 0;
	unsigned char *pSend = 0;
	unsigned int rlen = 0;
	unsigned char *ptr = 0;
	unsigned int slen = 0;

	if ((pSend == 0) || (ptr == 0))
	{

		return ;
	}

	obd_len = get_obd_data(pSend,1536);
	status_len = get_status(pSend + obd_len,1536 - obd_len);
	rlen = obd_len + status_len;

	slen = tccp_pack(TCCP_DEVICE_HEART_BEAT_MSG_ID1,pSend,rlen,ptr,1536);

	
	DBG_Print(LEVEL3,"send heart beat(%d):\r\n",slen);
	DBG_PrintBuf(LEVEL3,0,ptr,slen);
}
#endif

void _device_heart_beat1(unsigned char channel)
{
	unsigned int obd_len = 0;
	unsigned char status_len = 0;
	unsigned char *pSend = 0;
	unsigned int rlen = 0;
	unsigned char *ptr = 0;
	unsigned int slen = 0;
	
	pSend = os_malloc(1536);
	ptr = os_malloc(1536);
	if ((pSend == 0) || (ptr == 0))
	{
		os_free(pSend);	
		os_free(ptr);
		return ;
	}

	obd_len = get_obd_data(pSend,1536);
	status_len = get_status(pSend + obd_len,1536 - obd_len);
	rlen = obd_len + status_len;

	slen = tccp_pack(TCCP_DEVICE_HEART_BEAT_MSG_ID1,pSend,rlen,ptr,1536);
	os_free(pSend);

	DBG_Print(LEVEL3,"send heart beat(%d):\r\n",slen);
	DBG_PrintBuf(LEVEL3,0,ptr,slen);

	send_msg(S_MSG_SEND_TO_SERVER,(void *)channel,ptr,(void *)slen);
	os_free(ptr);
}

void device_heart_beat1(void)
{
	_device_heart_beat1(8);
}

void test_device_heart_beat(void)
{
	_device_heart_beat1(7);
}

void send_status_to_canbus(void)
{
	unsigned char *pSend = 0;
	unsigned int xlen = 0;
	CanTxMsg txmsg = {0,0,CAN_Id_Extended,CAN_RTR_DATA,8,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}};
	unsigned char i = 0;

	pSend = os_malloc(1536);
	if (pSend)
	{
		xlen = get_status(pSend,1536);

		while (xlen)
		{
			txmsg.ExtId = 0;
			txmsg.StdId = 0x666;
			txmsg.DLC = 8;
			txmsg.IDE = CAN_Id_Standard;
			txmsg.RTR = CAN_RTR_DATA;

			txmsg.Data[0] = i;
			memcpy(&(txmsg.Data[1]),pSend + (i * 7),7);
			can_send_data(0,&txmsg);
			can_send_data(1,&txmsg);
			can_send_data(2,&txmsg);

			i++;
			xlen = (xlen >= 7) ? (xlen - 7) : 0;

			//DBG_PrintBuf(LEVEL2,"[CAN0]",txmsg.Data,8);
		}
		os_free(pSend);
	}
}

void user_cmd_ex(void *buf,unsigned int len)
{

}

unsigned int analyze_usercmd(void *ptr,unsigned int len,void *pOut,unsigned int outbuflen)
{
	//unsigned char *temp = (unsigned char *)ptr;
	//char *pTemp = 0;
	INT16U i = 0;
	static char acTemp[128] = {0};
	//static char acAnswer[512] = {0};
	unsigned int rlen = 0;

	if ((ptr == 0) || (len == 0))
	{
		return 0;
	}
	user_cmd_ex(ptr,len);

	for (i = 0; i < ARRAY_ELEMENT_CNT(stCmdList); i++)
	{
		if (strstr((char *)ptr,stCmdList[i].pCmd))	//��һ�Ա�ָ���
		{
			if (GetSubString((char *)ptr,stCmdList[i].pCmd,"\r\n",acTemp,sizeof(acTemp)) ||
			GetSubString((char *)ptr,stCmdList[i].pCmd,0,acTemp,sizeof(acTemp))
			)
			{
				if (stCmdList[i].pFunc)
				{
					DBG_Print(LEVEL3,"cmd:%s\r\narg:%s\r\n",stCmdList[i].pCmd,acTemp);
					
					rlen = stCmdList[i].pFunc(acTemp,strlen(acTemp),pOut,outbuflen);
				}
			}
		}
	}

	return rlen;
}











