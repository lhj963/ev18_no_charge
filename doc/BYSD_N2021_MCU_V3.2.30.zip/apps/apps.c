#include "apps.h"

#include "./aes128/aes.c"
#include "./func/func.c"
#include "./two_cpu_com_protocol/two_cpu_com_protocol.c"


#include "./HardwareCfg/HardwareCfg.c"

#include "./SysParam/SysParam.c"


#include "./OBD/obd.c"
#include "./OBD/J1939.c"
#include "./OBD/uds.c"


#include "./gb32960/gb32960.c"
#include "./dongfeng_plat/dongfeng_plat.c"
#include "./dst/dst.c"

#include "./CN6/CN6.c"
#include "./adhd/adhd.c"

#include "./usercmd/usercmd.c"

#include "./back_plat_ui/back_plat_ui.c"

#include "./pub/pub.c"


#include "./san_dian_ota/bl_crc32_bzip2.c"
#include "./san_dian_ota/vcu1_ota.c"
#include "./san_dian_ota/huichuan_mcu_ota.c"
#include "./san_dian_ota/ningde_bms_ota.c"
#include "./san_dian_ota/san_dian_ota.c"
#include "./san_dian_ota/lidong_bms_ota.c"


#include "./uds_server/uds_server.c"


#if 0

#include "./Common/Comm_Func.c"
//#include "./Protocol/Protocol.c"

#include "./hhsm/hhsm.c"
#include "./huadajiami/huadajiami.c"
#include "./sm2_chip/sm2_chip.c"


#include "./J5/J5.c"

//#include "./sjz_plat/sjz_plat.c"

#include "./zhongche_plat/zhongche_plat.c"



#include "./sensor_extern/sensor_extern.c"





#include "./back_protocol/back_protocol.c"

#include "./features/features.c"

#endif

