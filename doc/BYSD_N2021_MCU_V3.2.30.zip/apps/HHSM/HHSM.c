#include "HHSM.h"

/**************************************************************************
** �궨��
**************************************************************************/
#define M_HHSM_FRAME_HEAD0			(0xAA)	//֡ͷ1
#define M_HHSM_FRAME_HEAD1			(0x55)	//֡ͷ2
#define M_HHSM_FRAME_HEAD_LEN		(2)		//֡ͷ�ĳ���
#define M_HHSM_MAX_DATA_LEN			(1024)	//���1k����
#define M_HHSM_SINGLE_DATA_LEN		(16)	//�������ݳ���

#define M_HHSM_RECV_TRANSMIT_ERR	(0x3B)	//���մ������
#define M_HHSM_SEND_RE_HANDSHAKE	(0x3C)	//������������
#define M_HHSM_SEND_TANSMIT_FAIL	(0x3D)	//��η������ݳ��������ʹ���ʧ��

#define M_HHSM_RE_SEND_FAIL_CNT		(3)		//�ط���������
#define M_HHSM_RE_RECV_FAIL_CNT		(3)		//�ؽ��յ�������

#define M_HHSM_ACK_SUCC_H			(0x90)
#define M_HHSM_ACK_SUCC_L			(0x00)
/**************************************************************************
** �ṹ�嶨��
**************************************************************************/
/* �����ӿڽṹ�� */
typedef struct _hhsm_driver_func_st
{
	SPIInitFunc init;
	SPIWriteFunc write;
	SPIReadFunc read;
	CE_SetHigFunc enhigh;
	CE_SetLowFunc enlow;
	DelayMsFunc delayms;
	IsHHSMBusy _is_hhsm_busy;
}hhsm_driver_func_st;

/**************************************************************************
** ȫ�ֱ�������
**************************************************************************/
//�����ӿ�
static hhsm_driver_func_st s_hhsm_func;

//����ʧ�ܴ���
static u8 s_hhsm_send_fail_cnt = 0;

/**************************************************************************
** ��������
**************************************************************************/

/**************************************************************************
* ��  ��: void hhsm_wait_busy_to_free(void)
* ��  ��: �ȴ�HHSMоƬ���߿���
* ��  ��: 
* ��  ��: void
* ��  ��: void
* ����ֵ: void
**************************************************************************/
static void hhsm_wait_busy_to_free(void)
{
	u8 cnt = 0;
	
	while (s_hhsm_func._is_hhsm_busy ? s_hhsm_func._is_hhsm_busy() : 1)
	{
		if (s_hhsm_func.delayms)
		{
			s_hhsm_func.delayms(10);
		}

		cnt++;
		if (cnt >= 6)
		{
			break;
		}
	}

	//DBG_Print(LEVEL_GPRS, "hhsm_wait_busy_to_free cnt:%d\r\n", cnt);
}

/**************************************************************************
* ��  ��: int hhsm_send_cmd(u8 *data, u32 len)
* ��  ��: ����ָ������
* ��  ��: 
* ��  ��: u8 *data������������Ϣ
*		  u32 len:����������Ϣ����
* ��  ��: void
* ����ֵ: int �� -1 : ʧ�ܣ� 0 ���ͳɹ�
**************************************************************************/
static int hhsm_send_cmd(u8 *data, u32 len)
{
	int ret = -1;
	int index = 0;

	do
	{
		if ((0 == data) || (0 == len) || (len > get_big_mem_size()))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_send_cmd input data error\r\n");
			break;
		}

		if (s_hhsm_func.enlow)
		{
			s_hhsm_func.enlow();
		}

		if (s_hhsm_func.delayms)
		{
			s_hhsm_func.delayms(10);
		}

		if (s_hhsm_func.write)
		{
			s_hhsm_func.write(data, M_HHSM_FRAME_HEAD_LEN);
		}

		//DBG_PrintBuf(LEVEL0, "send Frame head:\r\n", data, M_HHSM_FRAME_HEAD_LEN);
		hhsm_wait_busy_to_free();

		index = 2;

		while(len > index)
		{
			if ((len - index) <= M_HHSM_SINGLE_DATA_LEN)
			{
				if (s_hhsm_func.write)
				{
					s_hhsm_func.write(&data[index], len - index);
					//DBG_PrintBuf(LEVEL0, "send Frame data:\r\n", &data[index], len - index);
				}
				hhsm_wait_busy_to_free();
				break;
			}

			if (s_hhsm_func.write)
			{
				s_hhsm_func.write(&data[index], M_HHSM_SINGLE_DATA_LEN);
				//DBG_PrintBuf(LEVEL0, "send Frame data[16]:\r\n", &data[index], M_HHSM_SINGLE_DATA_LEN);
				index += M_HHSM_SINGLE_DATA_LEN;
			}
			hhsm_wait_busy_to_free();
		}

		DBG_Print(LEVEL_GPRS, "hhsm_send_cmd ok\r\n");

		ret = 0;
	} while(0);

	return ret;
}

/**************************************************************************
* ��  ��: int hhsm_recv_data(u8 *data, u32 len)
* ��  ��: ���յ�����
* ��  ��: 
* ��  ��: u32 maxlen:�����������ݵ�������ݳ���
* ��  ��: u8 *data:��ȡ��������Ϣ
* ����ֵ: int 
			-1 : ���͹����г�����֧���ش������֧��3���ش�
			-2 : �������ݳ���̫��
			-3 : ��������
			 > 0 ��ȡ�����ݳ���
**************************************************************************/
static int hhsm_recv_data(u8 *data, u32 maxlen)
{
	int ret = -2;
	unsigned short recv_msg_len = 0;	//��Ч���ݵĳ���
	unsigned short recv_len = 0;					//�����������ݵĳ���
	u8 temp[M_HHSM_SINGLE_DATA_LEN] = {0};

	//crc�������½��յĴ������
	u8 crc = 0;
	static u8 crc_err_cnt = 0;

	do
	{
Recv:
		if (s_hhsm_func.read)
		{
			s_hhsm_func.read(M_HHSM_FRAME_HEAD_LEN, temp, sizeof(temp));
		}
		hhsm_wait_busy_to_free();

		//DBG_PrintBuf(LEVEL_GPRS, "Ack Frame Head:\r\n", temp,M_HHSM_FRAME_HEAD_LEN);

		if ((M_HHSM_FRAME_HEAD0 == temp[0]) && (M_HHSM_RECV_TRANSMIT_ERR == temp[1]))
		{
			//���͹�����������
			ret = -1;
			crc_err_cnt = 0;
			break;
		}
		else if ((M_HHSM_FRAME_HEAD0 == temp[0]) && (M_HHSM_SEND_RE_HANDSHAKE == temp[1]))
		{
			//���͹�����������
			ret = -1;
			crc_err_cnt = 0;
			break;
		}
		else if ((M_HHSM_FRAME_HEAD0 == temp[0]) && (M_HHSM_FRAME_HEAD1 == temp[1]))
		{
			//Ӧ��ɹ�
			memset(temp, 0, sizeof(temp));
			if (s_hhsm_func.read)
			{
				s_hhsm_func.read(M_HHSM_SINGLE_DATA_LEN, temp, sizeof(temp));
			}
			hhsm_wait_busy_to_free();

			//DBG_PrintBuf(LEVEL_GPRS, "Ack Data:\r\n", temp, M_HHSM_SINGLE_DATA_LEN);
		
			recv_msg_len = (((unsigned short)temp[0]) << 8) | temp[1];
			recv_msg_len += 1; //+1 �ǻ���һ��У����
			if (recv_msg_len > get_big_mem_size())
			{
				ret = -2;
				crc_err_cnt = 0;
				break;
			}

			//DBG_Print(LEVEL_GPRS, "recv msg len:%x\r\n", recv_msg_len);

			if (recv_msg_len <= (M_HHSM_SINGLE_DATA_LEN - M_HHSM_FRAME_HEAD_LEN))
			{
				memcpy(&data[recv_len], &temp[M_HHSM_FRAME_HEAD_LEN], recv_msg_len);
				recv_len += recv_msg_len;
			}
			else
			{
				memcpy(&data[recv_len], &temp[M_HHSM_FRAME_HEAD_LEN], M_HHSM_SINGLE_DATA_LEN - M_HHSM_FRAME_HEAD_LEN);
				recv_len += M_HHSM_SINGLE_DATA_LEN - M_HHSM_FRAME_HEAD_LEN;

				//ѭ����ȡ���յ�����
				while (recv_msg_len > recv_len)
				{
					memset(temp, 0, sizeof(temp));
					//����16���ֽ�
					if ((recv_msg_len - recv_len) >= M_HHSM_SINGLE_DATA_LEN)
					{
						if (s_hhsm_func.read)
						{
							s_hhsm_func.read(M_HHSM_SINGLE_DATA_LEN, temp, sizeof(temp));
						}
						hhsm_wait_busy_to_free();

						memcpy(&data[recv_len], temp, M_HHSM_SINGLE_DATA_LEN);
						recv_len += M_HHSM_SINGLE_DATA_LEN;
					}
					else
					{
						if (s_hhsm_func.read)
						{
							s_hhsm_func.read((recv_msg_len - recv_len), temp, sizeof(temp));
						}
						hhsm_wait_busy_to_free();

						memcpy(&data[recv_len], temp, recv_msg_len - recv_len);
						recv_len = recv_msg_len;
						break;
					}
				}
			}

			//DBG_PrintBuf(LEVEL_GPRS, "recv hex data:\r\n", data, recv_len);

			//����У��
			crc = CommSumCheckCode(data, (recv_len - 1));
			crc = ~crc;

			//DBG_Print(LEVEL_GPRS, "calc cr:%x, recv crc:%x\r\n", crc, data[recv_len - 1]);
			
			if (crc != data[recv_len - 1])
			{
				//��������г�������Ҫ����������������
				if (s_hhsm_func.write)
				{
					memset(temp, 0, sizeof(temp));
					temp[0] = M_HHSM_FRAME_HEAD0;
					temp[1] = M_HHSM_SEND_RE_HANDSHAKE;
					s_hhsm_func.write(temp, M_HHSM_FRAME_HEAD_LEN);
				}
				hhsm_wait_busy_to_free();

				crc_err_cnt++;
				if (crc_err_cnt >= M_HHSM_RE_RECV_FAIL_CNT)
				{
					//����3�ν��ն�ʧ�ܣ�����ֹ����
					if (s_hhsm_func.write)
					{
						memset(temp, 0, sizeof(temp));
						temp[0] = M_HHSM_FRAME_HEAD0;
						temp[1] = M_HHSM_SEND_TANSMIT_FAIL;
						s_hhsm_func.write(temp, M_HHSM_FRAME_HEAD_LEN);
					}
					hhsm_wait_busy_to_free();

					ret = -3;
					break;
				}

				//��Ҫ���½���
				memset(data, 0, maxlen);
				recv_len = 0;
				goto Recv;
			}

			//���ճɹ�
			ret = recv_len - 1;
		}
	} while(0);

	crc_err_cnt = 0;

	return ret;
}

/**************************************************************************
* ��  ��: int hhsm_send_cmd_data(u8 *data, u32 len, u8 *outdata, u32 maxlen)
* ��  ��: ����ָ�����ݵõ�����
* ��  ��: 
* ��  ��: u8 *data������������Ϣ
*		  u32 len:����������Ϣ����
*		  u32 maxlen:�����������ݵ�������ݳ���
* ��  ��: u8 *outdata:��ȡ��������Ϣ
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ��ȡ�����ݳ���
**************************************************************************/
static int hhsm_send_cmd_data(u8 *data, u32 len, u8 *outdata, u32 maxlen)
{
	int ret = -1;
	u8 crc = 0;
	static u8 *send_cmd = 0;
	u32 send_len = 0;
	u8 temp[M_HHSM_FRAME_HEAD_LEN] = {0};

	send_cmd = (u8 *)get_big_mem();
	if (send_cmd == 0)
	{
		return -1;
	}

	do
	{
		if ((0 == data) || (0 == len) || (0 == outdata) || (len > M_HHSM_MAX_DATA_LEN)
			|| (0 == maxlen) || (maxlen > get_big_mem_size()))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_send_cmd_data input data error\r\n");
			break;
		}

Send:
		//ͬ���ֽ�
		send_cmd[send_len++] = M_HHSM_FRAME_HEAD0;
		send_cmd[send_len++] = M_HHSM_FRAME_HEAD1;

		//����
		send_cmd[send_len++] = (u8)((len >> 8) & 0xff);
		send_cmd[send_len++] = (u8)(len & 0xff);

		//������
		memcpy(&send_cmd[send_len], data, len);
		send_len += len;

		//У��λ
		crc = CommSumCheckCode(&send_cmd[4], send_len - 4);
		send_cmd[send_len++] = ~crc;

		//DBG_PrintBuf(LEVEL_GPRS, "hhsm_send_cmd_data:\r\n", send_cmd, send_len);

		//���з���
		ret = hhsm_send_cmd(send_cmd, send_len);
		if (-1 == ret)
		{
			DBG_Print(LEVEL4, "hhsm_send_cmd_data send cmd fail\r\n");
			break;
		}
		
		//��������
		ret = hhsm_recv_data(outdata, maxlen);
		if (ret > 0)
		{
			//���ճɹ�
			//DBG_PrintBuf(LEVEL_GPRS, "hhsm recv data:\r\n", outdata, ret);

			//���ͽ��ճɹ���Ӧ��ָ��
			if (s_hhsm_func.write)
			{
				memset(temp, 0, sizeof(temp));
				temp[0] = M_HHSM_FRAME_HEAD0;
				temp[1] = M_HHSM_FRAME_HEAD0;
				s_hhsm_func.write(temp, M_HHSM_FRAME_HEAD_LEN);
			}
			hhsm_wait_busy_to_free();

			break;
		}
		else if (-1 == ret)
		{
			DBG_Print(LEVEL4, "hhsm_send_cmd_data need resend data\r\n");

			s_hhsm_send_fail_cnt++;
			if (s_hhsm_send_fail_cnt >= M_HHSM_RE_SEND_FAIL_CNT)
			{
				//����3�ξ���������ʧ�ܣ������ش�
				if (s_hhsm_func.write)
				{
					memset(temp, 0, sizeof(temp));
					temp[0] = M_HHSM_FRAME_HEAD0;
					temp[1] = M_HHSM_SEND_TANSMIT_FAIL;
					s_hhsm_func.write(temp, M_HHSM_FRAME_HEAD_LEN);
				}
				hhsm_wait_busy_to_free();

				ret = -1;
				break;
			}

			send_len = 0;
			goto Send;
		}
		else
		{
			DBG_Print(LEVEL4, "hhsm_send_cmd_data recv data fail\r\n");
			ret = -1;
			break;
		}
	} while(0);

	free_big_mem(send_cmd);

	if (s_hhsm_func.enhigh)
	{
		s_hhsm_func.enhigh();
	}

	s_hhsm_send_fail_cnt = 0;

	return ret;
}

/**************************************************************************
* ��  ��: void hhsm_select_app(void)
* ��  ��: ѡ��Ӧ��
* ��  ��: 
		//M->S 00a4 04 00 0E 6170706C65742E63746170703031
		//M<-S 9000
* ��  ��: void
* ��  ��: void
* ����ֵ: int �� -1 : ʧ�ܣ� 0 �ɹ�
**************************************************************************/
static int hhsm_select_app(void)
{
	int ret = -1;
	u8 temp[] ={
			0x00, 0xA4, 0x04, 0x00, 0x0E,
			0x61, 0x70, 0x70, 0x6C, 0x65,
			0x74, 0x2E, 0x63, 0x74, 0x61,
			0x70, 0x70, 0x30, 0x31};
	u8 ack[M_HHSM_SINGLE_DATA_LEN] = {0};

	ret = hhsm_send_cmd_data(temp, sizeof(temp), ack, sizeof(ack));
	if (-1 != ret)
	{
		if ((M_HHSM_ACK_SUCC_H == ack[0]) && (M_HHSM_ACK_SUCC_L == ack[1]))
		{
			DBG_Print(LEVEL4, "hhsm_select_app Ok.\r\n");
			return 0;
		}
	}

	return -1;
}

/**************************************************************************
* ��  ��: void hhsm_open_app(void)
* ��  ��: ��Ӧ��
* ��  ��: 
		//M->S 80110000021000
		//M<-S 9000
		
* ��  ��: void
* ��  ��: void
* ����ֵ: int �� -1 : ʧ�ܣ� 0 �ɹ�
**************************************************************************/
static int hhsm_open_app(void)
{
	int ret = -1;
	u8 temp[] ={0x80, 0x11, 0x00, 0x00, 0x02, 0x10, 0x00};
	u8 ack[M_HHSM_SINGLE_DATA_LEN] = {0};

	ret = hhsm_send_cmd_data(temp, sizeof(temp), ack, sizeof(ack));
	if (-1 != ret)
	{
		if ((M_HHSM_ACK_SUCC_H == ack[0]) && (M_HHSM_ACK_SUCC_L == ack[1]))
		{
			DBG_Print(LEVEL4, "hhsm_open_app Ok.\r\n");
			return 0;
		}
	}

	return -1;
}

/**************************************************************************
* ��  ��: void hhsm_open_container(void)
* ��  ��: ������
* ��  ��: 
		//M->S 80170000021000
		//M<-S 9000	
* ��  ��: void
* ��  ��: void
* ����ֵ: int �� -1 : ʧ�ܣ� 0 �ɹ�
**************************************************************************/
static int hhsm_open_container(void)
{
	int ret = -1;
	u8 temp[] ={0x80, 0x17, 0x00, 0x00, 0x02,0x10, 0x00};
	u8 ack[M_HHSM_SINGLE_DATA_LEN] = {0};

	ret = hhsm_send_cmd_data(temp, sizeof(temp), ack, sizeof(ack));
	if (-1 != ret)
	{
		if ((M_HHSM_ACK_SUCC_H == ack[0]) && (M_HHSM_ACK_SUCC_L == ack[1]))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_open_container Ok.\r\n");
			return 0;
		}
	}

	return -1;
}

/**************************************************************************
* ��  ��: void hhsm_open_container(void)
* ��  ��: ������
* ��  ��: 
		//M->S 80170000021000
		//M<-S 9000	
* ��  ��: void
* ��  ��: void
* ����ֵ: int �� -1 : ʧ�ܣ� 0 �ɹ�
**************************************************************************/
static int _hhsm_open_container(unsigned char idx)
{
	int ret = -1;
	u8 temp[] ={0x80, 0x17, 0x00, 0x00, 0x02,0x10, 0x00};
	u8 ack[M_HHSM_SINGLE_DATA_LEN] = {0};

	temp[6] = idx;
	ret = hhsm_send_cmd_data(temp, sizeof(temp), ack, sizeof(ack));
	if (-1 != ret)
	{
		if ((M_HHSM_ACK_SUCC_H == ack[0]) && (M_HHSM_ACK_SUCC_L == ack[1]))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_open_container Ok.\r\n");
			return 0;
		}
	}

	return -1;
}



/**************************************************************************
* ��  ��: int hhsm_read_chip_id(u8 *data, int maxlen)
* ��  ��: ��ȡоƬID
* ��  ��: 	
	M->S 8028 0000 0A
	M<-S 0010000000000000002B 9000
* ��  ��: int maxlen:��󳤶�����
* ��  ��: u8 *data����ȡоƬID
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 оƬID�ĳ���
**************************************************************************/
int hhsm_read_chip_id(u8 *data, int maxlen)
{
	int ret = -1;
	u8 temp[] ={0x80, 0x28, 0x00, 0x00, 0x0A};

	do
	{
		if ((0 == data) || (0 == maxlen))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_chip_id input fail.\r\n");
			break;
		}
	
		if (-1 == hhsm_select_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_chip_id hhsm_select_app fail.\r\n");
			break;
		}

		if (-1 == hhsm_open_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_chip_id hhsm_open_app fail.\r\n");
			break;
		}

		if (-1 == hhsm_open_container())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_chip_id hhsm_open_container fail.\r\n");
			break;
		}

		ret = hhsm_send_cmd_data(temp, sizeof(temp), data, maxlen);
		if (-1 != ret)
		{
			if ((M_HHSM_ACK_SUCC_H == data[ret - 2]) && (M_HHSM_ACK_SUCC_L == data[ret - 1]))
			{
				ret = ret - 2;
				break;
			}
		}

		ret = -1;
	} while(0);

	return ret;
}

//0��ʾ�ɹ� �����ʾʧ��
int _hhsm_write_public_private_key(unsigned char idx,
	void *public_key,unsigned int pb_len,void *private_key,unsigned int pv_len)
{
	int ret = -1;
	unsigned char data[16] = {0};
	//u8 temp[] ={0x80, 0x24, 0x01, 0x00, 0x00};
	unsigned int rlen = 0;
	unsigned char *temp = 0;


	temp = get_small_mem();
	if (temp == 0) return -1;

	do
	{
		if ((public_key == 0) || (pb_len == 0) 
		|| (private_key == 0) || (pv_len == 0))
		{
			break;
		}
		if (-1 == hhsm_select_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_public_key input fail.\r\n");
			break;
		}

		if (-1 == hhsm_open_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_public_key input fail.\r\n");
			break;
		}

		if (-1 == _hhsm_open_container(idx))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_public_key input fail.\r\n");
			break;
		}

		//80328000 63 1001 00 8ee63df7e84f195f6a3ae62c90db62b6aa30e09a52d7e9b05e9c23085e6ddef8059b11174b959b81c85a1e010e189a836d81342d6873566d3f1ecd7b06b423f0 58e0d61e89b69cf477199131d3e6c37bae5990fd865cca48f44382e6628a89c1
		//׼������
		memcpy(temp,"\x80\x32\x80\x00",4);
		rlen += 4;
		temp[rlen++] = 3 + pv_len + pb_len;
		
		temp[rlen++] = 0x10;
		temp[rlen++] = idx;
		temp[rlen++] = 0x00;

		memcpy(temp+rlen,public_key,pb_len);
		rlen += pb_len;
		memcpy(temp+rlen,private_key,pv_len);
		rlen += pv_len;

		ret = hhsm_send_cmd_data(temp, rlen, data, sizeof(data));
		if (-1 != ret)
		{
			if ((M_HHSM_ACK_SUCC_L == data[1]) && (M_HHSM_ACK_SUCC_H == data[0]))
			{
				ret = 0;
				break;
			}
		}

		ret = -1;
	} while(0);

	free_small_mem(temp);
	return ret;
}


//��˽Կ����A B C���� д�빫˽Կ��A
int hhsm_write_public_private_key(void *public_key,
					unsigned int pb_len,void *private_key,unsigned int pv_len)
{
	return _hhsm_write_public_private_key(0,public_key,pb_len,private_key,pv_len);
}

//д�빫˽Կ��B
int hhsm_write_public_private_keyB(void *public_key,
					unsigned int pb_len,void *private_key,unsigned int pv_len)
{
	return _hhsm_write_public_private_key(1,public_key,pb_len,private_key,pv_len);
}

//д�빫˽Կ��C
int hhsm_write_public_private_keyC(void *public_key,
					unsigned int pb_len,void *private_key,unsigned int pv_len)
{
	return _hhsm_write_public_private_key(2,public_key,pb_len,private_key,pv_len);
}



/**************************************************************************
* ��  ��: int hhsm_read_public_key(u8 *data, int maxlen)
* ��  ��: ��ȡ��Կ
* ��  ��: 	
	M->S 8024 01 00 00
	M<-S 00EA571DC72EABEBEF7953505C9CBB11875E68C16CF1ACA2BB087C
		 A91A00F4A52989F4D6351BC4A287CBE8431A119CE2B13013EF76E1ACB28B356E9C801B6AB47D 9000
	
* ��  ��: int maxlen����󳤶�����
* ��  ��: u8 *data:��ȡ�Ĺ�Կ
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ��Կ�ĳ���
**************************************************************************/
int _hhsm_read_public_key(unsigned char idx,u8 *data, int maxlen)
{
	int ret = -1;
	u8 temp[] ={0x80, 0x24, 0x01, 0x00, 0x00};

	do
	{
		if ((0 == data) || (0 == maxlen))
		{
			break;
		}
	
		if (-1 == hhsm_select_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_public_key input fail.\r\n");
			break;
		}

		if (-1 == hhsm_open_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_public_key input fail.\r\n");
			break;
		}

		if (-1 == _hhsm_open_container(idx))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_read_public_key input fail.\r\n");
			break;
		}

		ret = hhsm_send_cmd_data(temp, sizeof(temp), data, maxlen);
		if (-1 != ret)
		{
			if ((M_HHSM_ACK_SUCC_L == data[0]) && (M_HHSM_ACK_SUCC_H == data[ret - 2])
				&& (M_HHSM_ACK_SUCC_L == data[ret - 1]))
			{
				int i = 0;

				for (i = 0; i < (ret - 3); i++)
				{
					data[i] = data[i + 1];
				}

				ret = ret - 3;
				break;
			}
		}

		ret = -1;
	} while(0);

	return ret;
}


/**************************************************************************
* ��  ��: int hhsm_read_public_key(u8 *data, int maxlen)
* ��  ��: ��ȡ��Կ
* ��  ��: 	
	M->S 8024 01 00 00
	M<-S 00EA571DC72EABEBEF7953505C9CBB11875E68C16CF1ACA2BB087C
		 A91A00F4A52989F4D6351BC4A287CBE8431A119CE2B13013EF76E1ACB28B356E9C801B6AB47D 9000
	
* ��  ��: int maxlen����󳤶�����
* ��  ��: u8 *data:��ȡ�Ĺ�Կ
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ��Կ�ĳ���
**************************************************************************/
int hhsm_read_public_key(u8 *data, int maxlen)
{
	return _hhsm_read_public_key(0,data,maxlen);
}


/**************************************************************************
* ��  ��: int hhsm_read_public_keyB(u8 *data, int maxlen)
* ��  ��: ��ȡ��ԿB
* ��  ��: 	
	M->S 8024 01 00 00
	M<-S 00EA571DC72EABEBEF7953505C9CBB11875E68C16CF1ACA2BB087C
		 A91A00F4A52989F4D6351BC4A287CBE8431A119CE2B13013EF76E1ACB28B356E9C801B6AB47D 9000
	
* ��  ��: int maxlen����󳤶�����
* ��  ��: u8 *data:��ȡ�Ĺ�Կ
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ��Կ�ĳ���
**************************************************************************/
int hhsm_read_public_keyB(u8 *data, int maxlen)
{
	return _hhsm_read_public_key(1,data,maxlen);
}


/**************************************************************************
* ��  ��: int hhsm_read_public_keyC(u8 *data, int maxlen)
* ��  ��: ��ȡ��ԿC
* ��  ��: 	
	M->S 8024 01 00 00
	M<-S 00EA571DC72EABEBEF7953505C9CBB11875E68C16CF1ACA2BB087C
		 A91A00F4A52989F4D6351BC4A287CBE8431A119CE2B13013EF76E1ACB28B356E9C801B6AB47D 9000
	
* ��  ��: int maxlen����󳤶�����
* ��  ��: u8 *data:��ȡ�Ĺ�Կ
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ��Կ�ĳ���
**************************************************************************/
int hhsm_read_public_keyC(u8 *data, int maxlen)
{
	return _hhsm_read_public_key(2,data,maxlen);
}


/**************************************************************************
* ��  ��: int hhsm_send_singal_data(u8 *data, u32 len, u8 last_flag, u8 *outdata)
* ��  ��: ���͵�������
* ��  ��: 	
	
* ��  ��: u8 *data:һ������
*	      u8 len:һ������
*		  u8 last_flag�����һ��
* ��  ��: u8 *outdata����������һ��������Ҫ����������
* ����ֵ: int �� -1 : ʧ�ܣ�>= 0 �ɹ�
**************************************************************************/
static int hhsm_send_singal_data(u8 *data, u32 len, u8 last_flag, u8 *outdata)
{
	int ret = -1;
	static u8 ack[80] = {0};

	//��������
	ret = hhsm_send_cmd_data(data, len, ack, sizeof(ack));
	if (-1 != ret)
	{
		if ((M_HHSM_ACK_SUCC_H == ack[ret - 2]) && (M_HHSM_ACK_SUCC_L == ack[ret - 1]))
		{
			if (1 == last_flag)
			{
				memcpy(outdata, ack, ret - 2);
				return ret - 2;
			}
			else
			{
				return 0;
			}
		}
	}

	return -1;
}

/**************************************************************************
* ��  ��: int hhsm_read_calc_hash(u8 *data, u32 len, u8 *outdata, int maxlen)
* ��  ��: �����ϣֵ
* ��  ��: 	
	
* ��  ��: u8 *data, u32 len, int maxlen
* ��  ��: u8 *outdata��
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ��ϣֵ�ĳ���
**************************************************************************/
int hhsm_read_calc_hash(u8 *data, u32 len, u8 *outdata, int maxlen)
{
	int ret = -1;
	u8 *temp = 0;
	int templen = 0;
	int msglen = 0;
	u8 index = 0;

	do
	{
		temp = (u8 *)get_big_mem();
		if (!temp)
		{
			break;
		}		

		if (len <= 0x7f)
		{
			temp[templen++] = 0x80;
			temp[templen++] = 0x31;

			temp[templen++] = 0x80;	//���һ��
			temp[templen++] = 0x00;
			temp[templen++] = (u8)(len & 0x7f);

			memcpy(&temp[templen], data, len);
			templen += (u8)(len & 0x7f);

			ret = hhsm_send_singal_data(temp, templen, 1, outdata);
			if (ret > 0)
			{
				break;
			}
		}
		else
		{
			//�ֶη���
			while (len > msglen)
			{
				memset(temp, 0, get_big_mem_size());
				templen = 0;
				temp[templen++] = 0x80;
				temp[templen++] = 0x31;

				if ((len - msglen) <= 0x7f)
				{
					temp[templen++] = 0x80;	//���һ��
					temp[templen++] = index++;
					temp[templen++] = (u8)((len - msglen) & 0x7f);

					memcpy(&temp[templen], &data[msglen], len - msglen);
					templen += (u8)((len - msglen) & 0x7f);

					//����
					ret = hhsm_send_singal_data(temp, templen, 1, outdata);
					if (ret > 0)
					{
						DBG_Print(LEVEL_GPRS, "hhsm_send_singal_data, 1, succ\r\n");
						msglen = len;
						break;
					}
					else
					{
						DBG_Print(LEVEL_GPRS, "hhsm_send_singal_data, 1, Fail\r\n");
						ret = -1;
						break;
					}
				}
				else
				{
					temp[templen++] = 0x00;//�ֶ�
					temp[templen++] = index++;
					temp[templen++] = 0x7f;

					memcpy(&temp[templen], &data[msglen], 0x7f);
					templen += 0x7f;

					//����
					ret = hhsm_send_singal_data(temp, templen, 0, 0);
					if (0 == ret)
					{
						DBG_Print(LEVEL_GPRS, "hhsm_send_singal_data, 0, succ\r\n");
						msglen += 0x7f;
					}
					else
					{
						DBG_Print(LEVEL_GPRS, "hhsm_send_singal_data, 0, Fail\r\n");
						ret = -1;
						break;
					}
				}
			}
		}
	} while(0);

	if (temp)
	{
		free_big_mem(temp);
		temp = 0;
	}

	return ret;
}

/**************************************************************************
* ��  ��: int hhsm_read_sign_data(u8 *data, u32 len, u8 *outdata, int maxlen)
* ��  ��: ��ȡǩ������
* ��  ��: 	
	M->S 8024 01 00 00
	M<-S 00EA571DC72EABEBEF7953505C9CBB11875E68C16CF1ACA2BB087C
		 A91A00F4A52989F4D6351BC4A287CBE8431A119CE2B13013EF76E1ACB28B356E9C801B6AB47D 9000
	
* ��  ��: u8 data:������Ҫǰ�������
*		  u32 len:����
*		  int maxlen:�õ�ǩ�����ݵ������������
* ��  ��: u8 *outdata���õ�ǩ������
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 оƬID�ĳ���
**************************************************************************/
int hhsm_read_sign_data(u8 *data, u32 len, u8 *outdata, int maxlen)
{
	int ret = -1;
	//static u8 hash_val[33] = {0};
	u8 *hash_val = 0;
	u8 *temp = 0;
	u32 templen = 0;

	do
	{
		if ((0 == data) || (0 == maxlen) || (0 == outdata) || (0 == maxlen))
		{
			break;
		}
	
		if (-1 == hhsm_select_app())
		{
			break;
		}

		if (-1 == hhsm_open_app())
		{
			break;
		}

		if (-1 == hhsm_open_container())
		{
			break;
		}

		hash_val = (u8 *)get_micro_mem();
		if (!hash_val)
		{
			DBG_Print(LEVEL_GPRS, "hhsm_send_cmd_data get_micro_mem fail .\r\n");
			break;
		}

		//�ȼ���Ķ���ϣֵ
		ret = hhsm_read_calc_hash(data, len, hash_val, sizeof(hash_val));
		if (-1 == ret)
		{
			DBG_Print(LEVEL_GPRS, "hhsm_send_cmd_data hhsm_read_calc_hash fail.\r\n");
			break;
		}

		temp = (u8 *)get_small_mem();
		if (!temp)
		{
			break;
		}

		DBG_PrintBuf(LEVEL_GPRS, "��ϣֵ:\r\n", hash_val, ret);

		//���ݹ�ϣֵ��ȡǩ��ֵ
		temp[templen++] = 0x80;
		temp[templen++] = 0x25;
		temp[templen++] = 0x00;
		temp[templen++] = 0x00;
		temp[templen++] = (u8)((ret + 2) & 0xff);

		//����ID
		temp[templen++] = 0x10;
		temp[templen++] = 0x00;

		//��ϣֵ
		memcpy(&temp[templen], hash_val, (ret & 0xff));
		templen += (ret & 0xff);
		
		ret = hhsm_send_cmd_data(temp, templen, outdata, maxlen);
		if (-1 != ret)
		{
			if ((M_HHSM_ACK_SUCC_H == outdata[ret - 2]) && (M_HHSM_ACK_SUCC_L == outdata[ret - 1]))
			{
				ret = ret - 2;
				break;
			}
		}

		ret = -1;
	} while(0);

	if (hash_val)
	{
		free_micro_mem(hash_val);
		hash_val = 0;
	}

	if (temp)
	{
		free_small_mem(temp);
		temp = 0;
	}

	return ret;
}

/* ��������ô��Ϣ��ZAֵ */
const u8 g_protocol_za_val[] =
{
 0xFF, 0xFF, 0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
 0xFF, 0xFC, 0x28, 0xE9, 0xFA, 0x9E, 0x9D, 0x9F, 0x5E, 0x34,
 0x4D, 0x5A, 0x9E, 0x4B, 0xCF, 0x65, 0x09, 0xA7, 0xF3, 0x97,
 0x89, 0xF5, 0x15, 0xAB, 0x8F, 0x92, 0xDD, 0xBC, 0xBD, 0x41,
 0x4D, 0x94, 0x0E, 0x93, 0x32, 0xC4, 0xAE, 0x2C, 0x1F, 0x19,
 0x81, 0x19, 0x5F, 0x99, 0x04, 0x46, 0x6A, 0x39, 0xC9, 0x94,
 0x8F, 0xE3, 0x0B, 0xBF, 0xF2, 0x66, 0x0B, 0xE1, 0x71, 0x5A,
 0x45, 0x89, 0x33, 0x4C, 0x74, 0xC7, 0xBC, 0x37, 0x36, 0xA2,
 0xF4, 0xF6, 0x77, 0x9C, 0x59, 0xBD, 0xCE, 0xE3, 0x6B, 0x69,
 0x21, 0x53, 0xD0, 0xA9, 0x87, 0x7C, 0xC6, 0x2A, 0x47, 0x40,
 0x02, 0xDF, 0x32, 0xE5, 0x21, 0x39, 0xF0, 0xA0
};



static int _ProtocolCalcZaHashVal(void *chip_id,unsigned int chip_id_len,
									void *public_key,unsigned int public_key_len,
									u8 *za_hash, u32 maxlen)
{
	int ret = -1;
	u8 *temp = 0;
	int templen = 0;

	do
	{
		temp = get_small_mem();
		if (!temp)
		{
			break;
		}

		//00 80 + ChipID + ZA_val + PubKey
		temp[templen++] = 0x00;
		temp[templen++] = 0x80;
		memcpy(&temp[templen], chip_id,chip_id_len);
		templen += chip_id_len;

		memcpy(&temp[templen], g_protocol_za_val, sizeof(g_protocol_za_val));
		templen += sizeof(g_protocol_za_val);

		memcpy(&temp[templen],public_key, public_key_len);
		templen += public_key_len;

		DBG_PrintBuf(LEVEL1, "�̶�ֵ+��Կ\r\n", temp, templen);
		ret = hhsm_read_calc_hash(temp, templen, za_hash, maxlen);
		if (-1 == ret)
		{
			DBG_Print(LEVEL0, "ProtocolFilingData hhsm_read_calc_hash fail.\r\n");
			break;
		}

		DBG_PrintBuf(LEVEL1, "ZA(��ϣֵ)\r\n", za_hash, ret);
	} while(0);

	free_small_mem(temp);

	return ret;
}



//��Zֵ��ǩ�� ����ֵ:С��0��ʾʧ�� ����-66 ��ʾ�����tempbuff������̫С
//����ֵ������ ��ʾ ���ǩ���ĳ���
int hhsm_read_sign_data_with_z(void *chip_id,unsigned int chip_id_len,
							void *public_key,unsigned int public_key_len,
							void *dat, unsigned int datlen,
							void *pOutSign,unsigned int outbuflen)
{
	int templen = 0;
	unsigned char *pTempBuff = 0;

	if ((pOutSign == 0) || (outbuflen ==0)
	|| (chip_id == 0) || (chip_id_len == 0) || (public_key == 0)
	|| (public_key_len == 0) || (dat == 0) || (datlen == 0)
	)
	{
		return -1;
	}
	pTempBuff = get_big_mem();

	if (pTempBuff == 0)
	{
		return -2;
	}
	templen = _ProtocolCalcZaHashVal(chip_id,chip_id_len,public_key,
									public_key_len,pTempBuff,
									get_big_mem_size());

	if (templen > 0)
	{
		memcpy(pTempBuff + templen,dat,datlen);
	}
	else
	{
		memcpy(pTempBuff,dat,datlen);
		templen = 0;
	}
	templen = hhsm_read_sign_data(pTempBuff,templen + datlen,pOutSign,outbuflen);
	free_big_mem(pTempBuff);
	return templen;
}


/**************************************************************************
* ��  ��: int hhsm_private_key_decrypt_encrypt(u8 type, u8 *data, u32 len, u8 *outdata, int maxlen)
* ��  ��: �����������ݣ���˽�ܽ��н���,����
* ��  ��: 	
* ��  ��: u8 type: �������ͣ� 0 - ˽Կ���ܣ�1 - ��Կ����
*		  u8 data:��������
*		  u32 len:�������ݳ���
*		  int maxlen:����������ݳ���
* ��  ��: u8 *outdata�������������
* ����ֵ: int �� -1 : ʧ�ܣ� > 0 ����������ݳ���
**************************************************************************/
int _hhsm_private_key_decrypt_encrypt(unsigned char idx,u8 type, u8 *data, u32 len, u8 *outdata, int maxlen)
{
	int ret = -1;
	static u8 temp[270] = {0};
	int templen = 0;
	u8 ack[16] = {0};
	u8 index = 0;			//�����
	int msg_len = 0;
	u8 flag = 0;
	static u8 recv_data[512] = {0};

	do
	{
		if ((0 == data) || (0 == len) || (len > M_HHSM_MAX_DATA_LEN)
			|| (0 == outdata) || (0 == maxlen) || (maxlen > get_big_mem_size()))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_private_key_decrypt_encrypt input error.\r\n");
			break;
		}
		
		if (-1 == hhsm_select_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_private_key_decrypt_encrypt input fail.\r\n");
			break;
		}

		if (-1 == hhsm_open_app())
		{
			DBG_Print(LEVEL_GPRS, "hhsm_private_key_decrypt_encrypt input fail.\r\n");
			break;
		}

		if (-1 == _hhsm_open_container(idx))
		{
			DBG_Print(LEVEL_GPRS, "hhsm_private_key_decrypt_encrypt input fail.\r\n");
			break;
		}

		if (len <= (0xff - 5))
		{
			temp[templen++] = 0x80;
			temp[templen++] = (0 == type) ? (0x26) : ((1 == type) ? (0x36) : (0x32));

			temp[templen++] = 0x82;
			temp[templen++] = 0x00;
			temp[templen++] = (u8)((len + 5) & 0xff);

			//������
			temp[templen++] = 0x10;
			temp[templen++] = idx;

			//AlgFlag
			temp[templen++] = 0x00;

			//���ĳ���
			temp[templen++] = (u8)((len >> 8) & 0xff);
			temp[templen++] = (u8)(len & 0xff);

			//������Ϣ
			memcpy(&temp[templen], data, len);
			templen += len;

			//��������
			ret = hhsm_send_cmd_data(temp, templen, ack, sizeof(ack));
			if (-1 == ret)
			{
				DBG_Print(LEVEL_GPRS, "hhsm_private_key_decrypt_encrypt hhsm_send_cmd_data fail.\r\n");
				break;
			}

			if (!((M_HHSM_ACK_SUCC_H == ack[ret - 2]) && (M_HHSM_ACK_SUCC_L == ack[ret - 1])))
			{
				DBG_Print(LEVEL_GPRS, "hhsm_private_key_decrypt_encrypt ack data[%x][%x].\r\n",
					ack[ret - 2], ack[ret - 1]);
				break;
			}

			//ȡ����
			templen = 0;
			memset(temp, 0, sizeof(temp));
			temp[templen++] = 0x80;
			temp[templen++] = (0 == type) ? (0x26) : (0x36);

			temp[templen++] = 0xC2;
			temp[templen++] = 0x00;
			temp[templen++] = 0x00;

			memset(recv_data, 0, sizeof(recv_data));
			ret = hhsm_send_cmd_data(temp, templen, recv_data, sizeof(recv_data));
			if (ret > 0)
			{
				if ((M_HHSM_ACK_SUCC_H == recv_data[ret - 2]) && (M_HHSM_ACK_SUCC_L == recv_data[ret - 1]))
				{
					ret = (int)(((unsigned short)(recv_data[0]) << 8) | recv_data[1]);
					memcpy(outdata, &recv_data[2], ret);
					break;
				}
			}
			ret = -1;
			break;
		}

		//���ȴ���0xff - 5���ֽڣ���Ҫ�ֶη���
		while (len > msg_len)
		{
			templen = 0;
			memset(temp, 0, sizeof(temp));

			if ((0 == index) || ((index >= 1) && ((len - msg_len) >= 0xff)))
			{
				//ǰ������ݣ��ֶδ���
				temp[templen++] = 0x80;
				temp[templen++] = (0 == type) ? (0x26) : (0x36);

				temp[templen++] = 0x02;
				temp[templen++] = index;
				temp[templen++] = 0xff;

				if (0 == index)
				{
					//������
					temp[templen++] = 0x10;
					temp[templen++] = idx;

					//AlgFlag
					temp[templen++] = 0x00;

					//���ĳ���
					temp[templen++] = (u8)((len >> 8) & 0xff);
					temp[templen++] = (u8)(len & 0xff);

					//������Ϣ
					memcpy(&temp[templen], &data[msg_len], (0xff - 5));
					templen += (0xff - 5);
				}
				else
				{
					//������Ϣ
					memcpy(&temp[templen], &data[msg_len], 0xff);
					templen += 0xff;
				}

				//��������
				ret = hhsm_send_cmd_data(temp, templen, ack, sizeof(ack));
				if (-1 != ret)
				{
					if ((M_HHSM_ACK_SUCC_H == ack[ret - 2]) && (M_HHSM_ACK_SUCC_L == ack[ret - 1]))
					{
						if (0 == index)
						{
							DBG_Print(LEVEL_GPRS, "send first package[%d], msg_len:%d, len:%d, ok\r\n", index, msg_len, len);
							msg_len += (0xff - 5);
						}
						else if ((index >= 1) && ((len - msg_len) >= 0xff))
						{
							DBG_Print(LEVEL_GPRS, "send package[%d], msg_len:%d, len:%d, ok\r\n", index, msg_len, len);
							msg_len += 0xff;
						}
						index++;
						continue;
					}
				}

				ret = -1;
				break;
			}
			else if ((len - msg_len) <= 0xff)
			{
				//���һ������
				temp[templen++] = 0x80;
				temp[templen++] = (0 == type) ? (0x26) : (0x36);

				temp[templen++] = 0x82;
				temp[templen++] = index;
				temp[templen++] = (u8)((len - msg_len) & 0xff);

				//������Ϣ
				memcpy(&temp[templen], &data[msg_len], (len - msg_len));
				templen += (len - msg_len);

				//��������
				ret = hhsm_send_cmd_data(temp, templen, ack, sizeof(ack));
				if (-1 != ret)
				{
					if ((M_HHSM_ACK_SUCC_H == ack[ret - 2]) && (M_HHSM_ACK_SUCC_L == ack[ret - 1]))
					{
						DBG_Print(LEVEL_GPRS, "send last package[%d], msg_len:%d, len:%d, ok\r\n", index, msg_len, len);
						msg_len = len;
						index++;
						flag = 1;
						break;
					}
				}

				ret = -1;
				break;
			}
		}

		if (flag)
		{
			u8 i = 0;
			int recv_len = 0;
			u16 recv_msg_len = 0;

			//ȡ����/��������
			for (i = 0; i < index; i++)
			{
				templen = 0;
				memset(temp, 0, sizeof(temp));

				temp[templen++] = 0x80;
				temp[templen++] = (0 == type) ? (0x26) : (0x36);

				temp[templen++] = (0 == type) ? (0xC2) : (0x42);

				temp[templen++] = i;
				temp[templen++] = 0x00;
				//temp[templen++] = 0x00;

				memset(recv_data, 0, sizeof(recv_data));

				//���Ͷ�ȡ����ָ��
				ret = hhsm_send_cmd_data(temp, templen, recv_data, sizeof(recv_data));
				if (-1 != ret)
				{
					if ((M_HHSM_ACK_SUCC_H == recv_data[ret - 2]) && (M_HHSM_ACK_SUCC_L == recv_data[ret - 1]))
					{
						if (0 == i)
						{
							//��һ�ξͰ��������ݵĳ��ȴ�����
							recv_msg_len = (u16)(((u16)recv_data[0]) << 8 | recv_data[1]);
							if (recv_msg_len > maxlen)
							{
								ret = -1;
								DBG_Print(LEVEL_GPRS, "read indexx[%d], recv_msg_len:%d > maxlen\r\n",
									    index, recv_msg_len, maxlen);
								break;
							}

							memcpy(&outdata[recv_len], &recv_data[2], ret - 4);
							recv_len += ret - 4;
						}
						else
						{
							//����ֻ������
							memcpy(&outdata[recv_len], &recv_data[0], ret - 2);
							recv_len += ret - 2;
						}
					}
				}

				if (i == (index - 1))
				{
					DBG_Print(LEVEL_GPRS, "read indexx[%d], recv_msg_len:%d, recv_len\r\n",
									    		index, recv_msg_len, recv_len);
					if (recv_msg_len == recv_len)
					{
						ret = recv_len;
					}
					else
					{
						ret = -1;
					}
					break;
				}
			}
		}
	} while(0);

	return ret;
}

//ʹ��A�鹫˽Կ�Լӽ���
int hhsm_private_key_decrypt_encrypt(u8 type, u8 *data, u32 len, u8 *outdata, int maxlen)
{
	return _hhsm_private_key_decrypt_encrypt(0,type,data,len,outdata,maxlen);
}

//ʹ��B�鹫˽Կ�Լӽ���
int hhsm_private_key_decrypt_encryptB(u8 type, u8 *data, u32 len, u8 *outdata, int maxlen)
{
	return _hhsm_private_key_decrypt_encrypt(1,type,data,len,outdata,maxlen);
}

//ʹ��C�鹫˽Կ�Լӽ���
int hhsm_private_key_decrypt_encryptC(u8 type, u8 *data, u32 len, u8 *outdata, int maxlen)
{
	return _hhsm_private_key_decrypt_encrypt(2,type,data,len,outdata,maxlen);
}



//���Խӿ�
int hhsm_test(void)
{
	int ret = -1;
	u8 *data = 0;
	int ret1 = -1;
	u8 count = 0;
	char key_ok_flag = 0;
	char chipid_ok_flag = 1;

	data = (u8 *)get_small_mem();
	if (data == 0)
	{
		DBG_Print(LEVEL0, "hhsm_test data get_big_mem fail.\r\n");
		return -1;
	}

	do
	{
		memset(data, 0, get_small_mem_size());
		ret = hhsm_read_public_key(data, get_small_mem_size());
		if (ret > 0)
		{
			DBG_PrintBuf(LEVEL0, "��ԿKey:\r\n", data, ret);
			key_ok_flag = 1;
		}

		memset(data, 0, get_small_mem_size());
		ret = hhsm_read_chip_id(data, get_small_mem_size());
		if (ret > 0)		//������оƬID ֤���Ǿ�оƬ оƬ���� �������ش���
		{
			DBG_PrintBuf(LEVEL0, "оƬID:\r\n", data, ret);
			chipid_ok_flag = 0;
			ret1 = -10;
			break;
		}
		else			//������оƬID ��������ȷ��
		{
			//chipid_ok_flag = 1;
		}

		//оƬID��PubKey��OK��־ ����ȷ����
		if (chipid_ok_flag && key_ok_flag)
		{
			ret1 = 0;
			break;
		}
		count++;			
	}while(count < 3);

	free_small_mem(data);

	return ret1;
}

/**************************************************************************
* ��  ��: void hhsm_init
* ��  ��: ��ʼ������оƬ�������ӿ�
* ��  ��: 
* ��  ��: SPIInitFunc pSPIInit:��ʼ��
	      SPIWriteFunc pSPIWrite:д
		  SPIReadFunc pSPIRead:��
		  CE_SetHigFunc pSetCeHigh:ʹ������
		  CE_SetLowFunc pSetCeLow:ʹ������
		  DelayMsFunc pDelayms:��ʱ
* ��  ��: void
* ����ֵ: void
**************************************************************************/
void hhsm_init(SPIInitFunc pSPIInit,
					  SPIWriteFunc pSPIWrite,
					  SPIReadFunc pSPIRead,
					  CE_SetHigFunc pSetCeHigh,
					  CE_SetLowFunc pSetCeLow,
					  DelayMsFunc pDelayms,
					  IsHHSMBusy _is_hhsm_busy)
{
	memset(&s_hhsm_func, 0, sizeof(s_hhsm_func));
	s_hhsm_func.init = pSPIInit;
	s_hhsm_func.write = pSPIWrite;
	s_hhsm_func.read = pSPIRead;	
	s_hhsm_func.enhigh = pSetCeHigh;
	s_hhsm_func.enlow = pSetCeLow;	
	s_hhsm_func.delayms = pDelayms;
	s_hhsm_func._is_hhsm_busy = _is_hhsm_busy;

	if (s_hhsm_func.init)
	{
		s_hhsm_func.init();
	}
}

#if 0
typedef struct tagHHSMType
{
	SPIInitFunc pSPIInit;
	SPIWriteFunc pSPIWrite;
	SPIReadFunc pSPIRead;

	CE_SetHigFunc pSetCeHigh;
	CE_SetLowFunc pSetCeLow;
	DelayMsFunc pDelayms;
}HHSMType;

HHSMType s_stHHSM = {0};

#define SPI_CMD_HEAD0 0xAA
#define SPI_CMD_HEAD1 0x55
#define SPI_CMD_HEAD_LEN 2


int pack_spi_cmd(void *pdat,u32 datlen,void *pOutBuf,u32 outbuflen)
{
	u32 rlen = 0;
	u8 xor = 0;
	u8 *ptr = (u8 *)pOutBuf;

	if ((pOutBuf == 0) || (outbuflen < (datlen + 2 + 2 + 1)))
	{
		return 0;
	}

	//֡ͷ
	ptr[rlen++] = SPI_CMD_HEAD0;
	ptr[rlen++] = SPI_CMD_HEAD1;

	//���ݳ���
	ptr[rlen++] = datlen >> 8;
	ptr[rlen++] = datlen;

	//������
	if (pdat && datlen)
	{
		memcpy(ptr + rlen,pdat,datlen);
		rlen += datlen;
	}

	//У��λ
	xor = CommSumCheckCode((u8 *)pdat, datlen);
	xor = ~xor;
	ptr[rlen++] = xor;
	return rlen;
}

void hhsm_wait_busy(void)
{
	//if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(10);

#if 1
	u8 cnt = 0;
	
	while (GPIO_ReadInputDataBit(HHSM_INT_PORT,HHSM_INT_PIN))
	{
		s_stHHSM.pDelayms(5);
		cnt++;
		if (cnt >= 50)
		{
			break;
		}
	}
#endif
}

u32 _send_spi_cmd(void *pdat,u32 datlen,void *pOutAckBuf,u32 OutAckBufLen)
{
	u32 i = 0;
	u8 j = 0;
	u8 xor = 0;
	u8 temp[16] = {0};
	u8 aucTemp[18] = {0};
	u8 *ptr = (u8 *)pdat;
	u32 rlen = 0;
	u32 slen = 0;
	u8 *pOutPtr = (u8 *)pOutAckBuf;

	if ((pdat == 0) || (datlen == 0))
	{
		return 0;
	}
	if (s_stHHSM.pSetCeLow) s_stHHSM.pSetCeLow();
	if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(10);

	DBG_Print(LEVEL3,"spi send cmd head:%02X %02X\r\n",SPI_CMD_HEAD0,SPI_CMD_HEAD1);

	temp[0] = SPI_CMD_HEAD0;
	temp[1] = SPI_CMD_HEAD1;
	s_stHHSM.pSPIWrite(temp,SPI_CMD_HEAD_LEN);
	hhsm_wait_busy();

	xor = CommSumCheckCode((u8 *)pdat, datlen);
	xor = ~xor;

	for (i = 0; i < (datlen + 2 + 1); )
	{
		for (j = 0; (j < 16) && (i < (datlen + 2 + 1)); j++)
		{
			if (i == 0)
			{
				temp[j] = datlen >> 8;
			}
			else if (i == 1)
			{
				temp[j] = datlen;
			}
			else if (i == (datlen + 2))
			{
				temp[j] = xor;
			}
			else
			{
				temp[j] = *(ptr + i - 2);
			}
			
			i++;
		}
		s_stHHSM.pSPIWrite(temp,j);
		DBG_PrintBuf(LEVEL3,"spi send:",temp,j);
		hhsm_wait_busy();
	}

	//�������Э�鷢�����ָ���ȴ�оƬ�ظ�
	hhsm_wait_busy();
	//if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(50);

#if 1
	//���Ƚ���2���ֽڵ���Ϣ֡ͷ
	s_stHHSM.pSPIRead(SPI_CMD_HEAD_LEN,temp,sizeof(temp));
	memcpy(aucTemp,temp,SPI_CMD_HEAD_LEN);
	DBG_PrintBuf(LEVEL3,"hhsm ack head:",temp,SPI_CMD_HEAD_LEN);
	//if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(50);
	hhsm_wait_busy();
	
#if 0
		if ((temp[0] != SPI_CMD_HEAD0) || (temp[1] != SPI_CMD_HEAD1))
		{
			if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(50);
			
			if (s_stHHSM.pSetCeHigh) s_stHHSM.pSetCeHigh();
			return 0;
		}
#endif

	//ʣ�µ����ݰ���һ�����ֻ�ܶ�ȡ16���ֽڵ�ԭ�� ֱ������ȡ��
	s_stHHSM.pSPIRead(16,temp,sizeof(temp));
	memcpy(aucTemp + SPI_CMD_HEAD_LEN,temp,16);

	ptr = aucTemp;

	rlen = (ptr[SPI_CMD_HEAD_LEN] << 8) + ptr[SPI_CMD_HEAD_LEN + 1];		//���ݳ���

	if (rlen > 4096)
	{
		if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(10);
		if (s_stHHSM.pSetCeHigh) s_stHHSM.pSetCeHigh();
		DBG_PrintBuf(LEVEL3,"hhsm ack:",temp,16);
		return 0;
	}

	rlen++;		//��һ��У��λ
	if (rlen <= (16 - 2))
	{
		DBG_PrintBuf(LEVEL3,"hhsm ack finish:",temp,2 + rlen);
		if (pOutPtr)
		{
			memcpy(pOutPtr,temp + 2,((rlen - 1) > OutAckBufLen) ? OutAckBufLen : (rlen - 1));
		}
	}
	else
	{
		DBG_PrintBuf(LEVEL3,"hhsm ack:",temp,16);

		if (pOutPtr)
		{
			memcpy(pOutPtr,temp + 2,(14 > OutAckBufLen) ? OutAckBufLen : 14);
		}
		slen = 14;
		while (slen < rlen)
		{
			DBG_Print(LEVEL3,"hhsm recv ack:%d/%d\r\n",slen,rlen);
			//if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(10);
			hhsm_wait_busy();
			
			if ((rlen - slen) >= 16)
			{
				s_stHHSM.pSPIRead(16,temp,sizeof(temp));
				DBG_PrintBuf(LEVEL3,"hhsm ack:",temp,16);
				if (pOutPtr)
				{
					memcpy(pOutPtr + slen,temp,(16 > (OutAckBufLen - slen)) ? (OutAckBufLen - slen) : 16);
				}

				slen += 16;
			}
			else
			{
				s_stHHSM.pSPIRead(rlen - slen,temp,sizeof(temp));
				DBG_PrintBuf(LEVEL3,"hhsm ack:",temp,rlen - slen);
				if (pOutPtr)
				{
					memcpy(pOutPtr + slen,temp,((rlen - slen) > (OutAckBufLen - slen)) ? (OutAckBufLen - slen) : (rlen - slen));
				}
				slen += (rlen - slen);
			}
		}
	}
#endif

	//if (s_stHHSM.pDelayms) s_stHHSM.pDelayms(10);

	temp[0] = 0xAA;
	temp[1] = 0xAA;
	s_stHHSM.pSPIWrite(temp,2);
	//hhsm_wait_busy();
	DBG_Print(LEVEL3,"master ack:AA AA\r\n");
	
	if (s_stHHSM.pSetCeHigh) s_stHHSM.pSetCeHigh();

	return (rlen - 1);
}

int execute_cmd(void *pdat,int len)
{
	u8 ret[2] = {0};

	_send_spi_cmd(pdat,len,ret,2);
	if ((ret[0] == 0x90) && (ret[1] == 0x00))
	{
		return 0;
	}
	else
	{
		DBG_PrintBuf(LEVEL0,"cmd:\r\n",pdat,len);
		DBG_PrintBuf(LEVEL0,"execute false:",ret,2);
		return 1;
	}
}


#if 0
SEND 00a40400 0E6170706C65742E63746170703031
ASSERT 9000
#endif

int hhsm_start(void)
{
	return execute_cmd("\x00\xA4\x04\x00\x0E\x61\x70\x70\x6C\x65\x74\x2E\x63\x74\x61\x70\x70\x30\x31",19);
}

#if 0
2����ȡоƬID

SEND 00a40400 0E6170706C65742E63746170703031
ASSERT 9000
;��ȡID
SEND 8028 0000 0A
ASSERT 011480520800901200009000
#endif

u8 hhsm_read_chip_id(void *pOutBuf,u32 OutBufLen)
{
	u8 rlen = 0;

	hhsm_start();

	rlen = _send_spi_cmd("\x80\x28\x00\x00\x0A",5,pOutBuf,OutBufLen);
	if (rlen > 2)
	{
		rlen -= 2;
	}
	return rlen;
}

int open_application(void)
{
	return execute_cmd("\x80\x11\x00\x00\x02\x10\x00",7);
}

int open_container1(void)
{
	return execute_cmd("\x80\x17\x00\x00\x02\x10\x00",7);
}

int open_container2(void)
{
	return execute_cmd("\x80\x17\x00\x00\x02\x10\x01",7);
}

#if 0
SEND 8024 01 00 00
ASSERT 6C41
SEND 8024 01 00 41
ASSERT 00 C1CF526779F91943F0C88F2413E11502F780C1F6B49F299133A504D11B7D5020732224B1F555E92CAB0BB83EDABE33F00491B974DE0465326E58A9A16AF513B6 9000

#endif

int _import_keyA(void *pOutBuf,u32 outbuflen)
{
	u8 ack[2] = {0};
	u8 cmd[] = {0x80,0x24,0x01,0x00,0x41};

	_send_spi_cmd("\x80\x24\x01\x00\x00",5,ack,2);
	if (ack[0] != 0x61)
	{
		return 0;
	}
	cmd[4] = ack[1];
	return _send_spi_cmd(cmd,5,0,0);
}

int hhsm_import_keyA(void *pOutBuf,u32 outbuflen)
{
	hhsm_start();
	open_application();
	open_container1();
	return _import_keyA(pOutBuf,outbuflen);
}

int _read_public_keyA(void *pOutBuf,u32 outbuflen)
{
	u32 rlen = 0;
	u8 cmd[] = {0x80,0x24,0x01,0x00,0x00};
	static u8 s_p_keyA[64 + 3] = {0};

	rlen = _send_spi_cmd(cmd,5,s_p_keyA,sizeof(s_p_keyA));

	if (rlen > 3)
	{
		rlen -= 3;
	}
	if (pOutBuf && outbuflen)
	{
		memcpy(pOutBuf,s_p_keyA + 1,(rlen > outbuflen) ? outbuflen : rlen);
	}
	return rlen;
}

//��ȡ��ԿA
int hhsm_read_public_keyA(void *pOutBuf,u32 outbuflen)
{
	hhsm_start();
	open_application();
	open_container1();
	return _read_public_keyA(pOutBuf,outbuflen);
}


int _private_signA(void *pdat,u32 len,void *pOutBuf,u32 outbuflen)
{
	static u8 cmd[1024] = {0x80,0x25,0x00,0x00,0x22,0x10,0x00};
	//u8 readcmd[] = {0x00,0xC0,0x00,0x00,0x40};
	u32 rlen = 0;

	if ((pdat == 0) || (len == 0))
	{
		return 0;
	}

	cmd[4] = len + 2;
	memcpy(cmd + 7,pdat,len);

	rlen = _send_spi_cmd(cmd,7 + len,pOutBuf,outbuflen);
	if (rlen > 2)
	{
		rlen -= 2;
	}
	return rlen;
}

#if 0
SEND 00a40400 0E6170706C65742E63746170703031
ASSERT 9000
;open application
send 8011000002 1000
assert 9000 ;time:5
;open container 1
send 8017000002 1000
assert 9000 ;time:5
;ǩ��
SEND 802500 00 22 1000 7de6843fcd2dd2b75912e8b5d396e78aff58a10ee3d4dd285862720c0772909b
ASSERT 52B3B419322A8C7037BDB382196F9E049F61E862B149542A80025FDC6146E52B6C26CCB752436C54C98A0785C151FBBE66D6B850534B55755A829DB682EFBD659000
#endif
int hhsm_private_signA(void *pdat,u32 len,void *pOutBuf,u32 outbuflen)
{
	hhsm_start();
	open_application();
	open_container1();
	return _private_signA(pdat,len,pOutBuf,outbuflen);
}




#if 0
SEND 8026 8200  A5   1000 00 00A0 566ACD2FEAA155FDA43D06412CECEAD439849CD6B68BA3C1F9E3474D7C8ED70C6FAC3028F0CE2BD71860C1B0609DB21587ABBC14730E2093AC43D8B61CF516A03EEC86DE4EC899CB5E2A5A60E0349D25B4910CB74E70686CEE9C892DC29F25083695EA705DAE578F92272ADF07061872B6DF8CA909556866DC58FB52954C85F535FCD3F110D3735C5F88AB53EC7F10350419A73E541B8BB4572ED9941FC056F0
ASSERT 9000
SEND 8026 C200  00
ASSERT 6C42
SEND 8026 C200  42
ASSERT 0040 xxxxxxxxxxx9000
#endif
int _private_decryptA(void *pdat,u32 len,void *pOutBuf,u32 outbuflen)
{
	u32 rlen = 0;
	static u8 cmd[1024] = {0x80,0x26,0x82,0x00,0xA5,0x10,0x00,0x00,0x00,0x40};
	u8 readcmd[] = {0x80,0x26,0xC2,0x00,0x00};

	if ((pdat == 0) || (len == 0))
	{
		return 0;
	}

	cmd[8] = len >> 8;
	cmd[9] = len;
	memcpy(cmd + 10,pdat,len);

	_send_spi_cmd(cmd,10 + len,0,0);
	rlen = _send_spi_cmd(readcmd,sizeof(readcmd),pOutBuf,outbuflen);
	if (rlen <= 4)
	{
		return 0;
	}
	else
	{
		if (pOutBuf && outbuflen)
		{
			memcpy(pOutBuf,(u8 *)pOutBuf + 2,rlen - 4);
			return (rlen - 4);
		}
	}
	return 0;
}


int hhsm_private_decryptA(void *pdat,u32 len,void *pOutBuf,u32 outbuflen)
{
	hhsm_start();
	open_application();
	open_container1();
	return _private_decryptA(pdat,len,pOutBuf,outbuflen);
}

//�������ݵĹ�ϣֵ
int calc_hash_val(void *pdata, u32 len, void *poutbuf, u32 outbuflen)
{
	int ret = 0;
	int datalen = 0;
	u8 *temp = (u8 *)get_big_mem();
	u8 recv_data[64 + 1] = {0};
	u8 recv_len = 0;

	do
	{
		if (temp)
		{
			if (len <= 0xff)
			{
				temp[datalen++] = 0x80;
				temp[datalen++] = 0x31;

				//һ�������ϣֵ
				temp[datalen++] = 0x80;
				temp[datalen++] = 0x00;
				temp[datalen++] = len;
				memcpy(&temp[datalen], pdata, len);
				datalen += len;

				datalen = _send_spi_cmd(temp, datalen, poutbuf,outbuflen);
				if (datalen <= 2)
				{
					break;
				}
				else
				{
					if (poutbuf)
					{
						ret = datalen - 2;
						break;
					}
				}
			}
			else
			{
				u32 index = 0;
			
				do
				{
					if ((len - index) <= 0xff )
					{
						//�ְ������ϣֵ
						temp[datalen++] = 0x80;
						temp[datalen++] = 0x31;

						//һ�������ϣֵ
						temp[datalen++] = 0x00;
						temp[datalen++] = 0x00;
						temp[datalen++] = len;
						memcpy(&temp[datalen], pdata, len);
						datalen += len;

						memset(recv_data, 0, sizeof(recv_data));
	 					recv_len = _send_spi_cmd(temp, datalen, recv_data, sizeof(recv_data) - 1);
					}
 					
				} while(len > 0);
			}
		}
	}while(0);

	if (temp)
	{
		free_big_mem(temp);
		temp = 0;
	}

	return ret;
}

//�������ݵ�����
int hhsm_calc_hash_val(void *pdata, u32 len, void *poutbuf, u32 outbuflen)
{
	hhsm_start();
	open_application();
	open_container1();
	return calc_hash_val(pdata,len,poutbuf,outbuflen);
}

int hhsm_init(	SPIInitFunc pSPIInit,
					SPIWriteFunc pSPIWrite,
					SPIReadFunc pSPIRead,
					CE_SetHigFunc pSetCeHigh,
					CE_SetLowFunc pSetCeLow,
					DelayMsFunc pDelayms)
{
	s_stHHSM.pSPIInit = pSPIInit;
	s_stHHSM.pSPIWrite = pSPIWrite;
	s_stHHSM.pSPIRead = pSPIRead;	
	s_stHHSM.pSetCeHigh = pSetCeHigh;
	s_stHHSM.pSetCeLow = pSetCeLow;	
	s_stHHSM.pDelayms = pDelayms;

	if (s_stHHSM.pSPIInit)
	{
		s_stHHSM.pSPIInit();
	}
	return 0;
}

#if 0
void hhsm_test1(void)
{
	static u8 spi_rx_buff[128] = {0};
	static INT8U spi_tx_buff1[] = {0xAA, 0x55};
	static INT8U spi_tx_buff2[] = {0x00, 0x13, 0x00, 0xA4, 0x04, 0x00, 0x0E, 0x61, 0x70, 0x70, 0x6C, 0x65, 0x74, 0x2E, 0x63, 0x74};
	static INT8U spi_tx_buff3[] = {0x61, 0x70, 0x70, 0x30, 0x31, 0x14};
	static INT8U spi_tx_buff4[] = {0xAA, 0xAA};		   

	if (s_stHHSM.pSetCeLow)
	{
		s_stHHSM.pSetCeLow();
	}

	if (s_stHHSM.pDelayms)
	{
		s_stHHSM.pDelayms(100); //100 ms
	}

	memset(spi_rx_buff, 0x22, sizeof(spi_rx_buff));
	s_stHHSM.pSPIWrite(spi_tx_buff1, sizeof(spi_tx_buff1));  
	s_stHHSM.pSPIWrite(spi_tx_buff2, sizeof(spi_tx_buff2));
	s_stHHSM.pSPIWrite(spi_tx_buff3, sizeof(spi_tx_buff3));
	s_stHHSM.pSPIRead(2,spi_rx_buff, 2);

	DBG_PrintBuf(LEVEL5,"hhsm ack head:",spi_rx_buff,2);
	s_stHHSM.pSPIRead(5,spi_rx_buff, 5);

	DBG_PrintBuf(LEVEL5,"hhsm ack:",spi_rx_buff,5);
	s_stHHSM.pSPIWrite(spi_tx_buff4, sizeof(spi_tx_buff4));
	if (s_stHHSM.pSetCeHigh)
	{
		s_stHHSM.pSetCeHigh();
	}

	if (s_stHHSM.pDelayms)
	{
		s_stHHSM.pDelayms(100); // 100 ms
	}
}
#endif

char hhsm_test(void)
{
	char ret = 0;
	unsigned short i = 0;
	u32 rlen = 0;
	u8 *pOutBuf = 0;
	u8 *ptr = 0;

	pOutBuf = get_big_mem();
	ptr = get_small_mem();

	if ((ptr == 0) || (pOutBuf == 0))
	{
		free_big_mem(pOutBuf);
		free_small_mem(ptr);
		return 1;
	}

	rlen = hhsm_read_chip_id(pOutBuf,get_big_mem_size());
	DBG_PrintBuf(LEVEL0,"keyid:\r\n",pOutBuf,rlen);

	rlen = hhsm_read_public_keyA(pOutBuf,get_big_mem_size());
	DBG_PrintBuf(LEVEL0,"public keyA:\r\n",pOutBuf,rlen);

	//���ַ���"LFCS_HHSM"���м���
	DBG_PrintBuf(LEVEL0,"raw data:\r\n","LFCS_HHSM",9);
	rlen = hhsm_public_encryptionA("LFCS_HHSM",9,pOutBuf,get_big_mem_size());
	DBG_PrintBuf(LEVEL0,"encryption:\r\n",pOutBuf,rlen);

	//����
	rlen = hhsm_private_decryptA(pOutBuf,rlen,ptr,get_small_mem_size());
	if (rlen < get_small_mem_size())
	{
		ptr[rlen] = 0;
		if (strcmp((char *)ptr,"LFCS_HHSM") == 0)
		{
			ret = 0;
		}
		else
		{
			ret = 2;
		}
	}
	else
	{
		ret = 3;
	}
	DBG_PrintBuf(LEVEL0,"decrypt:\r\n",ptr,rlen);

	//�����ܳ��������ݽ���ǩ��
	memset(ptr, 0, get_small_mem_size());
	for (i = 0; i < 33; i++)
	{
		ptr[i] = i;
	}
	rlen = 33;

	memset(pOutBuf, 0, get_big_mem_size());
	rlen = hhsm_calc_hash_val(ptr, rlen, pOutBuf, get_big_mem_size());
	DBG_PrintBuf(LEVEL0,"hash val:\r\n", pOutBuf,rlen);

	
	memset(ptr, 0, get_small_mem_size());
	rlen = hhsm_private_signA(pOutBuf,rlen, ptr,get_small_mem_size());
	DBG_PrintBuf(LEVEL0,"signA:\r\n", ptr,rlen);

	free_big_mem(pOutBuf);
	free_small_mem(ptr);
	return ret;

}
#endif

