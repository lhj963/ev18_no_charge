#include "CN6.h"


typedef struct tagDataInfo
{
	INT8U *pVIN;
	INT8U Ver;
	INT8U Way;
}DataInfo;


DataInfo sDataInfo = {0};


typedef struct tagSaveData
{
	INT16U usLoginFlow;			//��¼��ˮ ����Ϊ��λ
	INT16U usRealInfoFlow;		//ʵʱ��Ϣ��ˮ ����Ϊ��λ
	INT16U usSupplyInfoFlow;	//������Ϣ��ˮ ����Ϊ��λ

	INT16U usHjLoginFlow;			//��¼��ˮ ����Ϊ��λ
	INT16U usHjRealInfoFlow;		//ʵʱ��Ϣ��ˮ ����Ϊ��λ
	INT16U usHjSupplyInfoFlow;	//������Ϣ��ˮ ����Ϊ��λ
}SaveData;
SaveData stSaveData = {0};



//���
int DataBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,void *pDataUnit,INT16U usDataUnitLen)
{
	INT16U len = 0;
	INT8U *pbuf = (INT8U *)pOutBuf;

	if (pbuf == 0)
	{
		return 0;
	}
	//�жϻ�������С
	//��ʼ��(2B)+������(1B)+VIN(17B)+�����汾��(1B)+���ܷ�ʽ(1B)+���ݵ�Ԫ����(2B)+���ݵ�Ԫ����(usDataUnitLen)+У��(1B)
	if (usOutBufSize < (2+1+LEN_VIN+1+1+2+usDataUnitLen+1))
	{
		return 0;
	}
	//��ʼ�ַ��� 2B
	pbuf[len++] = HEAD0;
	pbuf[len++] = HEAD1;

	//���Ԫ 1B
	pbuf[len++] = cmd;

	//����ʶ���
	memcpy(pbuf + len,sDataInfo.pVIN,LEN_VIN);
	len += LEN_VIN;

	//�ն˰汾�� 1B
	pbuf[len++] = sDataInfo.Ver;

	//���ݼ��ܷ�ʽ	1B
	pbuf[len++] = sDataInfo.Way;

	//���ݵ�Ԫ����	2B
	pbuf[len++] = usDataUnitLen >> 8;
	pbuf[len++] = usDataUnitLen;

	//���ݵ�Ԫ
	if (pDataUnit && usDataUnitLen)
	{
		memcpy(pbuf + len,pDataUnit,usDataUnitLen);
		len += usDataUnitLen;
	}

	//���У��
	pbuf[len++] = XOR_Check(pbuf+2,len-2);

	return len;
}


void CN6_Init(void *szVIN,INT8U Ver,INT8U Way)
{
	sDataInfo.pVIN = szVIN;
	sDataInfo.Ver = Ver;
	sDataInfo.Way = Way;
}

//��¼��
int LoginDataPacket(void *pOutBuf,INT16U usOutBufSize,INT8U BCDTime[6],void *szICCID)
{
	INT8U temp[32] = {0};
	INT8U len = 0;
	char *p = (char *)szICCID;

	if ((BCDTime == 0) || (szICCID == 0))
	{
		return 0;
	}

	//ʱ��
	memcpy(temp + len,BCDTime,6);
	len += 6;

	//��ˮ��
	stSaveData.usLoginFlow++;
	temp[len++] = stSaveData.usLoginFlow >> 8;
	temp[len++] = stSaveData.usLoginFlow;

	//ICCID
	if ((strlen(p) + 8) <= sizeof(temp))
	{
		strcpy((char *)(temp + len),p);
		len += strlen(p);
	}
	else
	{
		memcpy(temp + len,p,sizeof(temp) - 8);
		len += (sizeof(temp) - 8);
	}

	return DataBag(pOutBuf,usOutBufSize,CMD_LOGIN,temp,len);
}



//��¼��
int SHLoginDataPacket(void *pOutBuf,INT16U usOutBufSize,INT8U BCDTime[6],void *szICCID)
{
	INT8U temp[32] = {0};
	INT8U len = 0;
	char *p = (char *)szICCID;

	if ((BCDTime == 0) || (szICCID == 0))
	{
		return -1;
	}

	//ʱ��
	memcpy(temp + len,BCDTime,6);
	len += 6;

	//��ˮ��
	temp[len++] = 0;
	temp[len++] = 0;
	stSaveData.usLoginFlow++;
	temp[len++] = stSaveData.usLoginFlow >> 8;
	temp[len++] = stSaveData.usLoginFlow;

	//ICCID
	if ((strlen(p) + 8) <= sizeof(temp))
	{
		strcpy((char *)(temp + len),p);
		len += strlen(p);
	}
	else
	{
		memcpy(temp + len,p,sizeof(temp) - 8);
		len += (sizeof(temp) - 8);
	}

	return DataBag(pOutBuf,usOutBufSize,CMD_LOGIN,temp,len);
}

//�ǳ���
int LogoutDataPacket(void *pOutBuf,INT16U usOutBufSize,INT8U BCDTime[6],void *szICCID)
{
	INT8U temp[32] = {0};
	INT8U len = 0;
	//char *p = (char *)szICCID;

	if ((BCDTime == 0) || (szICCID == 0))
	{
		return 0;
	}

	//ʱ��
	memcpy(temp + len,BCDTime,6);
	len += 6;

	//��ˮ��
	temp[len++] = stSaveData.usLoginFlow >> 8;
	temp[len++] = stSaveData.usLoginFlow;

#if 0
	//ICCID
	if ((strlen(p) + 8) <= sizeof(temp))
	{
		strcpy((char *)(temp + len),p);
		len += strlen(p);
	}
	else
	{
		memcpy((char *)(temp + len),p,sizeof(temp) - 8);
		len += (sizeof(temp) - 8);

	}
#endif
	return DataBag(pOutBuf,usOutBufSize,CMD_LOGOUT,temp,len);
}


//�ն�Уʱ��
int CalibrationTimePacket(void *pOutBuf,INT16U usOutBufSize)
{
	return DataBag(pOutBuf,usOutBufSize,CMD_CALIBRATIONTIME,0,0);
}



int SHOBDInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,OBDInfo *pOBDInfo)
{
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	INT8U i = 0;
	INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pOBDInfo == 0)) return -1;

	usDataUnitLen = 6+1+2+6+LEN_VIN+LEN_SOFTVER+LEN_CVN+LEN_IUPR+1+4 * pOBDInfo->ucDTCTotalNum;	//���ݵ�Ԫ����

	if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	{
		return 0;	//the buf have no enough size
	}
	//���ݲɼ�ʱ��
	memcpy(ptr,pOBDInfo->BCDTime,6);
	len += 6;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usRealInfoFlow++;
	ptr[len++] = stSaveData.usRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usRealInfoFlow;
	//��Ϣ���ͱ�־
	ptr[len++] = OBD_INFO;

	//OBD��Ϣ��
	ptr[len++] = pOBDInfo->ucOBDProtocol;
	ptr[len++] = pOBDInfo->ucMilStatus;
	ptr[len++] = pOBDInfo->usSupportStatus >> 8;
	ptr[len++] = pOBDInfo->usSupportStatus;
	ptr[len++] = pOBDInfo->usReadyStatus >> 8;
	ptr[len++] = pOBDInfo->usReadyStatus;

	//memcpy(ptr + len, sDataInfo.pVIN, LEN_VIN);
	memcpy(ptr + len,pOBDInfo->szVIN,LEN_VIN);
	len += LEN_VIN;

	memcpy(ptr + len, pOBDInfo->szCalid, LEN_SOFTVER);
	len += LEN_SOFTVER;

	memcpy(ptr + len, pOBDInfo->szCVN, LEN_CVN);
	len += LEN_CVN;
	
	memcpy(ptr + len, pOBDInfo->szIUPR, LEN_IUPR);
	len += LEN_IUPR;

	ptr[len++] = pOBDInfo->ucDTCTotalNum;

	if (pOBDInfo->ucDTCTotalNum && (pOBDInfo->ucDTCTotalNum < 0xFE))
	{
		for (i = 0; i < pOBDInfo->ucDTCTotalNum; i++)
		{
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 0);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 1);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 2);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 3);
		}

	}
	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}



int OBDInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,OBDInfo *pOBDInfo)
{
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	INT8U i = 0;
	INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pOBDInfo == 0)) return -1;

	usDataUnitLen = 6+1+2+6+LEN_VIN+LEN_SOFTVER+LEN_CVN+LEN_IUPR+1+4 * pOBDInfo->ucDTCTotalNum;	//���ݵ�Ԫ����

	if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	{
		return -2;	//the buf have no enough size
	}
	//���ݲɼ�ʱ��
	memcpy(ptr,pOBDInfo->BCDTime,6);
	len += 6;
	//��Ϣ���ͱ�־
	ptr[len++] = OBD_INFO;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usRealInfoFlow++;
	ptr[len++] = stSaveData.usRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usRealInfoFlow;

	//OBD��Ϣ��
	ptr[len++] = pOBDInfo->ucOBDProtocol;
	ptr[len++] = pOBDInfo->ucMilStatus;
	ptr[len++] = pOBDInfo->usSupportStatus >> 8;
	ptr[len++] = pOBDInfo->usSupportStatus;
	ptr[len++] = pOBDInfo->usReadyStatus >> 8;
	ptr[len++] = pOBDInfo->usReadyStatus;

	//memcpy(ptr + len, sDataInfo.pVIN, LEN_VIN);
	memcpy(ptr + len,pOBDInfo->szVIN,LEN_VIN);
	len += LEN_VIN;

	memcpy(ptr + len, pOBDInfo->szCalid, LEN_SOFTVER);
	len += LEN_SOFTVER;

	memcpy(ptr + len, pOBDInfo->szCVN, LEN_CVN);
	len += LEN_CVN;
	
	memcpy(ptr + len, pOBDInfo->szIUPR, LEN_IUPR);
	len += LEN_IUPR;

	ptr[len++] = pOBDInfo->ucDTCTotalNum;

	if (pOBDInfo->ucDTCTotalNum < 0xFE)
	{
		for (i = 0; i < pOBDInfo->ucDTCTotalNum; i++)
		{
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 0);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 1);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 2);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 3);
		}

	}
	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}


int DataStreamInfoBagEx(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
								DataStreamInfo *pDataStreamInfo1,
								unsigned int bagcnt,char is_17691)
{
	DataStreamInfo *pDataStreamInfo = pDataStreamInfo1;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pDataStreamInfo == 0) || (bagcnt == 0)) return -1;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return -2;	//the buf have no enough size
	//}

	//���ݲɼ�ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;

	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		//��Ϣ���ͱ�־
		ptr[len++] = DATA_STREAM_INFO;

		if (is_17691)
		{
			//ֻҪһ����ˮ��
			if (i == 0)
			{
				//ʵʱ��Ϣ��ˮ��
				stSaveData.usRealInfoFlow++;
				ptr[len++] = stSaveData.usRealInfoFlow >> 8;
				ptr[len++] = stSaveData.usRealInfoFlow;
			}
		}
		else
		{
			//ʵʱ��Ϣ��ˮ��
			stSaveData.usRealInfoFlow++;
			ptr[len++] = stSaveData.usRealInfoFlow >> 8;
			ptr[len++] = stSaveData.usRealInfoFlow;
		}
		
		//��������Ϣ��
		ptr[len++] = pDataStreamInfo->usSpeed >> 8;
		ptr[len++] = pDataStreamInfo->usSpeed;
		
		ptr[len++] = pDataStreamInfo->uckPa;
		
		ptr[len++] = pDataStreamInfo->cActualTorquePercent;
		ptr[len++] = pDataStreamInfo->cFrictionTorquePercent;
		ptr[len++] = pDataStreamInfo->usRPM >> 8;
		ptr[len++] = pDataStreamInfo->usRPM;
		
		ptr[len++] = pDataStreamInfo->usFuelFlow >> 8;
		ptr[len++] = pDataStreamInfo->usFuelFlow;
		
		ptr[len++] = pDataStreamInfo->sUpperNOx >> 8;
		ptr[len++] = pDataStreamInfo->sUpperNOx;
		
		ptr[len++] = pDataStreamInfo->sLowerNOx >> 8;
		ptr[len++] = pDataStreamInfo->sLowerNOx;
		ptr[len++] = pDataStreamInfo->ucRemain;
		
		ptr[len++] = pDataStreamInfo->usIntakeVolume >> 8;
		ptr[len++] = pDataStreamInfo->usIntakeVolume;
		
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature;
		
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature;
		
		ptr[len++] = pDataStreamInfo->usDPF >> 8;
		ptr[len++] = pDataStreamInfo->usDPF;
		
		ptr[len++] = pDataStreamInfo->cCoolantTemperature;
		
		ptr[len++] = pDataStreamInfo->ucLevel;
		ptr[len++] = pDataStreamInfo->ucGpsStatus;
		
		ptr[len++] = pDataStreamInfo->ulLong >> 24; 
		ptr[len++] = pDataStreamInfo->ulLong >> 16;
		ptr[len++] = pDataStreamInfo->ulLong >> 8;
		ptr[len++] = pDataStreamInfo->ulLong;
		
		ptr[len++] = pDataStreamInfo->ulLat >> 24;	
		ptr[len++] = pDataStreamInfo->ulLat >> 16;
		ptr[len++] = pDataStreamInfo->ulLat >> 8;
		ptr[len++] = pDataStreamInfo->ulLat;
		
		ptr[len++] = pDataStreamInfo->ulMilage >> 24;	
		ptr[len++] = pDataStreamInfo->ulMilage >> 16;
		ptr[len++] = pDataStreamInfo->ulMilage >> 8;
		ptr[len++] = pDataStreamInfo->ulMilage;


		//��Ϣ���ͱ�־
		ptr[len++] = KELIWUCHUANGANQI_INFO;

		ptr[len++] = pDataStreamInfo->guangxishouxishu >> 8;
		ptr[len++] = pDataStreamInfo->guangxishouxishu;

		ptr[len++] = pDataStreamInfo->butouguangdu >> 8;
		ptr[len++] = pDataStreamInfo->butouguangdu;

		ptr[len++] = pDataStreamInfo->keliwunongdu >> 8;
		ptr[len++] = pDataStreamInfo->keliwunongdu;

	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}


int DataStreamInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
								DataStreamInfo *pDataStreamInfo1,
								unsigned int bagcnt,char is_17691)
{
	DataStreamInfo *pDataStreamInfo = pDataStreamInfo1;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pDataStreamInfo == 0) || (bagcnt == 0)) return -1;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return -2;	//the buf have no enough size
	//}

	//���ݲɼ�ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;

	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		//��Ϣ���ͱ�־
		ptr[len++] = DATA_STREAM_INFO;

		if (is_17691)
		{
			//ֻҪһ����ˮ��
			if (i == 0)
			{
				//ʵʱ��Ϣ��ˮ��
				stSaveData.usRealInfoFlow++;
				ptr[len++] = stSaveData.usRealInfoFlow >> 8;
				ptr[len++] = stSaveData.usRealInfoFlow;
			}
		}
		else
		{
			//ʵʱ��Ϣ��ˮ��
			stSaveData.usRealInfoFlow++;
			ptr[len++] = stSaveData.usRealInfoFlow >> 8;
			ptr[len++] = stSaveData.usRealInfoFlow;
		}
		
		//��������Ϣ��
		ptr[len++] = pDataStreamInfo->usSpeed >> 8;
		ptr[len++] = pDataStreamInfo->usSpeed;
		
		ptr[len++] = pDataStreamInfo->uckPa;
		
		ptr[len++] = pDataStreamInfo->cActualTorquePercent;
		ptr[len++] = pDataStreamInfo->cFrictionTorquePercent;
		ptr[len++] = pDataStreamInfo->usRPM >> 8;
		ptr[len++] = pDataStreamInfo->usRPM;
		
		ptr[len++] = pDataStreamInfo->usFuelFlow >> 8;
		ptr[len++] = pDataStreamInfo->usFuelFlow;
		
		ptr[len++] = pDataStreamInfo->sUpperNOx >> 8;
		ptr[len++] = pDataStreamInfo->sUpperNOx;
		
		ptr[len++] = pDataStreamInfo->sLowerNOx >> 8;
		ptr[len++] = pDataStreamInfo->sLowerNOx;
		ptr[len++] = pDataStreamInfo->ucRemain;
		
		ptr[len++] = pDataStreamInfo->usIntakeVolume >> 8;
		ptr[len++] = pDataStreamInfo->usIntakeVolume;
		
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature;
		
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature;
		
		ptr[len++] = pDataStreamInfo->usDPF >> 8;
		ptr[len++] = pDataStreamInfo->usDPF;
		
		ptr[len++] = pDataStreamInfo->cCoolantTemperature;
		
		ptr[len++] = pDataStreamInfo->ucLevel;
		ptr[len++] = pDataStreamInfo->ucGpsStatus;
		
		ptr[len++] = pDataStreamInfo->ulLong >> 24; 
		ptr[len++] = pDataStreamInfo->ulLong >> 16;
		ptr[len++] = pDataStreamInfo->ulLong >> 8;
		ptr[len++] = pDataStreamInfo->ulLong;
		
		ptr[len++] = pDataStreamInfo->ulLat >> 24;	
		ptr[len++] = pDataStreamInfo->ulLat >> 16;
		ptr[len++] = pDataStreamInfo->ulLat >> 8;
		ptr[len++] = pDataStreamInfo->ulLat;
		
		ptr[len++] = pDataStreamInfo->ulMilage >> 24;	
		ptr[len++] = pDataStreamInfo->ulMilage >> 16;
		ptr[len++] = pDataStreamInfo->ulMilage >> 8;
		ptr[len++] = pDataStreamInfo->ulMilage;
	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}

int DataStreamAndObdInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
										OBDInfo *pOBDInfo,
										DataStreamInfo *pDataStreamInfo1,
										unsigned int bagcnt,char is_17691)
{
	DataStreamInfo *pDataStreamInfo = pDataStreamInfo1;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOBDInfo == 0) || (pOutBuf == 0) || (pDataStreamInfo == 0) || (bagcnt == 0)) return 0;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return -2;	//the buf have no enough size
	//}

	//���ݲɼ�ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;

	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		if (i == 0)
		{
			//��Ϣ���ͱ�־
			ptr[len++] = OBD_INFO;
			//ʵʱ��Ϣ��ˮ��
			stSaveData.usRealInfoFlow++;
			ptr[len++] = stSaveData.usRealInfoFlow >> 8;
			ptr[len++] = stSaveData.usRealInfoFlow;

			//OBD��Ϣ��
			ptr[len++] = pOBDInfo->ucOBDProtocol;
			ptr[len++] = pOBDInfo->ucMilStatus;
			ptr[len++] = pOBDInfo->usSupportStatus >> 8;
			ptr[len++] = pOBDInfo->usSupportStatus;
			ptr[len++] = pOBDInfo->usReadyStatus >> 8;
			ptr[len++] = pOBDInfo->usReadyStatus;
			
			//memcpy(ptr + len, sDataInfo.pVIN, LEN_VIN);
			memcpy(ptr + len,pOBDInfo->szVIN,LEN_VIN);
			len += LEN_VIN;
			
			memcpy(ptr + len, pOBDInfo->szCalid, LEN_SOFTVER);
			len += LEN_SOFTVER;
			
			memcpy(ptr + len, pOBDInfo->szCVN, LEN_CVN);
			len += LEN_CVN;
			
			memcpy(ptr + len, pOBDInfo->szIUPR, LEN_IUPR);
			len += LEN_IUPR;
			
			ptr[len++] = pOBDInfo->ucDTCTotalNum;
			
			if (pOBDInfo->ucDTCTotalNum > 20) pOBDInfo->ucDTCTotalNum = 20;
			for (i = 0; i < pOBDInfo->ucDTCTotalNum; i++)
			{
				ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 0);
				ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 1);
				ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 2);
				ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 3);
			}				
		}

		//��Ϣ���ͱ�־
		ptr[len++] = DATA_STREAM_INFO;

		ptr[len++] = stSaveData.usRealInfoFlow >> 8;
		ptr[len++] = stSaveData.usRealInfoFlow;

		//��������Ϣ��
		ptr[len++] = pDataStreamInfo->usSpeed >> 8;
		ptr[len++] = pDataStreamInfo->usSpeed;
		
		ptr[len++] = pDataStreamInfo->uckPa;
		
		ptr[len++] = pDataStreamInfo->cActualTorquePercent;
		ptr[len++] = pDataStreamInfo->cFrictionTorquePercent;
		ptr[len++] = pDataStreamInfo->usRPM >> 8;
		ptr[len++] = pDataStreamInfo->usRPM;
		
		ptr[len++] = pDataStreamInfo->usFuelFlow >> 8;
		ptr[len++] = pDataStreamInfo->usFuelFlow;
		
		ptr[len++] = pDataStreamInfo->sUpperNOx >> 8;
		ptr[len++] = pDataStreamInfo->sUpperNOx;
		
		ptr[len++] = pDataStreamInfo->sLowerNOx >> 8;
		ptr[len++] = pDataStreamInfo->sLowerNOx;
		ptr[len++] = pDataStreamInfo->ucRemain;
		
		ptr[len++] = pDataStreamInfo->usIntakeVolume >> 8;
		ptr[len++] = pDataStreamInfo->usIntakeVolume;
		
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature;
		
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature;
		
		ptr[len++] = pDataStreamInfo->usDPF >> 8;
		ptr[len++] = pDataStreamInfo->usDPF;
		
		ptr[len++] = pDataStreamInfo->cCoolantTemperature;
		
		ptr[len++] = pDataStreamInfo->ucLevel;
		ptr[len++] = pDataStreamInfo->ucGpsStatus;
		
		ptr[len++] = pDataStreamInfo->ulLong >> 24; 
		ptr[len++] = pDataStreamInfo->ulLong >> 16;
		ptr[len++] = pDataStreamInfo->ulLong >> 8;
		ptr[len++] = pDataStreamInfo->ulLong;
		
		ptr[len++] = pDataStreamInfo->ulLat >> 24;	
		ptr[len++] = pDataStreamInfo->ulLat >> 16;
		ptr[len++] = pDataStreamInfo->ulLat >> 8;
		ptr[len++] = pDataStreamInfo->ulLat;
		
		ptr[len++] = pDataStreamInfo->ulMilage >> 24;	
		ptr[len++] = pDataStreamInfo->ulMilage >> 16;
		ptr[len++] = pDataStreamInfo->ulMilage >> 8;
		ptr[len++] = pDataStreamInfo->ulMilage;
	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}

int HJOBDInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,OBDInfo *pOBDInfo)
{
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	INT8U i = 0;
	INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pOBDInfo == 0)) return 0;

	usDataUnitLen = 6+1+2+6+LEN_VIN+LEN_SOFTVER+LEN_CVN+LEN_IUPR+1+4 * pOBDInfo->ucDTCTotalNum;	//���ݵ�Ԫ����

	if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	{
		return 0;	//the buf have no enough size
	}

	//����ʱ��
	memcpy(ptr,pOBDInfo->BCDTime,6);
	len += 6;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usHjRealInfoFlow++;
	ptr[len++] = stSaveData.usHjRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usHjRealInfoFlow;

	//��Ϣ���ͱ�־
	ptr[len++] = OBD_INFO;

	//���ݲɼ�ʱ��
	memcpy(ptr + len,pOBDInfo->BCDTime,6);
	len += 6;

	//OBD��Ϣ��
	ptr[len++] = pOBDInfo->ucOBDProtocol;
	ptr[len++] = pOBDInfo->ucMilStatus;
	ptr[len++] = pOBDInfo->usSupportStatus >> 8;
	ptr[len++] = pOBDInfo->usSupportStatus;
	ptr[len++] = pOBDInfo->usReadyStatus >> 8;
	ptr[len++] = pOBDInfo->usReadyStatus;

	//memcpy(ptr + len, sDataInfo.pVIN, LEN_VIN);
	memcpy(ptr + len,pOBDInfo->szVIN,LEN_VIN);
	len += LEN_VIN;

	memcpy(ptr + len, pOBDInfo->szCalid, LEN_SOFTVER);
	len += LEN_SOFTVER;

	memcpy(ptr + len, pOBDInfo->szCVN, LEN_CVN);
	len += LEN_CVN;
	
	memcpy(ptr + len, pOBDInfo->szIUPR, LEN_IUPR);
	len += LEN_IUPR;

	ptr[len++] = pOBDInfo->ucDTCTotalNum;

	if (pOBDInfo->ucDTCTotalNum < 0xFE)
	{
		for (i = 0; i < pOBDInfo->ucDTCTotalNum; i++)
		{
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 0);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 1);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 2);
			ptr[len++] = *(pOBDInfo->pDTCList + 4 * i + 3);
		}

	}
	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}


int HJDataStreamBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
										OBDInfo *pOBDInfo,
										DataStreamInfo *pDataStreamInfo1,
										unsigned int bagcnt,char is_17691)
{
	DataStreamInfo *pDataStreamInfo = 0;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOBDInfo == 0) || (pOutBuf == 0) || (pDataStreamInfo1 == 0) || (bagcnt == 0)) return 0;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return -2;	//the buf have no enough size
	//}

	pDataStreamInfo = &pDataStreamInfo1[bagcnt - 1];

	//���ݷ���ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;	

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usHjRealInfoFlow++;
	ptr[len++] = stSaveData.usHjRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usHjRealInfoFlow;


	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		//��Ϣ���ͱ�־
		ptr[len++] = DATA_STREAM_INFO;

		//���ݲɼ�ʱ��
		memcpy(ptr + len,pDataStreamInfo->BCDTime,6);
		len += 6;

		//��������Ϣ��
		ptr[len++] = pDataStreamInfo->usSpeed >> 8;
		ptr[len++] = pDataStreamInfo->usSpeed;
		
		ptr[len++] = pDataStreamInfo->uckPa;
		
		ptr[len++] = pDataStreamInfo->cActualTorquePercent;
		ptr[len++] = pDataStreamInfo->cFrictionTorquePercent;
		ptr[len++] = pDataStreamInfo->usRPM >> 8;
		ptr[len++] = pDataStreamInfo->usRPM;
		
		ptr[len++] = pDataStreamInfo->usFuelFlow >> 8;
		ptr[len++] = pDataStreamInfo->usFuelFlow;
		
		ptr[len++] = pDataStreamInfo->sUpperNOx >> 8;
		ptr[len++] = pDataStreamInfo->sUpperNOx;
		
		ptr[len++] = pDataStreamInfo->sLowerNOx >> 8;
		ptr[len++] = pDataStreamInfo->sLowerNOx;
		ptr[len++] = pDataStreamInfo->ucRemain;
		
		ptr[len++] = pDataStreamInfo->usIntakeVolume >> 8;
		ptr[len++] = pDataStreamInfo->usIntakeVolume;
		
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature;
		
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature;
		
		ptr[len++] = pDataStreamInfo->usDPF >> 8;
		ptr[len++] = pDataStreamInfo->usDPF;
		
		ptr[len++] = pDataStreamInfo->cCoolantTemperature;
		
		ptr[len++] = pDataStreamInfo->ucLevel;
		ptr[len++] = pDataStreamInfo->ucGpsStatus;
		
		ptr[len++] = pDataStreamInfo->ulLong >> 24; 
		ptr[len++] = pDataStreamInfo->ulLong >> 16;
		ptr[len++] = pDataStreamInfo->ulLong >> 8;
		ptr[len++] = pDataStreamInfo->ulLong;
		
		ptr[len++] = pDataStreamInfo->ulLat >> 24;	
		ptr[len++] = pDataStreamInfo->ulLat >> 16;
		ptr[len++] = pDataStreamInfo->ulLat >> 8;
		ptr[len++] = pDataStreamInfo->ulLat;
		
		ptr[len++] = pDataStreamInfo->ulMilage >> 24;	
		ptr[len++] = pDataStreamInfo->ulMilage >> 16;
		ptr[len++] = pDataStreamInfo->ulMilage >> 8;
		ptr[len++] = pDataStreamInfo->ulMilage;
	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}



//�Ϻ���������Ϣ���
int SHALLDataStreamInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
								SHALLDataStreamInfo *pDataStreamInfo1,
								unsigned int bagcnt,char is_17691)
{
	SHALLDataStreamInfo *pDataStreamInfo = pDataStreamInfo1;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pDataStreamInfo == 0) || (bagcnt == 0)) return -1;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return -2;	//the buf have no enough size
	//}

	//���ݲɼ�ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usRealInfoFlow++;
	ptr[len++] = stSaveData.usRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usRealInfoFlow;

	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		//��Ϣ���ͱ�־
		ptr[len++] = DATA_STREAM_INFO;
		
		//��������Ϣ��
		ptr[len++] = pDataStreamInfo->usSpeed >> 8;
		ptr[len++] = pDataStreamInfo->usSpeed;
		
		ptr[len++] = pDataStreamInfo->uckPa;
		
		ptr[len++] = pDataStreamInfo->cActualTorquePercent;
		ptr[len++] = pDataStreamInfo->cFrictionTorquePercent;
		ptr[len++] = pDataStreamInfo->usRPM >> 8;
		ptr[len++] = pDataStreamInfo->usRPM;
		
		ptr[len++] = pDataStreamInfo->usFuelFlow >> 8;
		ptr[len++] = pDataStreamInfo->usFuelFlow;
		
		ptr[len++] = pDataStreamInfo->sUpperNOx >> 8;
		ptr[len++] = pDataStreamInfo->sUpperNOx;
		
		ptr[len++] = pDataStreamInfo->sLowerNOx >> 8;
		ptr[len++] = pDataStreamInfo->sLowerNOx;
		ptr[len++] = pDataStreamInfo->ucRemain;
		
		ptr[len++] = pDataStreamInfo->usIntakeVolume >> 8;
		ptr[len++] = pDataStreamInfo->usIntakeVolume;
		
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature;
		
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature;
		
		ptr[len++] = pDataStreamInfo->usDPF >> 8;
		ptr[len++] = pDataStreamInfo->usDPF;
		
		ptr[len++] = pDataStreamInfo->cCoolantTemperature;
		
		ptr[len++] = pDataStreamInfo->ucLevel;
		ptr[len++] = pDataStreamInfo->ucGpsStatus;
		
		ptr[len++] = pDataStreamInfo->ulLong >> 24; 
		ptr[len++] = pDataStreamInfo->ulLong >> 16;
		ptr[len++] = pDataStreamInfo->ulLong >> 8;
		ptr[len++] = pDataStreamInfo->ulLong;
		
		ptr[len++] = pDataStreamInfo->ulLat >> 24;	
		ptr[len++] = pDataStreamInfo->ulLat >> 16;
		ptr[len++] = pDataStreamInfo->ulLat >> 8;
		ptr[len++] = pDataStreamInfo->ulLat;
		
		ptr[len++] = pDataStreamInfo->ulMilage >> 24;	
		ptr[len++] = pDataStreamInfo->ulMilage >> 16;
		ptr[len++] = pDataStreamInfo->ulMilage >> 8;
		ptr[len++] = pDataStreamInfo->ulMilage;

		//��Ϣ���ͱ�־
		ptr[len++] = SH_DATA_STREAM_EX_INFO;
		
		//������������Ϣ��
		ptr[len++] = pDataStreamInfo->engine_nj_mode;		//������Ť��ģʽ
		ptr[len++] = pDataStreamInfo->ymtb; 				//����̤��
		
		ptr[len++] = pDataStreamInfo->total_oil >> 24;		//�ۼ��ͺ�
		ptr[len++] = pDataStreamInfo->total_oil >> 16;
		ptr[len++] = pDataStreamInfo->total_oil >> 8;
		ptr[len++] = pDataStreamInfo->total_oil;
		
		ptr[len++] = pDataStreamInfo->nsxwd;				//�������¶�
		
		ptr[len++] = pDataStreamInfo->sjnspsl >> 24;		//ʵ������������
		ptr[len++] = pDataStreamInfo->sjnspsl >> 16;
		ptr[len++] = pDataStreamInfo->sjnspsl >> 8;
		ptr[len++] = pDataStreamInfo->sjnspsl;
		
		ptr[len++] = pDataStreamInfo->ljnsxh >> 24; 		//�ۼ���������
		ptr[len++] = pDataStreamInfo->ljnsxh >> 16;
		ptr[len++] = pDataStreamInfo->ljnsxh >> 8;
		ptr[len++] = pDataStreamInfo->ljnsxh;
		
		ptr[len++] = pDataStreamInfo->dpfpqwd >> 8;			//DPF�����¶�
		ptr[len++] = pDataStreamInfo->dpfpqwd;
	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}


//�Ϻ���������Ϣ���
int SHDataStreamInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
								DataStreamInfo *pDataStreamInfo1,
								unsigned int bagcnt,char is_17691)
{
	DataStreamInfo *pDataStreamInfo = pDataStreamInfo1;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pDataStreamInfo == 0) || (bagcnt == 0)) return -1;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return -2;	//the buf have no enough size
	//}

	//���ݲɼ�ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usRealInfoFlow++;
	ptr[len++] = stSaveData.usRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usRealInfoFlow;

	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		//��Ϣ���ͱ�־
		ptr[len++] = DATA_STREAM_INFO;
		
		//��������Ϣ��
		ptr[len++] = pDataStreamInfo->usSpeed >> 8;
		ptr[len++] = pDataStreamInfo->usSpeed;
		
		ptr[len++] = pDataStreamInfo->uckPa;
		
		ptr[len++] = pDataStreamInfo->cActualTorquePercent;
		ptr[len++] = pDataStreamInfo->cFrictionTorquePercent;
		ptr[len++] = pDataStreamInfo->usRPM >> 8;
		ptr[len++] = pDataStreamInfo->usRPM;
		
		ptr[len++] = pDataStreamInfo->usFuelFlow >> 8;
		ptr[len++] = pDataStreamInfo->usFuelFlow;
		
		ptr[len++] = pDataStreamInfo->sUpperNOx >> 8;
		ptr[len++] = pDataStreamInfo->sUpperNOx;
		
		ptr[len++] = pDataStreamInfo->sLowerNOx >> 8;
		ptr[len++] = pDataStreamInfo->sLowerNOx;
		ptr[len++] = pDataStreamInfo->ucRemain;
		
		ptr[len++] = pDataStreamInfo->usIntakeVolume >> 8;
		ptr[len++] = pDataStreamInfo->usIntakeVolume;
		
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCRInletTemperature;
		
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature >> 8;
		ptr[len++] = pDataStreamInfo->sSCROutletTemperature;
		
		ptr[len++] = pDataStreamInfo->usDPF >> 8;
		ptr[len++] = pDataStreamInfo->usDPF;
		
		ptr[len++] = pDataStreamInfo->cCoolantTemperature;
		
		ptr[len++] = pDataStreamInfo->ucLevel;
		ptr[len++] = pDataStreamInfo->ucGpsStatus;
		
		ptr[len++] = pDataStreamInfo->ulLong >> 24; 
		ptr[len++] = pDataStreamInfo->ulLong >> 16;
		ptr[len++] = pDataStreamInfo->ulLong >> 8;
		ptr[len++] = pDataStreamInfo->ulLong;
		
		ptr[len++] = pDataStreamInfo->ulLat >> 24;	
		ptr[len++] = pDataStreamInfo->ulLat >> 16;
		ptr[len++] = pDataStreamInfo->ulLat >> 8;
		ptr[len++] = pDataStreamInfo->ulLat;
		
		ptr[len++] = pDataStreamInfo->ulMilage >> 24;	
		ptr[len++] = pDataStreamInfo->ulMilage >> 16;
		ptr[len++] = pDataStreamInfo->ulMilage >> 8;
		ptr[len++] = pDataStreamInfo->ulMilage;
	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}


//�Ϻ�Э�� ����������
unsigned int SHDataStreamExInfoBag(void *pOutBuf,INT16U usOutBufSize,INT8U cmd,
								SHDataStreamExInfo *pDataStreamInfo1,
								unsigned int bagcnt,char is_17691)
{
	SHDataStreamExInfo *pDataStreamInfo = pDataStreamInfo1;
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;
	unsigned int i = 0;
	//INT16U usDataUnitLen = 0;	//���ݵ�Ԫ����

	if ((pOutBuf == 0) || (pDataStreamInfo == 0) || (bagcnt == 0)) return 0;

	//usDataUnitLen = 6+1+2+sizeof(DataStreamInfo) * bagcnt;	//���ݵ�Ԫ����

	//if ((usOutBufSize - OFFSET_DATA_UNIT) <= usDataUnitLen)
	//{
		//return 0;	//the buf have no enough size
	//}

	//���ݲɼ�ʱ��
	memcpy(ptr,pDataStreamInfo->BCDTime,6);
	len += 6;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usRealInfoFlow++;
	ptr[len++] = stSaveData.usRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usRealInfoFlow;

	for (i = 0; i < bagcnt; i++)
	{
		pDataStreamInfo = &pDataStreamInfo1[i];

		//��Ϣ���ͱ�־
		ptr[len++] = SH_DATA_STREAM_EX_INFO;

		
		//������������Ϣ��
		ptr[len++] = pDataStreamInfo->engine_nj_mode;		//������Ť��ģʽ
		ptr[len++] = pDataStreamInfo->ymtb;					//����̤��

		ptr[len++] = pDataStreamInfo->total_oil >> 24; 		//�ۼ��ͺ�
		ptr[len++] = pDataStreamInfo->total_oil >> 16;
		ptr[len++] = pDataStreamInfo->total_oil >> 8;
		ptr[len++] = pDataStreamInfo->total_oil;

		ptr[len++] = pDataStreamInfo->nsxwd;				//�������¶�
		
		ptr[len++] = pDataStreamInfo->sjnspsl >> 24;		//ʵ������������
		ptr[len++] = pDataStreamInfo->sjnspsl >> 16;
		ptr[len++] = pDataStreamInfo->sjnspsl >> 8;
		ptr[len++] = pDataStreamInfo->sjnspsl;
		
		ptr[len++] = pDataStreamInfo->ljnsxh >> 24;			//�ۼ���������
		ptr[len++] = pDataStreamInfo->ljnsxh >> 16;
		ptr[len++] = pDataStreamInfo->ljnsxh >> 8;
		ptr[len++] = pDataStreamInfo->ljnsxh;

																
		ptr[len++] = pDataStreamInfo->dpfpqwd >> 8;			//DPF�����¶�
		ptr[len++] = pDataStreamInfo->dpfpqwd;
	}

	return DataBag(pOutBuf,usOutBufSize,cmd,ptr,len);
}


//�Ϻ�ʵʱOBD��Ϣ
int SHRealOBDInfoPacket(void *pOutBuf,INT16U usOutBufSize,OBDInfo *pOBDInfo)
{
	return SHOBDInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pOBDInfo);
}

//�Ϻ�����OBD��Ϣ
int SHSupplyOBDInfoPacket(void *pOutBuf,INT16U usOutBufSize,OBDInfo *pOBDInfo)
{
	return SHOBDInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pOBDInfo);
}


//ʵʱOBD��Ϣ
int RealOBDInfoPacket(void *pOutBuf,INT16U usOutBufSize,OBDInfo *pOBDInfo)
{
	return OBDInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pOBDInfo);
}

//����OBD��Ϣ
int SupplyOBDInfoPacket(void *pOutBuf,INT16U usOutBufSize,OBDInfo *pOBDInfo)
{
	return OBDInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pOBDInfo);
}

//ʵʱ��������Ϣ
int RealDataStreamInfoPacket(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,1,0);
}

//���ʵʱ��������Ϣ
int RealDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,bagcnt,0);
}

//������������Ϣ
int SupplyDataStreamInfoPacket(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,1,0);
}

//���������������Ϣ
int SupplyDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,bagcnt,0);
}

//ʵʱ��������Ϣ
int GB17691_RealDataStreamInfoPacket(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,1,1);
}

//���ʵʱ��������Ϣ
int GB17691_SHRealDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return SHDataStreamInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,bagcnt,1);
}

//���ʵʱ��������Ϣ
int GB17691_SHALLRealDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,SHALLDataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return SHALLDataStreamInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,bagcnt,1);
}

//���������������Ϣ
int GB17691_SHALLSupplyDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,SHALLDataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return SHALLDataStreamInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,bagcnt,1);
}


//���������������Ϣ
int GB17691_SHSupplyDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return SHDataStreamInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,bagcnt,1);
}

//���ʵʱ��������Ϣ
int GB17691_RealDataStreamAndObdInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,
							OBDInfo *pOBDInfo,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamAndObdInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pOBDInfo,pDataStreamInfo,bagcnt,1);
}


//���ʵʱ��������Ϣ
int GB17691_RealDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,bagcnt,1);
}

//���ʵʱ��������Ϣ
int GB17691_RealDataStreamInfoExPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamInfoBagEx(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,bagcnt,1);
}



//���ʵʱ������������Ϣ
unsigned int GB17691_SHRealDataStreamExInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,SHDataStreamExInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return SHDataStreamExInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pDataStreamInfo,bagcnt,1);
}

int GB17691_SupplyDataStreamAndObdInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,
							OBDInfo *pOBDInfo,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamAndObdInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pOBDInfo,pDataStreamInfo,bagcnt,1);
}

//������������Ϣ
int GB17691_SupplyDataStreamInfoPacket(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,1,1);
}

//���������������Ϣ
int GB17691_SupplyDataStreamInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return DataStreamInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,bagcnt,1);
}

//�������������������Ϣ
int GB17691_SHSupplyDataStreamExInfoPacketMutli(void *pOutBuf,INT16U usOutBufSize,SHDataStreamExInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return SHDataStreamExInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pDataStreamInfo,bagcnt,1);
}



unsigned char bengbu_login_flag = 0;

void set_bengbu_login_flag(unsigned char val)
{
	bengbu_login_flag = val;
}

unsigned char get_bengbu_login_flag(void)
{
	return bengbu_login_flag;
}

//��ʼ�� + ���Ԫ + VIN + Ӧ���־
void anlyze_bengbu_server_data(void *pbuf,unsigned int len)
{
	unsigned char cmd = 0;
	unsigned char ack = 0;
	unsigned char *psrc = (unsigned char *)pbuf;
	unsigned char *ptr = 0;
	unsigned int rlen = len;

	while (1)
	{
		ptr = _find_sub_str(psrc,rlen,"\x23\x23",2);
		if (ptr == 0)
		{
			break;
		}
		cmd = ptr[2];
		ack = ptr[3 + 17];
		DBG_Print(LEVEL0,"----------server ack----------\r\ncmd:%02X ack:%02X\r\n",
		cmd,ack);

		if (cmd == CMD_LOGIN)
		{
			if (ack == 0)
			{
				set_bengbu_login_flag(1);
			}
		}

		psrc = ptr + 21;
		rlen = (unsigned char *)pbuf + len - psrc;
	}
}



//��ʼ�� + ���Ԫ + ������ʱ�� + ���ݵ�Ԫ���� + ���ݵ�Ԫ + У����
void anlyze_shanghai_server_data(void *pbuf,unsigned int len)
{
	unsigned char cmd = 0;
	unsigned char *psrc = (unsigned char *)pbuf;
	unsigned char *ptr = 0;
	unsigned int rlen = len;
	unsigned int datunitlen = 0;
	unsigned char xor = 0;

	if (len < (2+1+6+2+1))
	{
		return ;
	}
	while (1)
	{
		ptr = _find_sub_str(psrc,rlen,"\x23\x23",2);
		if (ptr == 0)
		{
			break;
		}
		cmd = ptr[2];
		datunitlen = (ptr[2+1+6] << 8) + ptr[2+1+6 + 1];
		if (rlen >= (2+1+6+2+datunitlen+1))
		{
			xor = ptr[2+1+6+2+datunitlen];
			DBG_Print(LEVEL0,"----------shanghai server ack----------\r\n"
			"cmd:%02X ack_time:%02d-%02d-%02d %02d:%02d:%02d datunitlen:%u xor:%02X\r\n",
			cmd,ptr[3],ptr[4],ptr[5],ptr[6],ptr[7],ptr[8],datunitlen,xor);
			
			switch (cmd)
			{
			case 0x01:		//��¼�ɹ�
			
			break;
			case 0x02:		//ʵʱ��Ϣ�ϴ��ɹ�
			
			break;
			case 0x05:		//������
			
			break;
			case 0x06:		//Զ������
			{
				unsigned char *url = ptr+2+1+6+2+2;
			
				ptr[2+1+6+2+datunitlen] = 0;	//У������0
				DBG_Print(LEVEL0,"http update:%s\r\n",url);
				//trigger_http_update(url);
			
			}
			break;
			default:break;
			}

		}
		else
		{
			DBG_Print(LEVEL0,"server data format error.\r\n");
			break;
		}

		psrc = ptr + 2 + 1 + 6 + 2 + datunitlen + 1;
		if (((unsigned char *)pbuf + len) > psrc)
		{
			rlen = (unsigned char *)pbuf + len - psrc;
		}
		else
		{
			break;
		}
	}
}


//��ʼ�� + ���Ԫ + VIN + �汾 + ���ܷ�ʽ + ���ݵ�Ԫ���� + ���ݵ�Ԫ + У����
void anlyze_17691_server_data(unsigned int linkid,void *pbuf,unsigned int len)
{
	unsigned char cmd = 0;
	unsigned char *psrc = (unsigned char *)pbuf;
	unsigned char *ptr = 0;
	unsigned char *pcontent = 0;
	unsigned int rlen = len;
	unsigned int datunitlen = 0;
	unsigned char xor = 0;
	unsigned int slen = 0;
	unsigned char psend[64] = {0};
	unsigned char *pack = psend + OFFSET_DATA_UNIT;
	unsigned int xlen = 0;

	if (len < (2+1+17+2+2+1))
	{
		return ;
	}
	while (1)
	{
		ptr = _find_sub_str(psrc,rlen,"\x23\x23",2);
		if (ptr == 0)
		{
			break;
		}
		cmd = ptr[2];
		datunitlen = (ptr[OFFSET_DATA_UNIT - 2] << 8) + ptr[OFFSET_DATA_UNIT - 1];
		if (rlen >= (2+1+17+2+2+datunitlen+1))
		{
			pcontent = ptr + OFFSET_DATA_UNIT;
			xor = ptr[2+1+17+2+2+datunitlen];
			DBG_Print(LEVEL0,"----------17691 server ack----------\r\n"
								"cmd:%02X datunitlen:%u xor:%02X\r\n",
								cmd,datunitlen,xor);
			switch (cmd)
			{
			case 0x01:		//��¼�ɹ�
			
			break;
			case 0x02:		//ʵʱ��Ϣ�ϴ��ɹ�
			
			break;
			case 0x05:		//Уʱ
			
			break;
			case 0x08:
				if (linkid == 5)			//����ƽ̨����Ӧ����Ҫ�ر�����
				{
					unsigned char *ps = 0;

					send_msg(S_MSG_SET_SERVER_IP_PORT,(void *)5,"0",0);

					ps = os_malloc(384);
					if (ps)
					{
						slen = df_17691_beian_result_pack(ps,384,
												get_rtc_time_ptr(),
												send_msg(S_MSG_GET_BEIAN_MSG_BODY_WITH_SIGN,0,0,0),169,
												pcontent[0],pcontent[1]
												);

						DBG_PrintBuf(LEVEL2,"report beian result to df server:\r\n",ps,slen);
						send_msg(S_MSG_SEND_TO_SERVER,(void *)2,ps,(void *)slen);
						os_free(ps);
					}
				}
			break;
	
			case 0x80:

			break;
			case 0x81:

			break;
			case 0x82:

			break;
			case 0x92:

			break;
			case 0x93:
			{
				xlen = 0;
				memcpy(pack,get_rtc_time_ptr(),6);
				xlen += 6;

				memcpy(pack + xlen,pcontent + 6,5);
				xlen += 5;

				pack[xlen++] = 0x01;

				slen = DataBag(psend,sizeof(psend),cmd,pack,xlen);
				send_msg(S_MSG_SEND_TO_SERVER,(void *)linkid,psend,(void *)slen);
			}
			break;
			case 0x95:				//TSPͨ�ÿ�������
			{			
				//Ӧ��
				xlen = 0;
				memcpy(pack,get_rtc_time_ptr(),6);
				xlen += 6;
				
				pack[xlen++] = pcontent[6]; 		//id
				
				stSaveData.usHjRealInfoFlow++;
				pack[xlen++] = stSaveData.usHjRealInfoFlow >> 8;
				pack[xlen++] = stSaveData.usHjRealInfoFlow;
				
				//�ְ���ʶ
				pack[xlen++] = pcontent[9];
				//ƽ̨��ˮ
				pack[xlen++] = pcontent[7];
				pack[xlen++] = pcontent[8];
				
				pack[xlen++] = 0x01;			//���״̬
				
				slen = DataBag(psend,sizeof(psend),cmd,pack,xlen);
				send_msg(S_MSG_SEND_TO_SERVER,(void *)linkid,psend,(void *)slen);

				if (pcontent[6] == 0x50)			//���۸ļ���
				{
					if (pcontent[10])
					{
						DBG_Print(LEVEL0,"tsp request bei an\r\n");		//��ҵƽ̨�����ն�ȥ����ƽ̨����
						//<ip5:g6check.vecc.org.cn><port5:20006>
						send_hj1239_beian_info_to_server("g6check.vecc.org.cn",20006);
					}
				}
				else if ((pcontent[6] == 0x52) && (datunitlen > 16))		//OTA
				{
					char *pcmd = 0;
					char *purl = 0;
					unsigned char urllen = 0;
					unsigned int templen = 0;

					pcmd = os_malloc(1536);
					if (pcmd)
					{
						purl = _find_sub_str(pcontent + 10,datunitlen - 10,"ftp://",strlen("ftp://"));
						if (purl)
						{
							urllen = *(purl - 1);
							if (urllen < 250)
							{
								//snprintf(pcmd,511,"ATEX=<linuxcmd:wget -O /data/box.bin ftp://%s:%s@%s>",pusr,psw,purl + strlen("ftp://"));
								templen = snprintf(pcmd,511,"ATEX=<linuxcmd:wget -O /data/box.bin ");

								memcpy(pcmd + templen,purl,urllen);
								templen += urllen;

								pcmd[templen++] = '>';
								pcmd[templen] = 0;
							}
						}
						else
						{
							DBG_Print(LEVEL0,"%s","not fond ftp server\r\n");
							purl = _find_sub_str(pcontent + 10,datunitlen - 10,"http://",strlen("http://"));
						}

						if (purl)
						{
							DBG_Print(0,"[exe cmd]%s\r\n",pcmd);
							send_msg(S_MSG_EXECUTE_DRV_CMD,pcmd,0,0);
						}
						os_free(pcmd);
					}

				}
				else if (pcontent[6] == 0x53)		//ȡ��OTA
				{

				}

			}
			break;
			default:break;
			}

		}
		else
		{
			DBG_Print(LEVEL0,"server data format error.\r\n");
			break;
		}

		psrc = ptr + 2+1+17+1+1 + 2 + datunitlen + 1;
		if (((unsigned char *)pbuf + len) > psrc)
		{
			rlen = (unsigned char *)pbuf + len - psrc;
		}
		else
		{
			break;
		}
	}
}




unsigned int hj1239_beian_pack(unsigned char rtime[6],
										void *chipid,unsigned int chipid_len,
										void *public_key,unsigned int pubkey_len,
										void *vin,unsigned int vin_len,
										void *pOut,unsigned int outbuflen)
{
	unsigned int rlen = 0;
	unsigned int slen = 0;
	unsigned char *content = 0;

	if ((chipid == 0) || (chipid_len == 0)
		|| (chipid == 0) || (chipid_len == 0)
		|| (public_key == 0) || (pubkey_len == 0)
		|| (vin == 0) || (vin_len == 0)
		|| (pOut == 0) || (outbuflen < 20)
		)
	{
		return 0;
	}

	content = (unsigned char *)pOut + OFFSET_DATA_UNIT;

	//ʱ��
	content[rlen++] = rtime[0];
	content[rlen++] = rtime[1];
	content[rlen++] = rtime[2];
	content[rlen++] = rtime[3];
	content[rlen++] = rtime[4];
	content[rlen++] = rtime[5];

	//оƬID
	memcpy(content + rlen,chipid,chipid_len);
	rlen += chipid_len;

	//��Կ
	memcpy(content + rlen,public_key,pubkey_len);
	rlen += pubkey_len;

	//VIN
	memcpy(content + rlen,vin,vin_len);
	rlen += vin_len;

	slen = DataBag(pOut,outbuflen,CMD_BEIAN,content,rlen);

	return slen;
}

//HJ1239���ʵʱ��������Ϣ
int HJ1239_RealDataStreamPacketMutli(void *pOutBuf,INT16U usOutBufSize,
							OBDInfo *pOBDInfo,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return HJDataStreamBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pOBDInfo,pDataStreamInfo,bagcnt,1);
}

int HJ1239_SupplyDataStreamPacketMutli(void *pOutBuf,INT16U usOutBufSize,
							OBDInfo *pOBDInfo,DataStreamInfo *pDataStreamInfo,unsigned int bagcnt)
{
	return HJDataStreamBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pOBDInfo,pDataStreamInfo,bagcnt,1);
}

//HJ1239ʵʱOBD��Ϣ
int HJ1239_RealOBDInfoPacket(void *pOutBuf,INT16U usOutBufSize,OBDInfo *pOBDInfo)
{
	return HJOBDInfoBag(pOutBuf,usOutBufSize,CMD_REAL_INFO,pOBDInfo);
}

//HJ1239����OBD��Ϣ
int HJ1239_SupplyOBDInfoPacket(void *pOutBuf,INT16U usOutBufSize,OBDInfo *pOBDInfo)
{
	return HJOBDInfoBag(pOutBuf,usOutBufSize,CMD_SUPPLY_INFO,pOBDInfo);
}


//�ϱ��������������ƽ̨
unsigned int df_17691_beian_result_pack(void *pOutBuf,INT16U usOutBufSize,
														INT8U t[6],
														void *beian_info,unsigned int beian_info_len,
														INT8U ack_code,INT8U ack_info)
{
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;

	if ((pOutBuf == 0) || (usOutBufSize == 0)) return 0;

	//���ݲɼ�ʱ��
	if (t) memcpy(ptr,t,6);
	len += 6;

	//���۸ļ������ϱ���־
	ptr[len++] = 0x50;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usHjRealInfoFlow++;
	ptr[len++] = stSaveData.usHjRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usHjRealInfoFlow;

	//�ְ���ʶ
	ptr[len++] = 0;

	//��Ϣ��
	if (beian_info && beian_info_len)
	{
		memcpy(ptr + len,beian_info,beian_info_len);
		len += beian_info_len;
	}

	//Ӧ��״̬��
	ptr[len++] = ack_code;

	//Ӧ����Ϣ
	ptr[len++] = ack_info;

	return DataBag(pOutBuf,usOutBufSize,0x25,ptr,len);
}


unsigned int df_17691_beian_result_pack1(void *pOutBuf,INT16U usOutBufSize,
														INT8U t[6],
														void *chip_id,unsigned int chipidlen,
														void *pubkey,unsigned int pubkeylen,
														void *pvin,unsigned int vinlen,
														void *phj1239_sign,unsigned int hj1239_sign_len,
														INT8U ack_code,INT8U ack_info)
{
	INT16U len = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;

	if ((pOutBuf == 0) || (usOutBufSize == 0)) return 0;

	//���ݲɼ�ʱ��
	if (t) memcpy(ptr,t,6);
	len += 6;

	//���۸ļ������ϱ���־
	ptr[len++] = 0x50;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usHjRealInfoFlow++;
	ptr[len++] = stSaveData.usHjRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usHjRealInfoFlow;

	//�ְ���ʶ
	ptr[len++] = 0;

	//��Ϣ��

	//����ʱ��ʱ��
	if (t) memcpy(ptr + len,t,6);
	len += 6;

	//оƬID
	if (chip_id && chipidlen)
	{
		memcpy(ptr + len,chip_id,chipidlen);
		len += chipidlen;
	}

	//��Կ
	if (pubkey && pubkeylen)
	{
		memcpy(ptr + len,pubkey,pubkeylen);
		len += pubkeylen;
	}
	//VIN
	if (pvin && vinlen)
	{
		memcpy(ptr + len,pvin,vinlen);
		len += vinlen;
	}

	//����ʱ��ǩ����Ϣ
	if (phj1239_sign && hj1239_sign_len)
	{
		memcpy(ptr + len,phj1239_sign,hj1239_sign_len);
		len += hj1239_sign_len;
	}
	//Ӧ��״̬��
	ptr[len++] = ack_code;

	//Ӧ����Ϣ
	ptr[len++] = ack_info;

	return DataBag(pOutBuf,usOutBufSize,0x25,ptr,len);
}


unsigned int df_17691_baseinfo_pack(void *pOutBuf,INT16U usOutBufSize,
												INT8U t[6],
												void *chipid,unsigned int chipid_len,
												void *piccid,unsigned int iccid_len,
												void *pesn,unsigned int esn_len
												)
{
	INT16U len = 0;
	INT16U templen = 0;
	unsigned char *pimei = 0;	
	char *p_mpu_ver = 0;
	INT8U *ptr = (INT8U *)pOutBuf + OFFSET_DATA_UNIT;

	if ((pOutBuf == 0) || (usOutBufSize == 0)) return 0;

	//���ݲɼ�ʱ��
	if (t) memcpy(ptr,t,6);
	len += 6;

	//������Ϣ
	ptr[len++] = 0x51;

	//ʵʱ��Ϣ��ˮ��
	stSaveData.usHjRealInfoFlow++;
	ptr[len++] = stSaveData.usHjRealInfoFlow >> 8;
	ptr[len++] = stSaveData.usHjRealInfoFlow;

	//�ְ���ʶ
	ptr[len++] = 0;

	//��Ϣ��

	//Э��汾
	ptr[len++] = 0x02;

	//�ն�ID
	pimei = send_msg(S_MSG_GET_IMEI,0,0,0);
	templen = strlen((char *)pimei);
	if (templen >= 24)
	{
		templen = 24;
	}
	ptr[len++] = templen;
	memcpy(ptr + len,pimei,templen);
	len += templen;

	//Ӳ���汾
	ptr[len++] = strlen("V1.0");
	memcpy(ptr + len,"V1.0",strlen("V1.0"));
	len += strlen("V1.0");

	//�����汾
	p_mpu_ver = send_msg(S_MSG_GET_MPU_SOFTWARE_VERSION,0,0,0);
	if ((p_mpu_ver == 0) || (strlen((char *)p_mpu_ver) == 0))
	{
		return 0;
	}

	templen = strlen(APP_VERSION) + strlen((char *)p_mpu_ver);
	if (templen >= 47)
	{
		templen = 47;
	}

	ptr[len++] = templen;
	memcpy(ptr+len,APP_VERSION,(strlen(APP_VERSION) > templen) ? templen : strlen(APP_VERSION));
	len += ((strlen(APP_VERSION) > templen) ? templen : strlen(APP_VERSION));
	if (templen > strlen(APP_VERSION))
	{
		memcpy(ptr + len,p_mpu_ver,templen - strlen(APP_VERSION));
		len += (templen - strlen(APP_VERSION));
	}

#if 0
�ն��ͺ�:JJ-Q2019
��ȫоƬ�ͺ�:HSC32I1
��ȫоƬǰ��λ��ʶ��:BVT
#endif

	//�ն��ͺ�
	ptr[len++] = strlen("JJ-Q2019");
	memcpy(ptr + len,"JJ-Q2019",strlen("JJ-Q2019"));
	len += strlen("JJ-Q2019");

	//����оƬ�ͺ�
	ptr[len++] = strlen("HSC32I1");
	memcpy(ptr + len,"HSC32I1",strlen("HSC32I1"));
	len += strlen("HSC32I1");

	//оƬID
	if (chipid && chipid_len)
	{
		memcpy(ptr + len,chipid,chipid_len);
	}
	len += 16;

	//iccid
	if (piccid)
	{
		memcpy(ptr + len,piccid,20);
	}
	len += 20;

	//sim
	ptr[len++] = 13;
	memcpy(ptr + len,"144",3);
	if (piccid) memcpy(ptr + len + 3,(unsigned char *)piccid + 10,10);
	len += 13;

	//���ƺ�
	ptr[len++] = strlen("��A00001");
	memcpy(ptr + len,"��A00001",strlen("��A00001"));
	len += strlen("��A00001");

	//���������к�
	if (pesn && esn_len)
	{
		ptr[len++] = esn_len;
		memcpy(ptr + len,pesn,esn_len);
		len += esn_len;
	}
	else
	{
		ptr[len++] = 0;
	}

	//ECUԴ��ַ
	ptr[len++] = 1;

	//ECU�궨�汾��
	ptr[len++] = strlen("ECU_V1.0.1");
	memcpy(ptr + len,"ECU_V1.0.1",strlen("ECU_V1.0.1"));
	len += strlen("ECU_V1.0.1");

	//ECU�ͺ�
	ptr[len++] = strlen("CMMNS");
	memcpy(ptr + len,"CMMNS",strlen("CMMNS"));
	len += strlen("CMMNS");

	//HMI����ѡ��
	ptr[len++] = strlen("tspBasic");
	memcpy(ptr + len,"tspBasic",strlen("tspBasic"));
	len += strlen("tspBasic");

	//ECU�궨�ļ���ʽ
	ptr[len++] = 1;			//1.bin 2.zip 3.gz

	//OTA
	ptr[len++] = 0;

	//��������
	ptr[len++] = 0;

	//��Ϲ���
	ptr[len++] = 0;

	return DataBag(pOutBuf,usOutBufSize,0x25,ptr,len);
}


void send_hj1239_beian_info_to_server(void *ip,unsigned int port)
{
	unsigned int templen = 0;
	unsigned char *szTemp = 0;

	if ((ip == 0) || (port == 0))
	{
		return ;
	}

	szTemp = os_malloc(256);
	if (szTemp)
	{
		send_msg(S_MSG_SET_SERVER_IP_PORT,(void *)5,ip,(void *)port);
		
		send_msg(S_MSG_GET_VIN,GetVIN(),0,0);
		send_msg(S_MSG_GET_PUBLIC_KEY,get_pubkey_ptr(),0,0);

		templen = hj1239_beian_pack(get_rtc_time_ptr(),
									send_msg(S_MSG_GET_JIAMI_CHIP_ID,0,0,0),16,
									get_pubkey_ptr(),64,
									GetVIN(),17,
									szTemp,256
									);
		
		send_msg(S_MSG_SEND_TO_SERVER,(void *)5,szTemp,(void *)templen);
		DBG_Print(LEVEL2,"beian to server %s:%u(%u):\r\n",ip,port,templen);
		DBG_PrintBuf(LEVEL2,0,szTemp,templen);

		os_free(szTemp);
	}
}


