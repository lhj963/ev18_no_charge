#include "car_uds.h"


typedef struct _UdsDtcDataInfo
{
    u8 AntennaDtcStatus; //���߿�·DTC״̬
    u8 SimCardDtcStatus; //SIM��δ��DTC״̬
    u8 CanbusDtcStatus;  //busoff����DTC״̬
	u32 AntennaDTC ;  //���߿�·DTC������
    u32 SimCardDTC;	 //SIM��δ��DTC������
	u32 CanbusDTC;  //busoff����DTC
}UdsDtcDataInfo;

u8 DTCStatusAvailabilityMask =0x49 ; //ECU֧�ֵ�DTC״̬
u8 AntennaDTCStatus =0x00;
u8 SimCardDTCStatus =0x00;
u8 CanbusDTCStatus  =0x00;


UdsDtcDataInfo s_UdsDtcInfo;


/**************************************************************************************************
* ��  ��: u8 CanSendMsg(CAN_TypeDef* CANx,u8 CAN_IDE,u32 CAN_Id,u8* msg,u8 len)
* ��  ��: CAN����һ������
* ��  ��: 
* ��  ��: uCAN_TypeDef* CANx:ѡ��CANΪ��·��CAN1��CAN2
*         u8 CAN_IDE:��ʶ������ѡ�񣬱�׼��ʶ����CAN_Id_Standard������չ��ʶ����CAN_Id_Extended)
*         u32 CAN_Id:���ñ�ʶ��Idֵ
*         u8* msg   :����ָ��,���Ϊ8���ֽ�
*         u8 len    :���ݳ���(���Ϊ8)
* ��  ��: u8
* ����ֵ: 0,�ɹ�,����,ʧ��;
****************************************************************************************************/
u8 CanSendMsg(CAN_TypeDef* CANx,u8 CAN_IDE,u32 CAN_Id,u8* msg,u8 len)
{	
	u8 mbox;
	u16 i=0;
	CanTxMsg TxMessage;
	TxMessage.StdId=CAN_Id;			// ���ñ�׼��ʶ��Idֵ
	TxMessage.ExtId=CAN_Id;			// ������չ��ʾ����29λ��
	TxMessage.IDE=CAN_IDE;          // ��ʶ������ѡ�񣬱�׼��ʶ����CAN_Id_Standard������չ��ʶ����CAN_Id_Extended)
	TxMessage.RTR=0;		 		// ��Ϣ����Ϊ����֡��һ֡8λ
	TxMessage.DLC=len;				// ����֡��Ϣ������
	DBG_Print(LEVEL4,"Send CanID: %08X\r\n",CAN_Id);
	for(i=0;i<len;i++)
	{
	 TxMessage.Data[i]=msg[i];		// ��һ֡��Ϣ 
	}		
	mbox= CAN_Transmit(CANx, &TxMessage);  	
	i=0;
	while((CAN_TransmitStatus(CANx, mbox)==CAN_TxStatus_Failed)&&(i<0XFFF))i++;	//�ȴ����ͽ���
	if(i>=0XFFF)return 1;
	return 0;		
}


/**************************************************************************************************
* ��  ��: void CarIS014229UdsAnalysis(CAN_TypeDef* CANx,u32 can_id,u8 data[8])
* ��  ��: ����ISO14229Э���UDS������ݽ���
* ��  ��: 
* ��  ��: CAN_TypeDef* CANx:ѡ��CAN�ı��
*         u32 can_id:�յ���CAN ID��
*         u8 data[8]:�յ�������
* ��  ��: u8
* ����ֵ: 0,�ɹ�,����,ʧ��;
****************************************************************************************************/
void CarIS014229UdsAnalysis(CAN_TypeDef* CANx,u32 can_id,u8 data[8])
{
    CanProInfo  CAR_UDSBro;
	static u8 ExtendDSFlag =0;
	static u8 Write2EEnableFlag =0;
	static u8 UDS_FCDFlag =0;
	static u8 UdsDtcFCDFlag =0;  //DTC�����Ʊ�־
	u8 UdsDtcCount =0;
	u8 DTCStatusMaskFlag =0; //ͨ��״̬����õ�DTC�ĸ�����־
	unsigned int PGN = 0;
	s_UdsDtcInfo.AntennaDTC =0xA39029;
	s_UdsDtcInfo.SimCardDTC =0xA3C000;
	s_UdsDtcInfo.CanbusDTC = 0xA39129;
	PGN =  can_id & 0xFFFF;
    if ((PGN != 0x0793)&&(PGN!= 0x07DF))
	{
		return ;
	}
	DBG_PrintBuf(LEVEL4,"CarIS014229UdsAnalysis:",data,8);

	if(data[0]&0x0F) //��֡����
	{
		switch(data[1])
		{
			case 0x10://���ģʽ���� 
				if(data[2]==0x01)//Ĭ��ģʽ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0x50;
					CAR_UDSBro.msg[2] = 0x01;
					CAR_UDSBro.len = 3;
					ExtendDSFlag =0;
				}
				else if(data[2]==0x03)//��չ���ģʽ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0x50;
					CAR_UDSBro.msg[2] = 0x03;
					CAR_UDSBro.len = 3;
					ExtendDSFlag =1;
				}
				else   //�񶨵���Ӧ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x7F;	
					CAR_UDSBro.msg[1] = 0x10;
					CAR_UDSBro.msg[2] = 0x12;
					CAR_UDSBro.len = 3;
				}
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);			
			break;
			case 0x27://��ȫ����
				if((data[2]==0x01)&&(ExtendDSFlag == 1))
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0x67;
					CAR_UDSBro.msg[2] = 0x01;
					CAR_UDSBro.msg[3] = 0x07;
					CAR_UDSBro.msg[4] = 0x10;
					CAR_UDSBro.msg[5] = 0x56;
					CAR_UDSBro.msg[6] = 0x01;
					CAR_UDSBro.msg[7] = 0xAA;
					CAR_UDSBro.len = 8;
				}
				else if((data[2]==0x02)&&(ExtendDSFlag == 1))
				{
					if((data[3]==0x02)&&(data[4]==0x02)&&(data[5]==0x03)&&(data[6]==0x03)) //�������
					{
						CAR_UDSBro.CANx =CANx;
						CAR_UDSBro.canide =CAN_Id_Standard;
						CAR_UDSBro.canid =0x79B;
						CAR_UDSBro.msg[0] = 0x02;	
						CAR_UDSBro.msg[1] = 0x67;
						CAR_UDSBro.msg[2] = 0x02;
						CAR_UDSBro.len = 3;
						Write2EEnableFlag = 1;  //����д�����ݱ�־
					}
					else
					{
					    CAR_UDSBro.CANx =CANx;
					    CAR_UDSBro.canide =CAN_Id_Standard;
					    CAR_UDSBro.canid =0x79B;
					    CAR_UDSBro.msg[0] = 0x7F;	
					    CAR_UDSBro.msg[1] = 0x27;
					    CAR_UDSBro.msg[2] = 0x35;
					    CAR_UDSBro.len = 3;
					
					}
				
				}
				else      //�񶨵���Ӧ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x7F;	
					CAR_UDSBro.msg[1] = 0x27;
					CAR_UDSBro.msg[2] = 0x12;
					CAR_UDSBro.len = 3;
				}
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
			break;
			case 0x3E://����豸����
				if(data[2]==0x00)
				{ 
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0x7E;
					CAR_UDSBro.msg[2] = 0x00;
					CAR_UDSBro.len = 3;
				}
				else      //�񶨵���Ӧ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x7F;	
					CAR_UDSBro.msg[1] = 0x3E;
					CAR_UDSBro.msg[2] = 0x12;
					CAR_UDSBro.len = 3;
				}
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
			break;
			case 0x28://ͨ�ſ���
				if(data[2]==0x00)//ʹ���շ�
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0x68;
					CAR_UDSBro.msg[2] = 0x00;
					CAR_UDSBro.len = 3;
				}
				else if(data[2]==0x03)//��ֹ�շ�
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0x68;
					CAR_UDSBro.msg[2] = 0x03;
					CAR_UDSBro.len = 3;
				
				}
				else      //�񶨵���Ӧ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x7F;	
					CAR_UDSBro.msg[1] = 0x28;
					CAR_UDSBro.msg[2] = 0x12;
					CAR_UDSBro.len = 3;
				}
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
			break;
			case 0x85://����DTC����
				if(data[2]==0x01)  //��DTC����
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0xC5;
					CAR_UDSBro.msg[2] = 0x01;
					CAR_UDSBro.len = 3;
				}
				else if(data[2]==0x02)  //�ر�DTC����
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x02;	
					CAR_UDSBro.msg[1] = 0xC5;
					CAR_UDSBro.msg[2] = 0x02;
					CAR_UDSBro.len = 3;
				
				}
				else      //�񶨵���Ӧ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x7F;	
					CAR_UDSBro.msg[1] = 0x85;
					CAR_UDSBro.msg[2] = 0x12;
					CAR_UDSBro.len = 3;
				}
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
			break;
			case 0x22://��ȡ����
				if((data[2]==0xF1)&&(data[3]==0x84))  //application Software Fingerprint Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x10;	
					CAR_UDSBro.msg[1] = 0x0B;
					CAR_UDSBro.msg[2] = 0x62;
					CAR_UDSBro.msg[3] = 0xF1;
					CAR_UDSBro.msg[4] = 0x84;
					CAR_UDSBro.msg[5] = 0x01;
					CAR_UDSBro.msg[6] = 0x02;
					CAR_UDSBro.msg[7] = 0x06;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					UDS_FCDFlag = 1;
				}
				else if((data[2]==0xF1)&&(data[3]==0x87))  //vehicle Manufacturer Spare Part Number Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x10;	
					CAR_UDSBro.msg[1] = 0x0E;
					CAR_UDSBro.msg[2] = 0x62;
					CAR_UDSBro.msg[3] = 0xF1;
					CAR_UDSBro.msg[4] = 0x87;
					CAR_UDSBro.msg[5] = 0x11;
					CAR_UDSBro.msg[6] = 0x12;
					CAR_UDSBro.msg[7] = 0x16;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					UDS_FCDFlag = 2;
				
				}
				else if((data[2]==0xF1)&&(data[3]==0x8A))  //System Supplier Identifier Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x10;	
					CAR_UDSBro.msg[1] = 0x0B;
					CAR_UDSBro.msg[2] = 0x62;
					CAR_UDSBro.msg[3] = 0xF1;
					CAR_UDSBro.msg[4] = 0x8A;
					CAR_UDSBro.msg[5] = 0x01;
					CAR_UDSBro.msg[6] = 0x02;
					CAR_UDSBro.msg[7] = 0x06;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					UDS_FCDFlag = 3;
				
				}
				else if((data[2]==0xF1)&&(data[3]==0x8C)) //ECU Serial Number Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x10;	
					CAR_UDSBro.msg[1] = 0x08;
					CAR_UDSBro.msg[2] = 0x62;
					CAR_UDSBro.msg[3] = 0xF1;
					CAR_UDSBro.msg[4] = 0x8C;
					CAR_UDSBro.msg[5] = 0x01;
					CAR_UDSBro.msg[6] = 0x02;
					CAR_UDSBro.msg[7] = 0x06;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					UDS_FCDFlag = 4;
				}
				else if((data[2]==0xF1)&&(data[3]==0x90)) //VIN Data Identifier
				{
				   CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x10;	
					CAR_UDSBro.msg[1] = 0x13;
					CAR_UDSBro.msg[2] = 0x62;
					CAR_UDSBro.msg[3] = 0xF1;
					CAR_UDSBro.msg[4] = 0x90;
					CAR_UDSBro.msg[5] = 0x01;
					CAR_UDSBro.msg[6] = 0x02;
					CAR_UDSBro.msg[7] = 0x06;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					UDS_FCDFlag = 5;
				}
				else if((data[2]==0xF1)&&(data[3]==0x92)) //system Supplier ECU Hardware Number Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x05;	
					CAR_UDSBro.msg[1] = 0x62;
					CAR_UDSBro.msg[2] = 0xF1;
					CAR_UDSBro.msg[3] = 0x92;
					CAR_UDSBro.msg[4] = 0x01;
					CAR_UDSBro.msg[5] = 0x02;
					CAR_UDSBro.msg[6] = 0xAA;
					CAR_UDSBro.msg[7] = 0xAA;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					
				}
				else if((data[2]==0xF1)&&(data[3]==0x93)) //ECU Hardware Version
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x10;	
					CAR_UDSBro.msg[1] = 0x08;
					CAR_UDSBro.msg[2] = 0x62;
					CAR_UDSBro.msg[3] = 0xF1;
					CAR_UDSBro.msg[4] = 0x93;
					CAR_UDSBro.msg[5] = 0x01;
					CAR_UDSBro.msg[6] = 0x02;
					CAR_UDSBro.msg[7] = 0x06;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
					UDS_FCDFlag = 6;
				}
				else if((data[2]==0xF1)&&(data[3]==0x94))  //system Supplier ECU Software Number Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x05;	
					CAR_UDSBro.msg[1] = 0x62;
					CAR_UDSBro.msg[2] = 0xF1;
					CAR_UDSBro.msg[3] = 0x94;
					CAR_UDSBro.msg[4] = 0x01;
					CAR_UDSBro.msg[5] = 0x02;
					CAR_UDSBro.msg[6] = 0xAA;
					CAR_UDSBro.msg[7] = 0xAA;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);                        
				
				}
				else if((data[2]==0xF1)&&(data[3]==0x95)) //system Supplier ECU Software Version Number Data Identifier
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x05;	
					CAR_UDSBro.msg[1] = 0x62;
					CAR_UDSBro.msg[2] = 0xF1;
					CAR_UDSBro.msg[3] = 0x95;
					CAR_UDSBro.msg[4] = 0x01;
					CAR_UDSBro.msg[5] = 0x02;
					CAR_UDSBro.msg[6] = 0xAA;
					CAR_UDSBro.msg[7] = 0xAA;
					CAR_UDSBro.len = 8;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len);
				}
				else      //�񶨵���Ӧ
				{
					CAR_UDSBro.CANx =CANx;
					CAR_UDSBro.canide =CAN_Id_Standard;
					CAR_UDSBro.canid =0x79B;
					CAR_UDSBro.msg[0] = 0x7F;	
					CAR_UDSBro.msg[1] = 0x22;
					CAR_UDSBro.msg[2] = 0x12;
					CAR_UDSBro.len = 3;
					CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len); 
				}
			break;
//			case 0x2E://д������
//				 
//			break;
			case 0x19://��DTC��Ϣ
				if(data[2] ==0x01) //ͨ��״̬���뱨��DTC������
				{
				     if(s_UdsDtcInfo.AntennaDtcStatus &(data[2]&DTCStatusAvailabilityMask))
					 {
					     UdsDtcCount ++;
					 }
					 else if(s_UdsDtcInfo.SimCardDtcStatus &(data[2]&DTCStatusAvailabilityMask))
					 {
					 
					     UdsDtcCount ++;
					 }
					 else if(s_UdsDtcInfo.CanbusDtcStatus &(data[2]&DTCStatusAvailabilityMask))
					 {
					     UdsDtcCount ++;
					 }
					 CAR_UDSBro.CANx =CANx;
					 CAR_UDSBro.canide =CAN_Id_Standard;
					 CAR_UDSBro.canid =0x79B;
					 CAR_UDSBro.msg[0] = 0x05;	
					 CAR_UDSBro.msg[1] = 0x59;
					 CAR_UDSBro.msg[2] = 0x01;
					 CAR_UDSBro.msg[3] = DTCStatusAvailabilityMask;
					 CAR_UDSBro.msg[4] = 0x00;
					 CAR_UDSBro.msg[5] = UdsDtcCount;
					 CAR_UDSBro.len = 6;
					 CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len); 
				
				}
				else if(data[2] ==0x02)  //ͨ��״̬���뱨��DTC
				{
				     if(s_UdsDtcInfo.AntennaDtcStatus &(data[2] & DTCStatusAvailabilityMask))
					 {
						 DTCStatusMaskFlag =1;  //һ�������룺����DTC
						 if(s_UdsDtcInfo.SimCardDtcStatus &&(data[2] && DTCStatusAvailabilityMask))
						 {
						     DTCStatusMaskFlag = 2;  //���������룺����DTC��SIM��DTC
							 if(s_UdsDtcInfo.CanbusDtcStatus &&(data[2] && DTCStatusAvailabilityMask))
							 {
							     DTCStatusMaskFlag = 7; //���������룺����DTC��SIM��DTC��canbusDTC
							 }
						 }
						 else if(s_UdsDtcInfo.CanbusDtcStatus &&(data[2] && DTCStatusAvailabilityMask))
						 {
						     DTCStatusMaskFlag = 3;  //���������룺����DTC��canbusDTC
						 }
					     
					 }
					 else if(s_UdsDtcInfo.SimCardDtcStatus &&(data[2] && DTCStatusAvailabilityMask))
					 {
					     DTCStatusMaskFlag =4; //һ�������룺SIM��DTC
						 if(s_UdsDtcInfo.CanbusDtcStatus &&(data[2] && DTCStatusAvailabilityMask))
						 {
						     DTCStatusMaskFlag = 5;  //���������룺SIM��DTC��canbusDTC
						 }
					 }
					 else if(s_UdsDtcInfo.CanbusDtcStatus &&(data[2] && DTCStatusAvailabilityMask))
					 {
					     DTCStatusMaskFlag = 6;  //һ�������룺canbusDTC
					 }
					 
					 switch(DTCStatusMaskFlag)
					 {
					     case 1:   //һ�������룺����DTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x07;	
						     CAR_UDSBro.msg[1] = 0x59;
						     CAR_UDSBro.msg[2] = 0x02;
						     CAR_UDSBro.msg[3] = DTCStatusAvailabilityMask;  
						     CAR_UDSBro.msg[4] = (u8)(s_UdsDtcInfo.AntennaDTC&0xFF);
						     CAR_UDSBro.msg[5] =(u8)((s_UdsDtcInfo.AntennaDTC >>8)&0xFF);
						     CAR_UDSBro.msg[6] = (u8)((s_UdsDtcInfo.AntennaDTC >>16)&0xFF);
						     CAR_UDSBro.msg[7] = s_UdsDtcInfo.AntennaDtcStatus;
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
							 break;
					     case 2:   //���������룺����DTC��SIM��DTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x10;	
						     CAR_UDSBro.msg[1] = 0x08;
						     CAR_UDSBro.msg[2] = 0x59;
					         CAR_UDSBro.msg[3] = 0x0A;
						     CAR_UDSBro.msg[4] = DTCStatusAvailabilityMask; 
						     CAR_UDSBro.msg[5] = (u8)(s_UdsDtcInfo.AntennaDTC&0xFF);
						     CAR_UDSBro.msg[6] =(u8)((s_UdsDtcInfo.AntennaDTC >>8)&0xFF);
						     CAR_UDSBro.msg[7] = (u8)((s_UdsDtcInfo.AntennaDTC >>16)&0xFF);
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
					         UdsDtcFCDFlag =2;
							 break;
						 case 3:   //���������룺����DTC��canbusDTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x10;	
						     CAR_UDSBro.msg[1] = 0x08;
						     CAR_UDSBro.msg[2] = 0x59;
					         CAR_UDSBro.msg[3] = 0x0A;
						     CAR_UDSBro.msg[4] = DTCStatusAvailabilityMask; 
						     CAR_UDSBro.msg[5] = (u8)(s_UdsDtcInfo.AntennaDTC&0xFF);
						     CAR_UDSBro.msg[6] =(u8)((s_UdsDtcInfo.AntennaDTC >>8)&0xFF);
						     CAR_UDSBro.msg[7] = (u8)((s_UdsDtcInfo.AntennaDTC >>16)&0xFF);
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
					         UdsDtcFCDFlag =3;
							 break;
						 case 4:   //һ�������룺SIM��DTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x07;	
						     CAR_UDSBro.msg[1] = 0x59;
						     CAR_UDSBro.msg[2] = 0x02;
						     CAR_UDSBro.msg[3] = DTCStatusAvailabilityMask;  
						     CAR_UDSBro.msg[4] = (u8)(s_UdsDtcInfo.SimCardDTC&0xFF);
						     CAR_UDSBro.msg[5] =(u8)((s_UdsDtcInfo.SimCardDTC >>8)&0xFF);
						     CAR_UDSBro.msg[6] = (u8)((s_UdsDtcInfo.SimCardDTC >>16)&0xFF);
						     CAR_UDSBro.msg[7] = s_UdsDtcInfo.SimCardDtcStatus;
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
							 break;
						 case 5:  //���������룺SIM��DTC��canbusDTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x10;	
						     CAR_UDSBro.msg[1] = 0x08;
						     CAR_UDSBro.msg[2] = 0x59;
					         CAR_UDSBro.msg[3] = 0x0A;
						     CAR_UDSBro.msg[4] = DTCStatusAvailabilityMask; 
						     CAR_UDSBro.msg[5] = (u8)(s_UdsDtcInfo.SimCardDTC&0xFF);
						     CAR_UDSBro.msg[6] =(u8)((s_UdsDtcInfo.SimCardDTC >>8)&0xFF);
						     CAR_UDSBro.msg[7] = (u8)((s_UdsDtcInfo.SimCardDTC >>16)&0xFF);
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
					         UdsDtcFCDFlag =4;
							 break;
						 case 6:   //һ�������룺canbusDTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x07;	
						     CAR_UDSBro.msg[1] = 0x59;
						     CAR_UDSBro.msg[2] = 0x02;
						     CAR_UDSBro.msg[3] = DTCStatusAvailabilityMask;  
						     CAR_UDSBro.msg[4] = (u8)(s_UdsDtcInfo.CanbusDTC&0xFF);
						     CAR_UDSBro.msg[5] =(u8)((s_UdsDtcInfo.CanbusDTC >>8)&0xFF);
						     CAR_UDSBro.msg[6] = (u8)((s_UdsDtcInfo.CanbusDTC >>16)&0xFF);
						     CAR_UDSBro.msg[7] = s_UdsDtcInfo.CanbusDtcStatus;
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
						 case 7:  //���������룺����DTC��SIM��DTC��canbusDTC
							 CAR_UDSBro.CANx =CANx;
						     CAR_UDSBro.canide =CAN_Id_Standard;
						     CAR_UDSBro.canid =0x79B;
						     CAR_UDSBro.msg[0] = 0x10;	
						     CAR_UDSBro.msg[1] = 0x0E;
						     CAR_UDSBro.msg[2] = 0x59;
					         CAR_UDSBro.msg[3] = 0x0A;
						     CAR_UDSBro.msg[4] = DTCStatusAvailabilityMask; 
						     CAR_UDSBro.msg[5] = (u8)(s_UdsDtcInfo.AntennaDTC&0xFF);
						     CAR_UDSBro.msg[6] =(u8)((s_UdsDtcInfo.AntennaDTC >>8)&0xFF);
						     CAR_UDSBro.msg[7] = (u8)((s_UdsDtcInfo.AntennaDTC >>16)&0xFF);
						     CAR_UDSBro.len = 8;
						     CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
					         UdsDtcFCDFlag =1;
							 break;
						 default:
							 break;
					 
					 
					 
					 
					 }
				
				}
				else if(data[2] ==0x0A) //����֧�ֵ�DTC
				{
				    CAR_UDSBro.CANx =CANx;
				    CAR_UDSBro.canide =CAN_Id_Standard;
				    CAR_UDSBro.canid =0x79B;
				    CAR_UDSBro.msg[0] = 0x10;	
				    CAR_UDSBro.msg[1] = 0x0E;
				    CAR_UDSBro.msg[2] = 0x59;
				    CAR_UDSBro.msg[3] = 0x0A;
				    CAR_UDSBro.msg[4] = DTCStatusAvailabilityMask; 
				    CAR_UDSBro.msg[5] = (u8)(s_UdsDtcInfo.AntennaDTC&0xFF);
				    CAR_UDSBro.msg[6] =(u8)((s_UdsDtcInfo.AntennaDTC >>8)&0xFF);
				    CAR_UDSBro.msg[7] = (u8)((s_UdsDtcInfo.AntennaDTC >>16)&0xFF);
				    CAR_UDSBro.len = 8;
				    CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				    UdsDtcFCDFlag =1;
				}
			break;
			case 0x34://��������
			break;
			case 0x36://��������
			break;
			case 0x37://�����˳�����
			break;
			default:
			break;
		
		
		
		}
	}
	else if(data[0] ==0x10) //����֡�����һ֡
	{
	    if(data[2]==0x2E)
		{
		    if(Write2EEnableFlag == 1)
			{
				if((data[3]==0xF1)&&(data[4]==0x90))
				{
				    
				
				}
			
			}
			else
			{
			
			
			}
	
		
		}
	
	
	}
	else if(((data[0]>>4)&0x0F) == 0x02) //��֡�������֡
	{
	
	
	}
	else if(data[0] ==0x30) ////�յ�����֡
	{
	    switch(UDS_FCDFlag)
		{
			case 1: //application Software Fingerprint Data Identifier
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x21;	
				CAR_UDSBro.msg[1] = 0x07;
				CAR_UDSBro.msg[2] = 0x01;
				CAR_UDSBro.msg[3] = 0x02;
				CAR_UDSBro.msg[4] = 0x03;
				CAR_UDSBro.msg[5] = 0x05;
				CAR_UDSBro.msg[6] = 0x09;
				CAR_UDSBro.msg[7] = 0x02;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				break;
			case 2: //vehicle Manufacturer Spare Part Number Data Identifier
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x21;	
				CAR_UDSBro.msg[1] = 0x17;
				CAR_UDSBro.msg[2] = 0x21;
				CAR_UDSBro.msg[3] = 0x22;
				CAR_UDSBro.msg[4] = 0x23;
				CAR_UDSBro.msg[5] = 0x25;
				CAR_UDSBro.msg[6] = 0x29;
				CAR_UDSBro.msg[7] = 0x26;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x22;	
				CAR_UDSBro.msg[1] = 0x25;
				CAR_UDSBro.msg[2] = 0x27;
				CAR_UDSBro.msg[3] = 0xAA;
				CAR_UDSBro.msg[4] = 0xAA;
				CAR_UDSBro.msg[5] = 0xAA;
				CAR_UDSBro.msg[6] = 0xAA;
				CAR_UDSBro.msg[7] = 0xAA;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				break;
			case 3: //System Supplier Identifier Data Identifier
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x21;	
				CAR_UDSBro.msg[1] = 0x07;
				CAR_UDSBro.msg[2] = 0x01;
				CAR_UDSBro.msg[3] = 0x02;
				CAR_UDSBro.msg[4] = 0x03;
				CAR_UDSBro.msg[5] = 0x05;
				CAR_UDSBro.msg[6] = 0x09;
				CAR_UDSBro.msg[7] = 0x02;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				break;
			case 4: //ECU Serial Number Data Identifier
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x21;	
				CAR_UDSBro.msg[1] = 0x07;
				CAR_UDSBro.msg[2] = 0x01;
				CAR_UDSBro.msg[3] = 0x02;
				CAR_UDSBro.msg[4] = 0x03;
				CAR_UDSBro.msg[5] = 0xAA;
				CAR_UDSBro.msg[6] = 0xAA;
				CAR_UDSBro.msg[7] = 0xAA;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				break;
			case 5: //VIN Data Identifier
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x21;	
				CAR_UDSBro.msg[1] = 0x07;
				CAR_UDSBro.msg[2] = 0x01;
				CAR_UDSBro.msg[3] = 0x02;
				CAR_UDSBro.msg[4] = 0x03;
				CAR_UDSBro.msg[5] = 0x40;
				CAR_UDSBro.msg[6] = 0x50;
				CAR_UDSBro.msg[7] = 0x60;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x22;	
				CAR_UDSBro.msg[1] = 0x30;
				CAR_UDSBro.msg[2] = 0x01;
				CAR_UDSBro.msg[3] = 0x02;
				CAR_UDSBro.msg[4] = 0x03;
				CAR_UDSBro.msg[5] = 0x05;
				CAR_UDSBro.msg[6] = 0x09;
				CAR_UDSBro.msg[7] = 0x01;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
			
				break;
			case 6: //ECU Hardware Version
				CAR_UDSBro.CANx =CANx;
				CAR_UDSBro.canide =CAN_Id_Standard;
				CAR_UDSBro.canid =0x79B;
				CAR_UDSBro.msg[0] = 0x21;	
				CAR_UDSBro.msg[1] = 0x07;
				CAR_UDSBro.msg[2] = 0x01;
				CAR_UDSBro.msg[3] = 0x02;
				CAR_UDSBro.msg[4] = 0x03;
				CAR_UDSBro.msg[5] = 0xAA;
				CAR_UDSBro.msg[6] = 0xAA;
				CAR_UDSBro.msg[7] = 0xAA;
				CAR_UDSBro.len = 8;
				CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
				break;
			default:
				break;
				
		}
		if(UdsDtcFCDFlag ==1)  //��֡����3��DTC
		{
	        CAR_UDSBro.CANx =CANx;
			CAR_UDSBro.canide =CAN_Id_Standard;
			CAR_UDSBro.canid =0x79B;
			CAR_UDSBro.msg[0] = 0x21;
			CAR_UDSBro.msg[1] =s_UdsDtcInfo.AntennaDtcStatus;			
			CAR_UDSBro.msg[2] = (u8)(s_UdsDtcInfo.SimCardDTC&0xFF);
			CAR_UDSBro.msg[3] = (u8)((s_UdsDtcInfo.SimCardDTC >>8)&0xFF);
			CAR_UDSBro.msg[4] = (u8)((s_UdsDtcInfo.SimCardDTC >>16)&0xFF);
			CAR_UDSBro.msg[5] = s_UdsDtcInfo.SimCardDtcStatus;
			CAR_UDSBro.msg[6] =(u8)(s_UdsDtcInfo.CanbusDTC&0xFF);
			CAR_UDSBro.msg[7] =(u8)((s_UdsDtcInfo.CanbusDTC >>8)&0xFF);
			CAR_UDSBro.len = 8;
			CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
			CAR_UDSBro.CANx =CANx;
			CAR_UDSBro.canide =CAN_Id_Standard;
			CAR_UDSBro.canid =0x79B;
			CAR_UDSBro.msg[0] = 0x22;	
			CAR_UDSBro.msg[1] = (u8)((s_UdsDtcInfo.CanbusDTC >>16)&0xFF);
			CAR_UDSBro.msg[2] = s_UdsDtcInfo.CanbusDtcStatus;
			CAR_UDSBro.msg[3] = 0xAA;
			CAR_UDSBro.msg[4] = 0xAA;
			CAR_UDSBro.msg[5] = 0xAA;
			CAR_UDSBro.msg[6] = 0xAA;
			CAR_UDSBro.msg[7] = 0xAA;
			CAR_UDSBro.len = 8;
			CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
		}
		else if(UdsDtcFCDFlag ==2) //��֡����2��DTC
		{
		    CAR_UDSBro.CANx =CANx;
			CAR_UDSBro.canide =CAN_Id_Standard;
			CAR_UDSBro.canid =0x79B;
			CAR_UDSBro.msg[0] = 0x21;
			CAR_UDSBro.msg[1] =s_UdsDtcInfo.AntennaDtcStatus;			
			CAR_UDSBro.msg[2] = (u8)(s_UdsDtcInfo.SimCardDTC&0xFF);
			CAR_UDSBro.msg[3] = (u8)((s_UdsDtcInfo.SimCardDTC >>8)&0xFF);
			CAR_UDSBro.msg[4] = (u8)((s_UdsDtcInfo.SimCardDTC >>16)&0xFF);
			CAR_UDSBro.msg[5] = s_UdsDtcInfo.SimCardDtcStatus;
			CAR_UDSBro.msg[6] = 0xAA;
			CAR_UDSBro.msg[7] = 0xAA;
			CAR_UDSBro.len = 8;
			CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ;         
		}
	    else if(UdsDtcFCDFlag ==3) //��֡����2��DTC
		{
		    CAR_UDSBro.CANx =CANx;
			CAR_UDSBro.canide =CAN_Id_Standard;
			CAR_UDSBro.canid =0x79B;
			CAR_UDSBro.msg[0] = 0x21;
			CAR_UDSBro.msg[1] =s_UdsDtcInfo.AntennaDtcStatus;			
			CAR_UDSBro.msg[2] = (u8)(s_UdsDtcInfo.CanbusDTC&0xFF);
			CAR_UDSBro.msg[3] = (u8)((s_UdsDtcInfo.CanbusDTC >>8)&0xFF);
			CAR_UDSBro.msg[4] = (u8)((s_UdsDtcInfo.CanbusDTC >>16)&0xFF);
			CAR_UDSBro.msg[5] = s_UdsDtcInfo.CanbusDtcStatus;
			CAR_UDSBro.msg[6] = 0xAA;
			CAR_UDSBro.msg[7] = 0xAA;
			CAR_UDSBro.len = 8;
			CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
		
		}
		else if(UdsDtcFCDFlag ==4) //��֡����2��DTC
		{
		    CAR_UDSBro.CANx =CANx;
			CAR_UDSBro.canide =CAN_Id_Standard;
			CAR_UDSBro.canid =0x79B;
			CAR_UDSBro.msg[0] = 0x21;
			CAR_UDSBro.msg[1] =s_UdsDtcInfo.AntennaDtcStatus;			
			CAR_UDSBro.msg[2] = (u8)(s_UdsDtcInfo.CanbusDTC&0xFF);
			CAR_UDSBro.msg[3] = (u8)((s_UdsDtcInfo.CanbusDTC >>8)&0xFF);
			CAR_UDSBro.msg[4] = (u8)((s_UdsDtcInfo.CanbusDTC >>16)&0xFF);
			CAR_UDSBro.msg[5] = s_UdsDtcInfo.CanbusDtcStatus;
			CAR_UDSBro.msg[6] = 0xAA;
			CAR_UDSBro.msg[7] = 0xAA;
			CAR_UDSBro.len = 8;
			CanSendMsg(CAR_UDSBro.CANx,CAR_UDSBro.canide,CAR_UDSBro.canid,(u8 *)CAR_UDSBro.msg,CAR_UDSBro.len) ; 
		}
	
	
	
	}

}


