/*************************************************************************
**  ����: Config.h�ļ�
*   ����: 2019/3/18
*   ����: chensufei
*   ����: �ṩ���������ݽṹ��API�ӿ�
*		
*   �޸ļ�¼: 
*	   ����						�޸�����
*	2019/3/18 		|		������ʼ���汾��ʵ�������½ӿ�:
					|			
**************************************************************************/
#ifndef __CONFIG_H__
#define __CONFIG_H__

#include "apps.h"

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************
** �汾����
**************************************************************************/

typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;



/**************************************************************************
** �궨��
**************************************************************************/
#define M_COMM_FUNC_SUCC				(0)				/* ���سɹ� */
#define M_COMM_FUNC_FAIL				(-1)			/* ����ʧ�� */

#define M_GPS_MODULE					"GPS"			/* GPSģ�� */
#define M_PROTOCOL_MODULE				"PROTOCOL"		/* Э��ģ�� */
#define M_GSM_AT_MODULE					"GSMAT"
#define M_TCP_MODULE					"TCP"
#define M_GPRS_MODULE					"GPRS"
#define M_FTP_MODULE					"FTP"
#define M_SMS_MODULE					"SMS"
#define M_CALL_MODULE					"CALL"

/* EC20--GSMģ�� */
#define M_EC20_SUPPORT					(1)
#if M_EC20_SUPPORT > 0
#define M_EC20_GSM						"EC20"
#endif

/* SIM800--GSMģ�� */
#define M_SIM800_SUPPORT				(0)
#if M_SIM800_SUPPORT > 0
#define M_SIM800_GSM					"SIM800"
#endif

/* M26--GSMģ�� */
#define M_M26_SUPPORT					(0)
#if M_M26_SUPPORT > 0
#define M_M26_GSM						"M26"
#endif

#ifndef True
#define True							(1)
#endif

#ifndef False
#define False							(0)
#endif

#define M_DEBUG							(1)				/* debug���� */

/* ��ӡ�ض��� */
#if M_DEBUG > 0
#define M_COMM_DEBUG(module, format,...)  	DBG_Print(LEVEL_GPRS, "[%s][%s][%d] debug: "format"\r\n", module, __func__, __LINE__, ##__VA_ARGS__)
#define M_COMM_WARN(module, format,...)  	DBG_Print(LEVEL_GPRS, "[%s][%s][%d] warn: "format"\r\n", module, __func__, __LINE__, ##__VA_ARGS__)
#define M_COMM_ERROR(module, format,...)  	DBG_Print(LEVEL_GPRS, "[%s][%s][%d] error: "format"\r\n", module, __func__, __LINE__, ##__VA_ARGS__)
#define M_COMM_INFO(module, format,...)  	DBG_Print(LEVEL_GPRS, "[%s][%s][%d] info: "format"\r\n", module, __func__, __LINE__, ##__VA_ARGS__)
#define M_COMM_TRACE_IN(module)				DBG_Print(LEVEL_GPRS, "[%s][%s][%d] trace in\r\n", module, __func__, __LINE__)
#define M_COMM_TRACE_OUT(module)			DBG_Print(LEVEL_GPRS, "[%s][%s][%d] trace out\r\n", module, __func__, __LINE__)
#else
#define M_COMM_DEBUG(module, format,...)
#define M_COMM_WARN(module, format,...)
#define M_COMM_ERROR(module, format,...)
#define M_COMM_INFO(module, format,...)
#define M_COMM_TRACE_IN(module)
#define M_COMM_TRACE_OUT(module)
#endif


/* 32λ���ת�� */
#define M_BIG_ENDIAN_U32(x, y)		do\
									{\
									 y = ((x >> 24) & 0xff);\
									 y |= (((x >> 16) & 0xff) << 8);\
									 y |= (((x >> 8) & 0xff) << 16);\
									 y |= ((x & 0xff) << 24);\
									} while(0)
/* 16λ���ת�� */
#define M_BIG_ENDIAN_U16(x, y)		do\
									{\
									 y = ((x >> 8) & 0xff);\
									 y |= ((x & 0xff) << 8);\
									} while(0)
/* b-��0��ʼȡֵ��0-������һλ */
#define M_SET_BIT(x, b)			(x |= ((unsigned long)1 << b))
#define M_CLR_BIT(x, b)			(x &= (~((unsigned long)1 << b)))
#define M_GET_BIT(x, b)			(((unsigned long)x >> b) & 0x01)

#define M_DATA_SIZE(x)			(sizeof(x) / sizeof(x[0]))


/*
* λ������,ʵ��51���Ƶ�GPIO���ƹ���
* ����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).
* IO�ڲ����궨��
*/
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 



#ifdef __cplusplus
}
#endif

#endif

