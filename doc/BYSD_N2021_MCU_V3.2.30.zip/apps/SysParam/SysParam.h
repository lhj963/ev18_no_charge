#ifndef __SYSPARAM_H__
#define __SYSPARAM_H__

#ifdef __cplusplus
extern "C" {
#endif



#define INIT_STORE_FLASH_FLAG     0x0AC2

#define THE_BEIAN_SUCCESS_FLAG 0x55

#define DBG_BPS_DEFAULT  	115200
#define MODEM_BPS_DEFAULT  	115200
#define GPS_BPS_DEFAULT  	9600
#define WIFI_BPS_DEFAULT  	115200
#define BT_BPS_DEFAULT  	115200
#define SENSOR_BPS_DEFAULT  115200
#define PERI_BPS_DEFAULT  	115200

#define REPORT_INV_DEFAULT6  1
#define REPORT_INV_DEFAULT5  15


#define APN_DEFAULT         				"CMNET"
#define APN_USERNAME_DEFAULT				"ROOT"
#define APN_PASSWORD_DEFAULT				"ROOT"



#define FTP_ADDR_DEFAULT 					"59.110.50.55"
#define FTP_PORT_DEFAULT 					21
#define FTP_USER_NAME_DEFAULT 				"gjbbgl"
#define FTP_PASSWORD_DEFAULT 				"fengyun@2019"
#define FTP_DOWNLOAD_FILE_NAME_DEFAULT 		"LF.BIN"

#if 0
#define FTP_ADDR_DEFAULT 					"61.19.242.71"
#define FTP_PORT_DEFAULT 					21
#define FTP_USER_NAME_DEFAULT 				"nateekan"
#define FTP_PASSWORD_DEFAULT 				"N@teeKAn614"
#define FTP_DOWNLOAD_FILE_NAME_DEFAULT 		"LF.BIN"
#endif
#if 0
#define FTP_ADDR_DEFAULT 					"120.25.144.86"
#define FTP_PORT_DEFAULT 					21
#define FTP_USER_NAME_DEFAULT 				"ftp_user"
#define FTP_PASSWORD_DEFAULT 				"123()abc"
#define FTP_DOWNLOAD_FILE_NAME_DEFAULT 		"LF.BIN"
#endif

#define FTP_AUTO_UPDATE_CFG_FILE_DEFAULT    "CFG.LF"



//�г�ƽ̨
#define	CN6_SERVER_ADDR_DEFAULT				"218.75.212.59"
#define	CN6_SERVER_PORT_DEFAULT				15001

//��������Դƽ̨
#define	CN6_SERVER_ADDR_DEFAULT1			"47.97.240.171"
#define	CN6_SERVER_PORT_DEFAULT1			0					//4002

//�г�Э��ĵ�����· 218.75.212.62 10002
#define	CN6_SERVER_ADDR_DEFAULT2			"218.75.212.62"
#define	CN6_SERVER_PORT_DEFAULT2			0


#define	CN5_SERVER_ADDR_DEFAULT				"server.natappfree.cc"
#define	CN5_SERVER_PORT_DEFAULT				0

//���ͷ����ʼ���������ַ
#define	EMAIL_SERVER_ADDR_DEFAULT			"smtp.139.com"
#define	EMAIL_SERVER_PORT_DEFAULT			0

//���ͷ��˺�����
#define EMAIL_SEND_USER_DEFAULT				"13902910201@139.com"
#define EMAIL_SEND_PSW_DEFAULT				"imxzq123"

//����Դ��ѹ������ֵ
#define MAIN_POWER_THRESHOLD_DEFAULT		9500

//CAN���������ݽ�������ģʽ
#define M_CAN_NO_DATA_OUTTIME  		(5)					/* 2min�ĳ�ʱʱ�� */


#define MAX_VIN_LEN  17
#define MAX_SN_LEN   32

/* TCP��·connect ID,������Ҫ���ӵ�ID�����������ӣ����֧��11��ID */
typedef enum _TcpConnectIdE
{
	E_TCP_CONN_CN6_ID = 0,						/* ��1· */
	E_TCP_CONN_CN6_ID_2 = 1,					/* ��2· */
	E_TCP_CONN_BJ5_ID = 2,						/* ��3· */

	E_TCP_CONN_BK_ID = 3,						/* ��4· */
	E_TCP_CONN_MAX_ID = 4,
} TcpConnectIdE;


/* socket���ӷ�ʽ */
typedef enum _TcpSocketTypeE
{
	E_TCP_SOCKET_TCP,							/* TCP��ʽ */
	E_TCP_SOCKET_UDP,							/* UDP��ʽ */
} TcpSocketTypeE;


/* Э�鷽ʽ */
typedef enum _ProtocolTypeE
{
	E_PROTO_BJ5_TYPE = 0,					/* ��5Э�� */
	E_PROTO_CN6_TYPE,						/* ����Э�� */
	E_PROTO_SHH_TYPE,						/* �Ϻ����Ͳ��ͳ� */
	E_PROTO_CN56_TYPE,						/* ��5-6Э�飬�Թ�6Ϊ��׼�������ڱ�����������߼�����ˮ������Ϣ����ǰ�� */
	E_PROTO_HZ_TYPE,						/* ���ݵر�Э�� */
	E_PROTO_GB17691_TYPE = 5,				/* GB17691Э�飬�Թ�6Ϊ��׼�������ڱ�����������߼�����ˮ���ڵ�һ����Ϣ���ͺ���Ϣ��֮�� */
	E_PROTO_JAC_CN6_TYPE,					/* ������6Э�飬�Թ�6��׼����ˮ������Ϣ����ǰ�棬����ÿһ�鶼����ˮ�� */
	E_PROTO_HJ_CN6_TYPE,					/* �����µĹ�6Э��HJ��ÿһ�������ж��вɼ�ʱ��(����ʱ�� + ��ˮ�� + ��Ϣ����(��Ϣ��־ + �ɼ�ʱ�� + ��Ϣ����)) + ǩ����Ϣ  */
	E_PROTO_YT_BLG_CN6_TYPE = 8,			/* ��ͨ��������ƽ̨Э��Խӣ�ÿһ�����ݽṹt(��ˮ�� + ��Ϣ��־ + ��Ϣ��)  */
	E_PROTO_BACK_DOOR_TYPE, 				/* Զ�̹���Э��  */
	E_PROTO_GDXC_HZ_TYPE,					/* �㶫��Ϻ��꣬ÿһ�������а���(1��obd���ݣ�10����������10����չ) */

	E_PROTO_NJYWK_TANGSHA_J5_TYPE = 11,		/* �Ͼ���ά�£���ɽ����Э�飬ÿһ�������ж��вɼ�ʱ��(����ʱ�� + ��ˮ�� + ��Ϣ����(��Ϣ��־ + �ɼ�ʱ�� + ��Ϣ����)) */
} ProtocolTypeE;


typedef enum tagEngineType
{
	EngineType_Compatible = 0,	//�������еķ���������
	EngineType_D78,				//D78
	EngineType_EV18,			//EV18

	EngineType_ZD30,
	EngineType_M9T,
	EngineType_YC,
	EngineType_QC,
	EngineType_CC,				//����
	EngineType_WC,
	EngineType_KMS,

	EngineType_DFAC,
	EngineType_E11K,
	EngineType_EM26,
	EngineType_LXC,

	EngineType_MAX,
}EngineType;

typedef struct tagDate
{
	INT8U year;
	INT8U month;
	INT8U day;
	INT8U hour;
	INT8U min;
	INT8U sec;
}Date;

typedef enum tagUpdateResult
{
	UPDATE_OK = 0,
	UPDATE_FALSE
}UpdateResult;

typedef enum tagUpdateStatus
{
	UPDATE_STATUS_NO = 0x12,			//δ����
	UPDATE_STATUS_START = 0x34,			//����
	UPDATE_STATUS_FILE_OK = 0x56,		//�����ļ�У��ͨ��
	UPDATE_STATUS_UPDATE_OK = 0x78,		//������� BOOT��⵽UPDATE_STATUS_FILE_OK ���״̬ 
										//�ͻ�����APP Ȼ��״̬��ΪUPDATE_STATUS_UPDATE_OK
	UPDATE_STATUS_UPDATE_FAIL = 0x90,	//����ʧ��
}UpdateStatus;

typedef struct tagUpdateInfo
{
	UpdateStatus eUpdateStatus;						//����״̬
	INT8U ucUpdateWay;						//������ʽ(xmodem FTP TCP�ȷ�ʽ)
	INT32U ulStartAddr;						//��FLASH�д�ŵ���ʼ��ַ
	INT32U ulEndAddr;						//������ַ
	INT32U ulTotalBytes;					//�ܴ�С
	INT16U usTotalPackCnt;						//�ܰ���
	Date stStartTime;				//��ʼʱ��
	INT32U ulStartTime;				//��ʼʱ��
	Date stEndTime;					//����ʱ��
	INT32U ulEndTime;				//����ʱ��
	INT32U ulTakeTimes;				//FTP��ʱ����
	INT8S szReportPhone[20];
	INT8S szServerAddr[32];
	INT16U usServerPort;
	INT8S szUpdateFileName[32];
}UpdateInfo;



#define MAX_SVR_LINK_CNT 8

typedef struct tagSysParam
{
	INT16U usInitFlag;			//������ʼ����־
	
	INT8S szServerAddr[MAX_SVR_LINK_CNT][32];		//��������ַ
	INT16U ausPort[MAX_SVR_LINK_CNT];				//�������˿�
	INT8U ucSocketType[MAX_SVR_LINK_CNT];							//SOCKET���� TCP UDP
	ProtocolTypeE aeProtocolTypeE[MAX_SVR_LINK_CNT];

	INT8S szApn[32];
	INT8S szApnUsername[32];
	INT8S szApnPassword[32];

	unsigned int aeCanBaudRate[3];			//CAN1��CAN2 CAN3�Ĳ�����

	//���������Ϣ
	INT8U ucCN6_Ver;
	INT8U ucCN6_Way;

	INT8S szVIN[MAX_VIN_LEN + 1];
	INT8S szSN[MAX_SN_LEN + 1];

	INT8U BCDPhoneNo[6];				//BCD[6]�ն��ֻ���
	INT8U ucEncryptionMethod;			//���ܷ�ʽ

	INT16U usProviceID;					//ʡ��ID
	INT16U usCityID;					//����ID
	INT8U aucManufacturerID[5];			//������ID
	INT8U aucTerminalModel[8];			//�ն��ͺ� λ�������λ���ո�
	INT8U aucTerminalID[7];				//�ն�ID
	INT8U ucLicensePlateColor;			//������ɫ
	INT8S szLicensePlate[32];			//���ƺ�

	INT8S aucAuthenticationCode[41];	//��Ȩ��

	/* ����Դ��ѹ������ֵ */
	INT16U usMainPowerThreshold;

	/* ���ٱ�����ֵ */
	INT8U ucLimitSpeed;

	//EngineType stEngineType;		//������ģʽ
	unsigned char ucCanChannel;
	
	INT8U sleepBaseAccCanFlag;					/* �����жϻ���ACC - 0, ����CAN - 1 */
	INT8U canNoDataOuttime;
	INT8U chipId[16+1];				/* оƬID */
	INT32U drive_cycle_cnt;			//��ʻѭ����
	INT8U beian_flag;		//�����ɹ���־
	INT32U speed_canid;		//CAN�ٶ�ID
	INT32U milage_canid;	//CAN���ID
	INT32U can_bag_id;
}SysParam;


//extern SysParam s_stUserParam;
//extern SysParam s_stUserParam;
//extern SysParam s_stYZUserParam;


extern INT8U get_can_test_mode(void);
extern void set_can_test_mode(INT8U val);
extern EngineType get_ryc_engine_type(void);
extern void set_ryc_engine_type(EngineType val);

extern void set_main_power_off_flag(unsigned char val);
extern unsigned char get_main_power_off_flag(void);
extern unsigned int get_can_list_tip(void *pout,unsigned int outlen);
extern void add_canid_in_list(unsigned int canid);
extern unsigned char is_in_catch_canid_list(unsigned int canid);

extern void set_dst_net_error_accumulate_time_tmp(INT32U val);
extern INT32U get_dst_net_error_accumulate_time_tmp(void);

extern unsigned char get_electric_car_class(void);
extern void set_electric_car_class(unsigned char val);

extern void *get_test_vin(void);
extern void set_test_vin(void *ptr,unsigned char len);


extern void set_rtc_time(unsigned char rtc_time[6]);
extern unsigned char *get_rtc_time_ptr(void);
extern unsigned int get_ms_mod(void);
extern void inc_ms_mod(void);

extern unsigned char get_collect_can_sw(void);
extern void set_collect_can_sw(unsigned char val);
extern unsigned char get_recv_send_can_flag(void);
extern void set_recv_send_can_flag(unsigned char val);

extern unsigned int get_can_rx_fps(unsigned char channel);
extern void stat_can_rx_fps(unsigned char channel);
extern void calc_can_rx_fps(unsigned char channel);

extern void set_net_link_status(unsigned char channel,unsigned char val);
extern unsigned char get_net_link_status(unsigned char channel);
extern unsigned char get_auto_vin_ok_flag(void);
extern void set_auto_vin_ok_flag(unsigned char val);
extern unsigned char get_can_data_arrive_flag(unsigned char channel);
extern void set_can_data_arrive_flag(unsigned char channel,unsigned char val);
extern unsigned char get_can_bps_match_ok_flag(unsigned char channel);
extern void set_can_bps_match_ok_flag(unsigned char channel,unsigned char val);


extern INT8U get_send_next_canfile_bag_flag(void);
extern void set_send_next_canfile_bag_flag(INT8U val);
extern INT8U get_five_hundred_ms_flag(void);
extern void set_five_hundred_ms_flag(INT8U val);

extern INT8U get_export_can_flag(void);
extern void set_export_can_flag(INT8U val);

extern INT8U get_plat_sw1(void);
extern void set_plat_sw1(INT8U val);
extern INT8U get_plat_sw2(void);
extern void set_plat_sw2(INT8U val);


extern INT8U get_rdy_sleep_flag(void);
extern void set_rdy_sleep_flag(INT8U val);


extern void set_export_data_flag(INT8U val);
extern INT8U get_export_data_flag(void);


extern INT8U get_test_step(void);
extern void set_test_step(INT8U val);


extern unsigned char get_chaichu_sos_flag(void);

extern void set_chaichu_sos_flag(unsigned char val);


extern unsigned char get_shoudong_login_flag(void);
extern void set_shoudong_login_flag(unsigned char val);

extern unsigned char get_sjz_beian_flag(void);

extern void set_sjz_beian_flag(unsigned char val);

extern unsigned char *get_pubkey_ptr(void);


extern INT16U GetSysParamSize(void);

extern void set_can_no_data_time(INT32U val);
extern INT32U get_can_no_data_time(void);

extern void set_acc_no_data_time(INT32U val);
extern INT32U get_acc_no_data_time(void);

extern void set_logout_flag(unsigned char channel,INT8U val);

extern INT8U get_logout_flag(unsigned char channel);

extern void LoadUserParam(void);
extern void UserParamDefault(void);
extern void SaveSysParam(void);



extern ProtocolTypeE get_plat_pro_type(unsigned char channel);
extern void set_plat_pro_type(unsigned char channel,ProtocolTypeE em);

extern unsigned int GetCan0Bps(void);

extern void SetCan0Bps(unsigned int canbps);

extern unsigned int GetCan1Bps(void);

extern void SetCan1Bps(unsigned int canbps);

extern unsigned int GetCan2Bps(void);

extern void SetCan2Bps(unsigned int canbps);


extern void SPSetApn(char *szApn);
extern void SPSetApnUsername(char *str);
extern void SPSetApnPassword(char *str);

extern char *SPGetApn(void);
extern char *SPGetApnUsername(void);
extern char *SPGetApnPassword(void);


extern INT8U GetSocketType(unsigned char idx);
extern INT8U ServerLinkIsTcp(unsigned char idx);

extern void SetSocketType(unsigned char idx,TcpSocketTypeE em);


extern void SetSN(void *szSN);
extern INT8S *GetSN(void);
extern void SetVIN(void *szVIN);
extern INT8S *GetVIN(void);
extern INT8U *GetEncryptionMethodPtr(void);
extern INT8U GetEncryptionMethod(void);

extern INT8U *GetBCDPhoneNo(void);
extern void SetBCDPhoneNo(INT8U bcd[6]);

extern INT8U *CN6_GetVerPtr(void);
extern INT8U *CN6_GetWayPtr(void);
extern void CN6_SetWay(INT8U ucWay);
extern void CN6_SetVer(INT8U ucVer);


extern INT8S *GetAuthenticationCode(void);
extern void SetAuthenticationCode(void *ptr);
extern INT8S *GetLicensePlate(void);
extern void SetLicensePlate(void *ptr);
extern INT8U *GetTerminalModel(void);
extern void SetTerminalModel(void *ptr);
extern INT8U *GetTerminalID(void);
extern void SetTerminalID(void *ptr);
extern void SetPlateColor(INT8U val);
extern INT8U GetPlateColor(void);
extern INT8U *GetManufacturerID(void);
extern void SetManufacturerID(void *ptr);
extern INT16U GetProviceID(void);
extern void SetProviceID(INT16U usID);
extern INT16U GetCityID(void);
extern void SetCityID(INT16U usID);

extern void SPSetServerPort(INT8U idx,INT16U usPort);
extern void SPSetServerAddr(INT8U idx,void *szAddr);
extern char *SPGetServerAddr(INT8U idx);
extern INT16U SPGetServerPort(INT8U idx);


extern INT16U GetMainPowerThreshold(void);
extern void SetMainPowerThreshold(INT16U val);

extern void SetLimitSpeed(INT8U val);

extern INT8U GetLimitSpeed(void);

extern EngineType get_engine_type(void);
extern void set_engine_type(EngineType st);
extern char *get_engine_type_str(EngineType st);

extern char *get_plat_pro_type_str(ProtocolTypeE st);

extern void SetCanChannel(INT8U val);
extern INT8U GetCanChannel(void);

extern unsigned int disp_sysparam(void *pOut,unsigned int outbuflen);


extern INT8U SysGetSleepBaseAccCanFlag(void);
extern void SysSetSleepBaseAccCanFlag(INT8U flag);

extern INT8U SysGetCanOuttime(void);
extern void SysSetCanOuttime(INT8U min);

/**************************************************************************
* ��  ��: void SysGetChipId(char *chipId)
* ��  ��: ��ȡоƬID��Ϣ
* ��  ��: 
* ��  ��: void
* ��  ��: void
* ����ֵ: void
**************************************************************************/
extern void SysGetChipId(void *chipId);


/**************************************************************************
* ��  ��: void SysSetChipId(u8 *chipId, int len)
* ��  ��: ����оƬID��Ϣ
* ��  ��: 
* ��  ��: void
* ��  ��: void
* ����ֵ: void
**************************************************************************/
extern void SysSetChipId(void *chipId, int len);

extern char *get_chipid_ptr(void);

extern INT32U get_drive_cycle_cnt(void);

extern void set_drive_cycle_cnt(INT32U val);

extern INT8U is_beian_success(void);
extern void beian_success(void);

extern void set_can_speed_id(INT32U val);
extern INT32U get_can_speed_id(void);
extern void set_can_milage_id(INT32U val);
extern INT32U get_can_milage_id(void);

extern void set_can_bag_id(INT32U val);
extern INT32U get_can_bag_id(void);



extern void record_kaiji_time(INT8U year,INT8U month,INT8U day,INT8U hour,INT8U min,INT8U sec);
//����¼���6��������¼
extern INT8U get_last_kaiji_time(INT8U idx,INT8U *year,INT8U *month,INT8U *day,INT8U *hour,INT8U *min,INT8U *sec);

extern void set_heart_beat_sw(INT8U val);
extern INT8U get_heart_beat_sw(void);
extern INT8U GetReportStatus(void);
extern void SetReportStatus(INT8U ucStatus);

extern INT8U *get_cur_date_ptr(void);
extern INT16U *get_gb_login_flow_ptr(void);
extern INT16U get_gb_login_flow_cnt(void);
extern void set_dst_chemen_switch(INT8U val);
extern void set_dst_chesuo_switch(INT8U val);
extern void set_dst_left_qian_chesuo_switch(INT8U val);
extern INT8U get_dst_chemen_switch(void);
extern INT8U get_dst_chesuo_switch(void);
extern INT8U get_dst_left_qian_chesuo_switch(void);


extern INT8U get_dst_fact_bind_status(void);
extern INT8U get_dst_fact_pro_ver_about_lock(void);
extern INT8U get_dst_fact_lock_status(void);
extern void set_dst_fact_bind_status(INT8U val);
extern void set_dst_fact_pro_ver_about_lock(INT8U val);
extern void set_dst_fact_lock_status(INT8U val);
extern INT8U get_dst_fact_kucunrong_limit_speed(void);
extern void set_dst_fact_kucunrong_limit_speed(INT8U val);
extern INT8U get_dst_fact_limit_speed_level(void);
extern void set_dst_fact_limit_speed_level(INT8U val);

extern void set_dst_net_error_accumulate_time(INT32U val);
extern INT32U get_dst_net_error_accumulate_time(void);
extern INT8U get_want_pro_ver_about_lock(void);
extern INT8U get_want_lock_status(void);
extern void set_want_pro_ver_about_lock(INT8U val);
extern void set_want_lock_status(INT8U val);
extern unsigned char get_lock_car_cmd_from_where(void);
extern void set_lock_car_cmd_from_where(unsigned char val);

extern unsigned char get_dst_no_auto_lock_when_meet_net_error_condition_flag(void);
extern void set_dst_no_auto_lock_when_meet_net_error_condition_flag(unsigned char val);
extern unsigned char get_dst_network_error_tip_flag(void);
extern void set_dst_network_error_tip_flag(unsigned char val);
extern unsigned char get_dst_network_error_flag(void);
extern void set_dst_network_error_flag(unsigned char val);
extern INT8U *get_dst_time_when_network_error(void);
extern void set_dst_time_when_network_error(INT8U t[6]);
extern INT32U get_dst_milage_when_network_error(void);
extern void set_dst_milage_when_network_error(INT32U val);
//������������
extern void backup_dst_lock_car_param(void);
//�ָ���������
extern void resume_dst_lock_car_param(void);
extern INT8U get_dst_want_pro_ver_about_lock(void);
extern INT8U get_dst_want_lock_status(void);
extern void set_dst_want_pro_ver_about_lock(INT8U val);
extern void set_dst_want_lock_status(INT8U val);
extern INT8U get_dst_want_kucunrong_limit_speed(void);
extern void set_dst_want_kucunrong_limit_speed(INT8U val);
extern INT8U get_dst_want_limit_speed_level(void);
extern void set_dst_want_limit_speed_level(INT8U val);
extern INT8U get_dst_pay_tip_flag(void);
extern void set_dst_pay_tip_flag(INT8U val);
extern INT8U get_dst_keep_fit_tip_flag(void);
extern void set_dst_keep_fit_tip_flag(INT8U val);
extern INT8U get_dst_inspect_tip_flag(void);
extern void set_dst_inspect_tip_flag(INT8U val);
extern void set_dst_vin(void *pvin,unsigned int vinlen);
extern INT8U *get_dst_vin(void);


extern void clr_dst_vcu_ver(void);
extern void set_dst_vcu_ver(unsigned char idx,unsigned char ch);
extern INT8U *get_dst_vcu_ver_ptr(void);


extern void set_vcu_ver(unsigned char idx,unsigned char ch);
extern void set_mcu_ver(unsigned char idx,unsigned char ch);
extern void set_bms_ver(unsigned char idx,unsigned char ch);
extern INT8U *get_vcu_ver_ptr(void);
extern INT8U *get_mcu_ver_ptr(void);
extern INT8U *get_bms_ver_ptr(void);

extern void clr_bms_ver(void);
extern void clr_mcu_ver(void);
extern void clr_vcu_ver(void);

extern INT8U *get_sc_date(void);
extern void set_sc_date(INT8U dat[6]);


extern void load_param(void);
extern void save_param(void);
extern void easy_change_param_arrive(void *ptr,unsigned int len);
extern void save_easy_change_param(void);

extern void dst_start_test_net_error_lock(void);

#ifdef __cplusplus
}
#endif
#endif


